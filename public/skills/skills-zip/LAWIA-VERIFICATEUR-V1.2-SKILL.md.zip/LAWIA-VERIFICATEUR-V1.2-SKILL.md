---
name: lawia-verificateur-sources-juridiques
description: LAWIA Vérificateur de Sources Juridiques V1.2 - Système d'analyse et de vérification multidimensionnelle pour avocats en contentieux judiciaire. Version enrichie avec Mode 2 Contre-argumentation avancé intégrant la triple vérification (vérifier adversaire → contre-argumenter → s'auto-vérifier), génération automatique de contre-arguments, recherche de jurisprudence contraire et auto-contrôle anti-hallucination. Architecture LAWIA 2026. Créé par Maître Patrice Humbert, LEXVOX - LAWIA.
---

# LAWIA VÉRIFICATEUR DE SOURCES JURIDIQUES V1.2

**Système d'analyse juridique multidimensionnelle pour avocats en contentieux**  
**Mode 2 enrichi : Contre-argumentation avec triple vérification**  
**Méthodologie LAWIA 2026 | Création Maître Patrice Humbert**

---

## 🎯 NOUVEAUTÉS V1.2

### Mode 2 : Contre-argumentation AVANCÉE

La V1.2 transforme le Mode 2 en système complet de destruction méthodique avec **triple vérification anti-hallucination** :

```
┌─────────────────────────────────────────────────────────────────┐
│              MODE 2 V1.2 : TRIPLE VÉRIFICATION                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ① VÉRIFIER L'ADVERSAIRE                                        │
│     Méthodologie V1.1 appliquée aux références adverses         │
│     → Failles détectées et CONFIRMÉES                           │
│                                                                 │
│  ② CONTRE-ARGUMENTER                                            │
│     Génération basée UNIQUEMENT sur failles vérifiées           │
│     → Recherche active de jurisprudence contraire               │
│     → Textes prêts à l'emploi                                   │
│                                                                 │
│  ③ S'AUTO-VÉRIFIER                                              │
│     Méthodologie V1.1 appliquée à SES PROPRES productions       │
│     → Retrait automatique des éléments non vérifiables          │
│     → Rapport garanti sans hallucination                        │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Garanties du Mode 2 V1.2

✅ **Zéro hallucination** : Aucune jurisprudence inventée  
✅ **Contre-arguments vérifiés** : Basés uniquement sur failles confirmées  
✅ **Jurisprudence contraire** : Trouvée ET re-vérifiée  
✅ **Transparence** : Liste des éléments retirés si non vérifiables

---

## 🎯 VISION STRATÉGIQUE

Le LAWIA Vérificateur V1.2 est un **système d'analyse contentieuse intégrale** avec cinq modes opératoires :

### Cinq modes opératoires

1. **🔍 CONTRÔLE BIBLIOGRAPHIQUE** - Vérification exhaustive de vos références
2. **⚔️ CONTRE-ARGUMENTATION AVANCÉE** - Analyse destructive avec triple vérification *(ENRICHI V1.2)*
3. **✍️ AUDIT RÉDACTIONNEL** - Évaluation qualitative de vos propres écritures
4. **📋 CONFORMITÉ PROCÉDURALE** - Contrôle bordereau, pièces, délais
5. **🎯 CARTOGRAPHIE ARGUMENTAIRE** - Extraction et visualisation des moyens

### Philosophie LAWIA

> "L'intelligence artificielle ne remplace pas le juriste. Elle décuple sa capacité d'analyse, libère son temps pour la stratégie, et transforme la masse documentaire en avantage tactique."

**Ius est ars boni et aequi** - Le droit est l'art du bon et de l'équitable.

---

## ⚠️ RECOMMANDATION TECHNIQUE MAJEURE : PROJETS CLAUDE

### Pourquoi un Projet Claude est IMPÉRATIF

Pour tout document comportant plus de 30 références juridiques, l'utilisation d'un Projet Claude devient **techniquement indispensable** pour garantir :

1. **Persistance automatique** des fichiers de progression entre les sessions
2. **Absence de téléchargement/téléversement** manuel des fichiers intermédiaires
3. **Reprises automatiques** sans intervention manuelle
4. **Sessions parallèles** pour diviser le temps de traitement par 3 à 5

### Seuils et comportement du système

| Références | Hors Projet | Dans Projet |
|------------|-------------|-------------|
| < 30 | ✅ Traitement direct | ✅ Traitement optimal |
| 30-100 | 🟡 Recommandation forte Projet | ✅ Traitement optimal |
| 100-200 | 🔴 Blocage sauf insistance ×3 | ✅ OK + mode léger proposé |
| > 200 | 🔴 Blocage strict | 🟡 Mode léger recommandé |

---

## ⚡ DÉMARRAGE RAPIDE

### Pour vérifier vos propres conclusions

```
Mode : Contrôle bibliographique
[Upload PDF de vos conclusions]
```

### Pour analyser et détruire les conclusions adverses (V1.2)

```
Mode : Contre-argumentation
[Upload PDF conclusions adverses]
Objectif : Identifier toutes les failles et générer contre-arguments
```

### Pour auditer la qualité de vos écritures

```
Mode : Audit rédactionnel
[Upload PDF de vos écritures]
```

### Pour contrôler votre bordereau

```
Mode : Conformité procédurale
[Upload PDF conclusions + bordereau]
```

### Pour extraire la structure argumentaire

```
Mode : Cartographie argumentaire
[Upload PDF conclusions]
```

---

## 🔧 ARCHITECTURE TECHNIQUE V1.2

### Chemins de fichiers selon l'environnement

**DANS UN PROJET CLAUDE** (RECOMMANDÉ) :

| Type | Chemin | Persistance |
|------|--------|-------------|
| Fichiers Projet | Accessibles via le Projet | ✅ Automatique |
| Outputs | `/mnt/user-data/outputs/` | ✅ Téléchargeables |

**HORS PROJET** :

| Type | Chemin | Persistance |
|------|--------|-------------|
| Uploads | `/mnt/user-data/uploads/` | Session uniquement |
| Travail | `/home/claude/` | Session uniquement |
| Outputs | `/mnt/user-data/outputs/` | ✅ Téléchargeables |

### Workflow standard (Modes 1, 3, 4, 5)

#### PHASE 1 : EXTRACTION (sans recherches web)

**Consommation** : 0 recherche web, ~3-5 minutes selon volume

1. Analyse du document uploadé
2. Détection du mode opératoire (ou demande à l'utilisateur)
3. Extraction exhaustive selon le mode
4. Classification et priorisation
5. Création fichiers de travail :
   - `lawia-[session_id].csv`
   - `lawia-[session_id]-progress.json`

#### PHASE 2 : VÉRIFICATION (avec recherches web)

**Consommation** : Maximum 15 recherches par session (compteur explicite)

1. **Déduplication intelligente** (gain 40-60%)
2. **Compteur de recherches** explicite
3. **Vérification web stratégique** (🔴 → 🟡 → 🟢)
4. **Sauvegarde continue**
5. **Génération rapport Excel final**

---

## 🚀 SESSIONS PARALLÈLES

### Principe de fonctionnement

Pour les documents >50 références **dans un Projet Claude**, vous pouvez exécuter plusieurs vérifications simultanées :

1. **Les fichiers du Projet sont partagés** entre toutes les conversations
2. Chaque conversation lit le fichier `progress.json`
3. Chaque conversation traite un **lot différent** de références
4. Les résultats sont consolidés automatiquement

### Procédure

```
ÉTAPE 1 : Lancer la vérification initiale (Phase 1)
ÉTAPE 2 : À la fin de Phase 1, ouvrir 2-4 conversations dans le même Projet
ÉTAPE 3 : Dans chaque conversation, taper "Reprendre"
ÉTAPE 4 : Chaque conversation traite un lot différent
ÉTAPE 5 : La dernière conversation génère le rapport final
```

### Gains de temps estimés

| Références | 1 session | 3 sessions | 4 sessions |
|------------|-----------|------------|------------|
| 50 | ~40 min | ~15 min | ~12 min |
| 100 | ~80 min | ~30 min | ~22 min |
| 150 | ~120 min | ~45 min | ~35 min |

---

## 🔍 MODE 1 : CONTRÔLE BIBLIOGRAPHIQUE

**Usage** : Vérifier la solidité de VOS propres écritures avant dépôt

### Objectifs

✅ **Existence** - Chaque référence citée existe-t-elle réellement ?  
✅ **Exactitude formelle** - Dates, numéros, juridictions corrects ?  
✅ **Disponibilité** - La source est-elle accessible au juge ?  
✅ **Pertinence contextuelle** - La référence porte-t-elle sur le bon domaine juridique ?

### Processus (2 phases standard)

**PHASE 1** : Extraction exhaustive des références  
**PHASE 2** : Vérification web avec priorisation

### Sortie

Rapport Excel avec tableau de vérification, problèmes identifiés, recommandations.

---

## ⚔️ MODE 2 : CONTRE-ARGUMENTATION AVANCÉE (V1.2)

**Usage** : Analyser les conclusions adverses, identifier TOUTES les failles, générer des contre-arguments VÉRIFIÉS

### Objectifs tactiques

🎯 **Détection failles référentielles** - Références inexistantes, mal citées, hors sujet  
🎯 **Génération contre-arguments** - Textes prêts à l'emploi VÉRIFIÉS  
🎯 **Recherche jurisprudence contraire** - Décisions opposées VÉRIFIÉES  
🎯 **Analyse cohérence interne** - Contradictions entre moyens  
🎯 **Extraction prétentions** - Montants réclamés, demandes formulées  
🎯 **Auto-contrôle final** - Garantie zéro hallucination

### Workflow en 5 phases (NOUVEAU V1.2)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    MODE 2 V1.2 - WORKFLOW 5 PHASES                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  PHASE 1        PHASE 2           PHASE 3        PHASE 4        PHASE 5    │
│  ════════       ════════          ════════       ════════       ════════   │
│                                                                             │
│  EXTRACTION  →  VÉRIFICATION   →  GÉNÉRATION  →  RECHERCHE  →  AUTO-       │
│  EXHAUSTIVE     ADVERSE           CONTRE-ARG     JURISP.       CONTRÔLE    │
│                                                  CONTRAIRE                  │
│                                                                             │
│  • Références   • Existence       • Failles     • Décisions   • Vérif.     │
│  • Arguments    • Pertinence      exploitées    contraires    nos propres  │
│  • Prétentions  • Failles         • Textes      • Évolutions  productions  │
│  • Pièces       confirmées        prêts                       • Retraits   │
│                                                                             │
│  ~5-10 min      ~15 min/          ~10 min       ~15 min/      ~10 min/     │
│                 session                          session       session      │
│                                                                             │
│  0 recherche    15 rech/sess      0 recherche   15 rech/sess  15 rech/sess │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### MODE 2 - PHASE 1 : EXTRACTION EXHAUSTIVE

**Consommation** : 0 recherche web | ~5-10 minutes

#### 1.1 Extraction des références juridiques adverses

Identifier et extraire TOUTES les références du document adverse :

**Jurisprudence française** :
- Cour de cassation : `Cass. civ. 1re, 12 juill. 2023, n° 21-12345`
- Conseil d'État : `CE, 15 mars 2024, req. n° 456789`
- Cours d'appel : `CA Paris, 3e ch., 8 juin 2023, n° RG 22/12345`
- Tribunaux : `TJ Paris, 12 janv. 2024, n° 23/54321`

**Jurisprudence européenne** :
- CEDH : `CEDH, 10 nov. 2005, Leyla Şahin c. Turquie, req. n° 44774/98`
- CJUE : `CJUE, 15 mars 2024, aff. C-123/23`

**Législation** :
- Codes, lois, règlements UE, directives

**Doctrine** :
- Articles, ouvrages, notes de jurisprudence

#### 1.2 Extraction des arguments adverses

**Arguments de fait** :
```
┌─────────────────────────────────────────────────┐
│ ARGUMENT DE FAIT n° [X]                         │
├─────────────────────────────────────────────────┤
│ Synthèse : [1-3 phrases]                        │
│ Texte original : « [citation exacte] »          │
│ Page(s) : [localisation]                        │
│ Éléments probatoires invoqués : [pièces citées] │
│ Type : allégation / description / prétention    │
└─────────────────────────────────────────────────┘
```

**Arguments de droit** :
```
┌─────────────────────────────────────────────────┐
│ ARGUMENT DE DROIT n° [X]                        │
├─────────────────────────────────────────────────┤
│ Synthèse : [1-3 phrases]                        │
│ Texte original : « [citation exacte] »          │
│ Page(s) : [localisation]                        │
│ Fondements invoqués : [textes, jurisp.]         │
│ Qualification juridique : [qualification]        │
│ Syllogisme : [majeure → mineure → conclusion]   │
└─────────────────────────────────────────────────┘
```

#### 1.3 Extraction des prétentions chiffrées

```
┌─────────────────────────────────────────────────┐
│ TABLEAU DES PRÉTENTIONS ADVERSES                │
├─────────────────────────────────────────────────┤
│ Principal demandé        : [montant] €          │
│ Article 700 CPC          : [montant] €          │
│ Dommages et intérêts     : [montant] €          │
│ Intérêts légaux          : depuis [date]        │
│ Astreinte                : [montant] €/jour     │
│ TOTAL PRÉTENTIONS        : [TOTAL] €            │
└─────────────────────────────────────────────────┘
```

#### 1.4 Extraction des pièces citées

Liste de toutes les pièces visées pour contrôle avec bordereau.

#### 1.5 Classification et priorisation

- 🔴 **HAUTE** : Référence citée >3 fois OU dans intro/conclusion OU qualifiée "fondamentale"
- 🟡 **MOYENNE** : Référence citée 1-3 fois OU doctrine/ouvrage
- 🟢 **BASSE** : Bibliographie uniquement, non citée dans corps/notes

#### 1.6 Fichiers générés

- `lawia-[session_id]-extraction.csv`
- `lawia-[session_id]-arguments.csv`
- `lawia-[session_id]-progress.json`

---

### MODE 2 - PHASE 2 : VÉRIFICATION DES RÉFÉRENCES ADVERSES

**Consommation** : Maximum 15 recherches par session | Compteur explicite

Cette phase applique la **méthodologie de vérification LAWIA** aux références de l'adversaire.

#### 2.1 Déduplication intelligente

- Identification références identiques/similaires
- Vérification unique, résultat propagé
- **Gain : 40-60% recherches économisées**

#### 2.2 Compteur de recherches

- Variable `recherches_session` dans le JSON
- Incrémentation à chaque recherche web
- Arrêt automatique à 15 recherches
- Message explicite avant pause

#### 2.3 Vérification web stratégique

**Ordre de priorité** : 🔴 HAUTE → 🟡 MOYENNE → 🟢 BASSE

**Sources de confiance priorisées** (voir section complète "Principes de prudence") :

| Niveau | Sources principales |
|--------|---------------------|
| ✅ Haute confiance | Légifrance, Judilibre, Conseil d'État, Conseil constitutionnel, HUDOC, EUR-Lex, CJUE |
| ⚠️ Confiance moyenne | HAL, Cairn, Persée, OpenEdition, Dalloz*, LexisNexis* (*accès limité) |
| ❌ Liste noire | droitjustice.fr, conseil-juridique-online.fr (IGNORER) |
| ❌ À éviter | Forums juridiques, sites personnels, Wikipédia |

#### 2.4 Pour chaque référence adverse

1. **Recherche web** sur bases officielles
2. **Vérification existence** : La référence existe-t-elle ?
3. **Vérification exactitude** : Date, numéro, juridiction corrects ?
4. **Extraction contenu réel** : Que dit vraiment la décision/le texte ?
5. **Évaluation pertinence contextuelle** (0-100%) :
   - 0-20% : Totalement inadéquate, hors sujet
   - 21-40% : Pertinence faible, contexte différent
   - 41-60% : Pertinence moyenne, applicable partiellement
   - 61-80% : Bonne pertinence
   - 81-100% : Pertinence excellente

#### 2.5 Détection des failles

| Type de faille | Description | Gravité |
|----------------|-------------|---------|
| Référence inexistante | La décision citée n'existe pas | 🔴 CRITIQUE |
| Référence hors sujet | Décision existe mais sur autre domaine | 🔴 CRITIQUE |
| Citation tronquée | Passage cité sorti de son contexte | 🟠 MAJEURE |
| Texte abrogé | Loi/article n'est plus en vigueur | 🔴 CRITIQUE |
| Revirement ignoré | Jurisprudence a évolué depuis | 🟠 MAJEURE |
| Qualification erronée | Mauvaise qualification juridique | 🟠 MAJEURE |
| Contradiction interne | Arguments adverses se contredisent | 🔴 CRITIQUE |
| Pièce manquante | Pièce citée non produite | 🟠 MAJEURE |

#### 2.6 Terminologie anti-hallucination stricte

**JAMAIS affirmer** qu'une référence est "fausse" / "incorrecte" / "erronée"

**TOUJOURS utiliser** :
- ❌ "Non trouvée" / "Non vérifiée" / "Vérification impossible"
- ⚠️ "Hors sujet probable" / "Pertinence incertaine"
- ✅ "Trouvée et pertinente" / "Vérifiée avec succès"

**Raison** : Source non trouvée ≠ source inexistante

#### 2.7 Fichiers générés

- `lawia-[session_id]-verifications.csv`
- `lawia-[session_id]-failles.csv`
- Mise à jour `progress.json`

---

### MODE 2 - PHASE 3 : GÉNÉRATION DES CONTRE-ARGUMENTS

**Consommation** : 0 recherche web | ~10 minutes

#### 3.1 Règle fondamentale

**SEULES les failles VÉRIFIÉES en Phase 2 peuvent être exploitées.**

Un contre-argument ne peut être généré que si :
- La référence adverse a été vérifiée (trouvée ou non trouvée)
- La faille a été confirmée par recherche web
- Le fondement du contre-argument est documenté

#### 3.2 Types de contre-arguments générés

**Pour les références non trouvées** :
```
┌─────────────────────────────────────────────────────────────────┐
│ CONTRE-ARGUMENT : RÉFÉRENCE NON TROUVÉE                         │
├─────────────────────────────────────────────────────────────────┤
│ Faille : Réf. adverse n° [X] - Statut : ❌ Non trouvée          │
│                                                                 │
│ TEXTE PRÊT À L'EMPLOI :                                         │
│ « L'adversaire fonde son argumentation sur une prétendue        │
│ décision [référence citée]. Or, cette décision n'a pu être      │
│ localisée sur les bases de données juridiques officielles       │
│ (Judilibre, Légifrance). En l'absence de production de cette    │
│ décision, le moyen manque en fait et devra être écarté. »       │
│                                                                 │
│ ⚠️ Terminologie prudente : "n'a pu être localisée"              │
└─────────────────────────────────────────────────────────────────┘
```

**Pour les références hors sujet** :
```
┌─────────────────────────────────────────────────────────────────┐
│ CONTRE-ARGUMENT : RÉFÉRENCE HORS SUJET                          │
├─────────────────────────────────────────────────────────────────┤
│ Faille : Réf. adverse n° [X] - Pertinence : [Y]%                │
│ Contenu réel vérifié : « [extrait] »                            │
│                                                                 │
│ TEXTE PRÊT À L'EMPLOI :                                         │
│ « L'adversaire invoque [référence] pour soutenir que [argument].│
│ Cependant, cette décision concerne [domaine réel], et non       │
│ [domaine prétendu]. En effet, la Cour statuait sur [contexte    │
│ réel]. Le parallèle avec la présente espèce est inopérant. »    │
│                                                                 │
│ Source de vérification : [URL]                                  │
└─────────────────────────────────────────────────────────────────┘
```

**Pour les contradictions internes** :
```
┌─────────────────────────────────────────────────────────────────┐
│ CONTRE-ARGUMENT : CONTRADICTION INTERNE                         │
├─────────────────────────────────────────────────────────────────┤
│ Contradiction entre Arg. [X] (p. [A]) et Arg. [Y] (p. [B])      │
│                                                                 │
│ TEXTE PRÊT À L'EMPLOI :                                         │
│ « L'argumentation adverse est entachée d'une contradiction      │
│ rédhibitoire. En effet, [partie adverse] soutient d'une part    │
│ que [résumé arg X] (conclusions, p. [A]), et d'autre part que   │
│ [résumé arg Y] (conclusions, p. [B]). Ces deux propositions     │
│ sont logiquement incompatibles. Cette incohérence révèle la     │
│ fragilité de l'argumentation adverse. »                         │
└─────────────────────────────────────────────────────────────────┘
```

#### 3.3 Évaluation de chaque contre-argument

| Niveau | Critères |
|--------|----------|
| **Très forte** | Basé sur faille critique vérifiée + jurisprudence contraire |
| **Forte** | Basé sur faille vérifiée OU jurisprudence contraire |
| **Moyenne** | Basé sur analyse sémantique, pas de faille critique |
| **Faible** | Argument de forme, peu d'impact |
| **À écarter** | Non vérifié ou insuffisamment fondé |

#### 3.4 Hiérarchisation automatique

**Règle** : Si plusieurs contre-arguments Forts ou Très forts existent :
→ NE PAS inclure les contre-arguments Faibles
→ Qualité > Quantité

#### 3.5 Stratégies de contre-argumentation intégrées

**En droit civil** :
- Opposer droit commun vs droit spécial
- Invoquer la jurisprudence récente
- Distinguer le cas d'espèce des précédents cités
- Soulever une exception ou une cause d'extinction

**En responsabilité civile** :
- Contester le lien de causalité
- Invoquer la faute de la victime
- Opposer les causes d'exonération
- Contester l'évaluation du préjudice

**En droit des contrats** :
- Opposer l'interprétation littérale vs téléologique
- Invoquer l'imprévision ou la force majeure
- Contester la qualification du contrat

**En droit du dommage corporel** :
- Contester les postes de préjudice
- Opposer les barèmes (Mornet, ONIAM)
- Discuter le taux d'AIPP
- Contester le lien de causalité avec l'état antérieur

**En procédure** :
- Irrecevabilité
- Forclusion
- Incompétence de la juridiction
- Vice de forme

#### 3.6 Fichiers générés

- `lawia-[session_id]-contre-arguments.csv`
- Mise à jour `progress.json`

---

### MODE 2 - PHASE 4 : RECHERCHE DE JURISPRUDENCE CONTRAIRE

**Consommation** : Maximum 15 recherches par session | Compteur explicite

#### 4.1 Stratégie de recherche

Pour chaque argument de droit adverse vérifié en Phase 2, rechercher activement des décisions qui :
- Établissent le principe **inverse**
- **Limitent** le principe invoqué
- Créent des **exceptions** applicables
- Constituent des **revirements** postérieurs

#### 4.2 Requêtes de recherche optimisées

**Exemple** : Argument adverse sur l'exonération totale par faute de la victime

```
REQUÊTES :
1. [web_search] "faute victime exonération partielle Cass civ 2e"
2. [web_search] "partage responsabilité faute victime jurisprudence"
3. [web_search] "Cass civ 2e exonération totale conditions"
```

#### 4.3 Critères de sélection

| Critère | Poids | Explication |
|---------|-------|-------------|
| Même juridiction | +++++ | Cass. si adversaire cite Cass. |
| Date plus récente | ++++ | Postérieure à celle citée |
| Faits similaires | ++++ | Transposable au cas d'espèce |
| Même chambre | +++ | Cohérence jurisprudentielle |
| Arrêt publié | +++ | Force de précédent |

#### 4.4 Format de sortie

```
┌─────────────────────────────────────────────────────────────────┐
│ JURISPRUDENCE CONTRAIRE - Argument adverse n° [X]               │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ ⚔️ DÉCISION CONTRAIRE 1                                         │
│ Référence : Cass. civ. 2e, 15 juin 2023, n° 22-15.789          │
│ Statut : ✅ TROUVÉE                                             │
│ Source : Judilibre | Lien : [URL]                               │
│                                                                 │
│ Extrait pertinent :                                             │
│ « La faute de la victime n'est exonératoire que si elle        │
│ présente les caractères de la force majeure... »               │
│                                                                 │
│ Pertinence : 92%                                                │
│ Impact : Détruit l'argument d'exonération totale               │
│                                                                 │
│ INTÉGRATION SUGGÉRÉE :                                          │
│ « La position de l'adversaire est contredite par la            │
│ jurisprudence récente (Cass. civ. 2e, 15/06/2023, n° 22-15.789)│
│ qui juge que [citation]. »                                      │
└─────────────────────────────────────────────────────────────────┘
```

#### 4.5 Règle anti-hallucination

**CRITIQUE** : Aucune jurisprudence contraire n'est citée sans avoir été :
1. Trouvée par recherche web effective
2. Vérifiée (existence, contenu, pertinence)
3. Documentée avec lien URL

**Si aucune jurisprudence contraire n'est trouvée** :
```
« La recherche de jurisprudence contraire sur ce point n'a pas 
permis d'identifier de décisions exploitables. L'argument adverse 
devra être contré par d'autres moyens. »
```

#### 4.6 Fichiers générés

- `lawia-[session_id]-jurisprudence-contraire.csv`
- Mise à jour `progress.json`

---

### MODE 2 - PHASE 5 : AUTO-CONTRÔLE FINAL

**Consommation** : Maximum 15 recherches par session | Compteur explicite

#### 5.1 Objectif

**Vérifier que chaque élément du contre-argumentaire généré est exact.**

Cette phase applique la méthodologie de vérification LAWIA **à nos propres productions**.

#### 5.2 Éléments à auto-vérifier

**Jurisprudence contraire citée** :
```
┌─────────────────────────────────────────────────────────────────┐
│ AUTO-CONTRÔLE - Jurisprudence contraire n° [X]                  │
├─────────────────────────────────────────────────────────────────┤
│ Référence citée : Cass. civ. 2e, 15 juin 2023, n° 22-15.789    │
│                                                                 │
│ ☑️ Vérification existence : [web_search effectuée]              │
│ ☑️ Résultat : ✅ Trouvée sur Judilibre                          │
│ ☑️ Extrait vérifié : Conforme à notre citation                  │
│ ☑️ Lien fonctionnel : [URL testée]                              │
│                                                                 │
│ STATUT : ✅ VALIDÉE POUR INCLUSION                              │
└─────────────────────────────────────────────────────────────────┘
```

**Citations exactes** : Vérifier la conformité au texte réel

**Textes législatifs** : Vérifier qu'ils sont toujours en vigueur

#### 5.3 Règle de suppression automatique

**Tout élément non vérifié est RETIRÉ du rapport final.**

Le rapport final ne contient QUE des éléments passés par l'auto-contrôle.

#### 5.4 Matrice d'auto-contrôle

| Élément | Vérifié | Résultat | Action |
|---------|---------|----------|--------|
| Jurisp. contraire 1 | ✅ | Confirmée | Conserver |
| Jurisp. contraire 2 | ✅ | Non trouvée | ❌ RETIRER |
| Art. 1240 C. civ. | ✅ | En vigueur | Conserver |
| Citation Cass. | ✅ | Conforme | Conserver |

#### 5.5 Message si retraits

```
⚠️ AUTO-CONTRÔLE : ÉLÉMENTS RETIRÉS

Les éléments suivants ont été retirés du contre-argumentaire car 
non vérifiables :

1. Jurisprudence : Cass. civ. 1re, 08/02/2024, n° 23-12.345
   Raison : Non trouvée sur Judilibre/Légifrance

Le contre-argumentaire final ne contient QUE des éléments vérifiés.
```

#### 5.6 Fichiers générés

- `lawia-[session_id]-auto-controle.csv`
- `lawia-[session_id]-retraits.csv` (si applicable)
- Mise à jour finale `progress.json`

---

### MODE 2 - RAPPORT FINAL

```
═══════════════════════════════════════════════════════════════════
                    CONTRE-ARGUMENTAIRE VÉRIFIÉ
            Analyse des conclusions de [ADVERSAIRE]
                   Affaire [NOM DOSSIER]
                   
        ✅ Triple vérification LAWIA appliquée
═══════════════════════════════════════════════════════════════════

SYNTHÈSE EXÉCUTIVE
──────────────────────────────────────────────────────────────────
Références adverses analysées : [X]
  ├─ ✅ Vérifiées trouvées : [A]
  ├─ ❌ Non trouvées : [B] → FAILLES EXPLOITABLES
  └─ ⚠️ Hors sujet : [C] → FAILLES EXPLOITABLES

Failles critiques confirmées : [Y]
Contre-arguments générés : [Z]
Jurisprudence contraire vérifiée : [W] décisions

Auto-contrôle final :
  ├─ Éléments validés : [N]
  └─ Éléments retirés (non vérifiables) : [M]

GARANTIE : Ce rapport ne contient AUCUN élément non vérifié.

═══════════════════════════════════════════════════════════════════
I. FAILLES VÉRIFIÉES À EXPLOITER
═══════════════════════════════════════════════════════════════════

[Détail des failles avec contre-arguments prêts à l'emploi]

═══════════════════════════════════════════════════════════════════
II. JURISPRUDENCE CONTRAIRE VÉRIFIÉE
═══════════════════════════════════════════════════════════════════

[Liste des décisions avec extraits et liens]

═══════════════════════════════════════════════════════════════════
III. RÉPONSES AUX ARGUMENTS ADVERSES
═══════════════════════════════════════════════════════════════════

[Contre-arguments structurés par argument]

═══════════════════════════════════════════════════════════════════
IV. ÉLÉMENTS RETIRÉS (TRANSPARENCE)
═══════════════════════════════════════════════════════════════════

[Liste si applicable]

═══════════════════════════════════════════════════════════════════
V. ANNEXES
═══════════════════════════════════════════════════════════════════

• Tableau vérification références adverses
• Matrice auto-contrôle
• Tableau prétentions
• Contrôle bordereau
```

---

## ✍️ MODE 3 : AUDIT RÉDACTIONNEL

**Usage** : Évaluer la qualité de VOS écritures AVANT dépôt

### Grille d'évaluation LAWIA (sur 100)

| Critère | Points | Éléments évalués |
|---------|--------|------------------|
| Structure formelle | /20 | Introduction, plan, moyens, transitions, conclusion, dispositif |
| Cohérence argumentaire | /20 | Contradictions, répétitions, progression, subsidiaires |
| Qualité référentielle | /20 | Vérifiabilité, récence, exactitude, équilibre, autorité |
| Clarté rédactionnelle | /20 | Phrases, vocabulaire, ambiguïtés, proportions, style |
| Densité argumentaire | /20 | Ratio arg/page, étayage, équilibre, superflu |

### Interprétation du score

| Score | Niveau | Recommandation |
|-------|--------|----------------|
| 90-100 | EXCELLENT | Prêt au dépôt |
| 80-89 | TRÈS BIEN | Corrections mineures |
| 70-79 | BIEN | Améliorations recommandées |
| 60-69 | PASSABLE | Révision nécessaire |
| <60 | INSUFFISANT | Refonte requise |

---

## 📋 MODE 4 : CONFORMITÉ PROCÉDURALE

**Usage** : Contrôler exhaustivement la conformité procédurale

### Contrôles effectués

#### 1. Bordereau de communication
✅ Toutes pièces citées sont produites  
✅ Aucune pièce orpheline  
✅ Numérotation cohérente

#### 2. Mentions obligatoires
✅ Constitution avocat  
✅ Élection de domicile  
✅ Signature  
✅ Numérotation pages

#### 3. Contradiction effective
✅ Tous moyens adverses discutés  
✅ Toutes pièces adverses commentées

---

## 🎯 MODE 5 : CARTOGRAPHIE ARGUMENTAIRE

**Usage** : Extraire et visualiser la structure complète de l'argumentation

### Extraction automatique

1. Tous les moyens (principaux, subsidiaires, plus subsidiaires)
2. Tous les sous-moyens (A, B, C / 1, 2, 3 / a, b, c)
3. Tous les fondements juridiques par moyen
4. Toute la jurisprudence citée par moyen
5. Toute la doctrine invoquée par moyen

### Usage tactique

- Brief rapide d'un collaborateur
- Préparation des plaidoiries
- Identification des moyens faibles
- Vérification exhaustivité

---

## 💬 MESSAGES UTILISATEUR STANDARDISÉS

### Message 1 : Détection mode opératoire

```
🎯 LAWIA VÉRIFICATEUR DE SOURCES JURIDIQUES V1.2

Document détecté : [nom_fichier]
Estimation préliminaire : ~[X] références

Quel mode d'analyse souhaitez-vous ?

1️⃣ CONTRÔLE BIBLIOGRAPHIQUE
   Vérifier VOS propres références avant dépôt

2️⃣ CONTRE-ARGUMENTATION AVANCÉE (V1.2)
   Analyser conclusions ADVERSES avec TRIPLE VÉRIFICATION
   → Génération contre-arguments vérifiés
   → Recherche jurisprudence contraire
   → Auto-contrôle anti-hallucination

3️⃣ AUDIT RÉDACTIONNEL
   Évaluer qualité de VOS écritures (score /100)

4️⃣ CONFORMITÉ PROCÉDURALE
   Contrôler bordereau, pièces, mentions obligatoires

5️⃣ CARTOGRAPHIE ARGUMENTAIRE
   Extraire structure moyens + fondements + jurisprudence

Tapez le numéro ou décrivez votre besoin.
```

### Message 2 : Démarrage Mode 2 (V1.2)

```
⚔️ MODE 2 : CONTRE-ARGUMENTATION AVANCÉE V1.2

Ce mode applique la TRIPLE VÉRIFICATION LAWIA :

✅ Phase 2 : Vérifier les références adverses
✅ Phase 4 : Rechercher jurisprudence contraire VÉRIFIÉE
✅ Phase 5 : Auto-contrôler chaque contre-argument généré

GARANTIE : Le rapport final ne contiendra QUE des éléments vérifiés.

📋 Questions préalables :

1. Disposez-vous d'éléments factuels complémentaires ?
2. Y a-t-il un domaine juridique principal ?
3. Avez-vous une audience prochaine ?

⏯️ Je démarre l'extraction (Phase 1)...
```

### Message 3 : Fin Phase 2 Mode 2

```
✅ PHASE 2 TERMINÉE - VÉRIFICATION ADVERSE

📊 Résultats de la vérification :

Références adverses vérifiées : [X]/[TOTAL]
  ├─ ✅ Trouvées : [A]
  ├─ ❌ Non trouvées : [B] → FAILLES EXPLOITABLES
  └─ ⚠️ Hors sujet : [C] → FAILLES EXPLOITABLES

Terminologie LAWIA respectée :
• "Non trouvée" (pas "fausse")
• "Hors sujet probable" (pas "incorrecte")

🎯 FAILLES CONFIRMÉES : [Y]

⏯️ Je passe à la Phase 3 (génération contre-arguments)...
```

### Message 4 : Fin Phase 5 Mode 2 (Auto-contrôle)

```
✅ PHASE 5 TERMINÉE - AUTO-CONTRÔLE

🔍 Résultats de l'auto-vérification :

Éléments générés en Phases 3-4 : [X]
  ├─ ✅ Validés (vérifiés) : [A]
  └─ ❌ Retirés (non vérifiables) : [B]

📄 GÉNÉRATION DU RAPPORT FINAL...

Le rapport ne contiendra QUE des éléments passés par l'auto-contrôle.
```

### Message 5 : Rapport Mode 2 terminé

```
🎉 CONTRE-ARGUMENTAIRE VÉRIFIÉ GÉNÉRÉ !

📄 Documents disponibles :
• Contre-argumentaire Word : [lien]
• Rapport Excel tactique : [lien]

═══════════════════════════════════════════════════════════════

GARANTIE TRIPLE VÉRIFICATION ✅

Phase 2 (Vérif. adverse)    : [X] références vérifiées
Phase 4 (Jurisp. contraire) : [Y] décisions trouvées et vérifiées  
Phase 5 (Auto-contrôle)     : [Z] éléments validés, [W] retirés

Ce rapport ne contient AUCUN élément non vérifié.

═══════════════════════════════════════════════════════════════

Souhaitez-vous que je :
• Approfondisse certains points ?
• Rédige des conclusions sur cette base ?
• Recherche davantage de jurisprudence sur un point ?
```

### Message 6 : Reprise automatique

```
🔄 REPRISE AUTOMATIQUE LAWIA V1.2

Session détectée : [session_id]
Document : [nom_fichier]
Mode : [mode_opératoire]

📊 Progression : [X]/[Y] ([Z]%)
Phase actuelle : [N]

⏯️ Je continue où vous vous êtes arrêté...
```

---

## 🚨 PRINCIPES DE PRUDENCE LAWIA

### 1. Terminologie anti-hallucination stricte

**JAMAIS affirmer** qu'une référence est "fausse" / "incorrecte" / "erronée"

**TOUJOURS utiliser** :
- ❌ "Non trouvée" / "Non vérifiée" / "Vérification impossible"
- ⚠️ "Hors sujet probable" / "Pertinence incertaine"
- ✅ "Trouvée et pertinente" / "Vérifiée avec succès"

### 2. LISTE NOIRE - Sites à ne JAMAIS consulter ou citer

**INTERDICTION ABSOLUE** de consulter, référencer ou citer les sites suivants car ils diffusent de fausses informations juridiques :

| Site interdit | Raison |
|---------------|--------|
| ❌ https://www.droitjustice.fr/ | Fausses informations juridiques |
| ❌ https://www.conseil-juridique-online.fr/ | Fausses informations juridiques |

**Comportement requis** :
- Si ces sites apparaissent dans les résultats de recherche → **Les ignorer totalement**
- Si l'utilisateur cite ces sources → **L'avertir** que ces sites diffusent des informations erronées et proposer des sources fiables

### 3. Sources officielles françaises (HAUTE CONFIANCE)

| Source | URL | Usage |
|--------|-----|-------|
| **Légifrance** | https://www.legifrance.gouv.fr/ | Textes législatifs et réglementaires |
| **Judilibre** | https://www.courdecassation.fr/acces-rapide-judilibre | Jurisprudence Cour de cassation et cours d'appel |
| **Cour de cassation** | https://www.courdecassation.fr/ | Site principal, rapports, avis |
| **Conseil d'État** | https://www.conseil-etat.fr/ | Jurisprudence et documentation administrative |
| **Justice administrative** | https://opendata.justice-administrative.fr/recherche | Décisions TA et CAA |
| **Conseil constitutionnel** | https://www.conseil-constitutionnel.fr/ | Décisions CC, QPC, commentaires |
| **Service-public.fr** | https://www.service-public.gouv.fr/ | Information administrative officielle |
| **Assemblée nationale** | https://www.assemblee-nationale.fr/ | Travaux parlementaires, projets de loi |
| **Sénat** | https://www.senat.fr/ | Travaux parlementaires, rapports |
| **Tous sites gouv.fr** | *.gouv.fr | Sources officielles gouvernementales |

### 4. Sources européennes et internationales (HAUTE CONFIANCE)

| Source | URL | Usage |
|--------|-----|-------|
| **HUDOC (CEDH)** | https://hudoc.echr.coe.int | Jurisprudence Cour européenne des droits de l'homme |
| **CEDH** | https://www.echr.coe.int/ | Site principal CEDH |
| **CJUE** | https://curia.europa.eu/jcms/jcms/j_6/fr/ | Cour de justice de l'Union européenne |
| **EUR-Lex** | https://european-union.europa.eu/institutions-law-budget/law/find-legislation_fr | Législation européenne |
| **Jurisprudence UE** | https://european-union.europa.eu/institutions-law-budget/law/find-case-law_fr | Jurisprudence européenne |
| **Traités internationaux** | https://basedoc.diplomatie.gouv.fr/exl-php/recherche/mae_internet___traites | Base documentaire MAE |

### 5. Autorités administratives indépendantes (HAUTE CONFIANCE)

Toutes les AAI référencées sur Légifrance :
https://www.legifrance.gouv.fr/contenu/menu/autour-de-la-loi/autorites-independantes/

Exemples : CNIL, Défenseur des droits, ARCEP, AMF, ACPR, CSA, etc.

### 6. Sources doctrinales fiables (CONFIANCE MOYENNE)

| Source | URL | Usage |
|--------|-----|-------|
| **HAL SHS** | https://shs.hal.science/ | Archive ouverte sciences humaines |
| **Cairn Droit** | https://droit.cairn.info/ | Revues juridiques |
| **Persée** | https://www.persee.fr/ | Revues scientifiques historiques |
| **OpenEdition Journals** | https://journals.openedition.org/ | Revues sciences humaines |
| **OpenEdition Books** | https://books.openedition.org/ | Ouvrages académiques |

### 7. Sources payantes (CONFIANCE MOYENNE - accès limité)

| Source | Statut |
|--------|--------|
| Dalloz | Payant - vérification parfois impossible |
| LexisNexis / JurisData | Payant - vérification parfois impossible |
| Doctrine.fr | Payant - vérification parfois impossible |
| Lexbase | Payant - vérification parfois impossible |

**Note** : Si une référence n'est trouvée que sur ces bases payantes, indiquer "Vérification impossible - source payante".

### 8. Sources à ÉVITER (BASSE CONFIANCE)

| Type | Exemples | Raison |
|------|----------|--------|
| ❌ Forums juridiques | Droit-finances.net (forums), etc. | Réponses non vérifiées |
| ❌ Sites personnels | Blogs, sites d'avocats individuels | Non officiels |
| ❌ Encyclopédies collaboratives | Wikipédia (pour citations directes) | Modifiable par tous |
| ❌ Sites de vulgarisation | Sauf gouv.fr | Simplifications excessives |

### 9. Hiérarchie des sources en cas de conflit

En cas d'informations contradictoires, respecter cette hiérarchie :

1. **Textes législatifs et réglementaires en vigueur** (Légifrance)
2. **Jurisprudence** (selon autorité de la juridiction) :
   - Cour de cassation > Cours d'appel > Tribunaux
   - Conseil d'État > CAA > TA
   - Conseil constitutionnel (pour questions constitutionnelles)
   - CEDH, CJUE (pour questions européennes)
3. **Doctrine** (commentaires d'auteurs reconnus)

### 10. Règles de recherche

**Ordre de priorité des recherches** :
1. D'abord Légifrance/Judilibre (sources officielles gratuites)
2. Puis HUDOC/EUR-Lex (si dimension européenne)
3. Puis Conseil d'État/Justice administrative (si droit administratif)
4. En dernier : sources doctrinales si nécessaire

**Formulation des requêtes** :
- Pour jurisprudence Cass. : `"numéro de pourvoi" site:courdecassation.fr` ou recherche Judilibre
- Pour textes : `"article X code Y" site:legifrance.gouv.fr`
- Pour CEDH : Recherche HUDOC avec numéro de requête
- Pour CJUE : Recherche Curia avec numéro d'affaire

### 11. Limite explicite de compétence

Ce système vérifie :
- ✅ Existence référence
- ✅ Correspondance formelle
- ✅ Pertinence contextuelle

Ce système NE vérifie PAS :
- ❌ Interprétation juridique donnée
- ❌ Sens exact de la décision
- ❌ Pertinence argumentative de fond

**La validation juridique finale reste du ressort exclusif de l'avocat.**

---

## 🔐 GARANTIES ET LIMITATIONS

### Ce que LAWIA V1.2 garantit

✅ **Exhaustivité extraction** : TOUTES les références identifiées  
✅ **Compteur explicite** : 15 recherches max/session  
✅ **Déduplication intelligente** : Gain 40-60%  
✅ **Sessions parallèles** : Gain ×3-5 dans un Projet  
✅ **Triple vérification Mode 2** : Zéro hallucination  
✅ **Auto-contrôle** : Retrait automatique éléments non vérifiables

### Limitations

⚠️ **Sources payantes** : Non accessibles  
⚠️ **Sources anciennes** : Pré-numérisation difficile  
⚠️ **Limite recherches** : 15/session  
⚠️ **Analyse de fond** : Reste du ressort de l'avocat

---

## 📜 DÉONTOLOGIE

✅ **Secret professionnel** : Documents confidentiels  
✅ **Diligence** : L'outil renforce votre diligence  
✅ **Compétence** : Vous conservez le contrôle  
✅ **Loyauté** : L'analyse adversaire est éthique

**L'avocat reste seul responsable de ses écritures et de sa stratégie.**

---

## 🚀 PRÊT À COMMENCER ?

### Dans un Projet Claude (RECOMMANDÉ)

1. Créer un Projet : "Projects" → "Create Project"
2. Uploader votre document
3. Choisir votre mode :
   - `Mode 1` pour vérifier vos références
   - `Mode 2` pour contre-argumenter (avec triple vérification)
   - `Mode 3` pour auditer vos écritures
   - `Mode 4` pour contrôler la conformité
   - `Mode 5` pour cartographier l'argumentation
4. Laisser les phases s'exécuter
5. Télécharger le rapport final

---

**LAWIA VÉRIFICATEUR DE SOURCES JURIDIQUES V1.2**  
**Mode 2 enrichi : Contre-argumentation avec triple vérification**  
**Méthodologie LAWIA 2026 | Création Maître Patrice Humbert**  
**SELARL LEXVOX - Aix-en-Provence | www.lawia.fr**  
**Janvier 2026**
