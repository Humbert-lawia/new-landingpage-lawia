# Modèle type — Conclusions d'appel

## Table des matières

1. [Structure des conclusions d'appelant](#appelant)
2. [Structure des conclusions d'intimé](#intime)
3. [Modèle de dispositif PAR CES MOTIFS](#dispositif)
4. [Exemples de syllogismes types](#syllogismes)
5. [Formulations élégantes](#formulations)
6. [Appel incident](#appel-incident)

---

## 1. Structure des conclusions d'appelant {#appelant}

```
COUR D'APPEL DE [VILLE]
[CHAMBRE] — [NUMERO RG]

CONCLUSIONS D'APPELANT
(Récapitulatives — [DATE])

POUR : [PRENOM NOM], [PROFESSION], demeurant [ADRESSE]
Représenté par Maître [NOM AVOCAT], avocat au barreau de [BARREAU]
[ADRESSE CABINET] — Tél. [TEL] — [COURRIEL]

CONTRE : [PRENOM NOM INTIMÉ], [PROFESSION], demeurant [ADRESSE]

═══════════════════════════════════════════════════════════
PLAISE À LA COUR
═══════════════════════════════════════════════════════════

I. RAPPEL DE LA PROCÉDURE

[Exposé chronologique de la procédure :
- Instance de première instance devant le [JURIDICTION]
- Jugement rendu le [DATE] — RG n°[NUMERO] — débouté / condamné
- Déclaration d'appel régularisée le [DATE]
- Avis du greffe / constitution de l'intimé le [DATE]]

II. EXPOSÉ DES FAITS

[Narration factuelle des faits de la cause, dans l'ordre chronologique.
Référence aux pièces par leur numéro : (cf. pièce n°[X])
Style sobre, précis, sans commentaire juridique à ce stade.]

III. DISCUSSION

A. Sur [PREMIER MOYEN — intitulé du chef critiqué]

[Structure syllogistique tripartite :

En droit :
[Majeure — règle de droit applicable, textes, jurisprudence]

En l'espèce :
[Mineure — application des faits à la règle de droit]

En conséquence :
[Conclusion — prétention ou demande de principe]]

B. Sur [DEUXIÈME MOYEN]

[Même structure]

C. Sur la critique du jugement entrepris

[Identifier et démontrer les erreurs du premier juge :
- Erreur de droit (mauvaise interprétation, mauvaise application)
- Erreur de fait (dénaturation des éléments de preuve)
- Insuffisance de motivation
- Vice de procédure]

IV. PAR CES MOTIFS

Vu les articles [LISTE DES ARTICLES CPC + FOND],

Il est demandé à la Cour de :

— RECEVOIR [NOM APPELANT] en son appel, le dire bien fondé,

— INFIRMER le jugement rendu le [DATE] par le [JURIDICTION] en ce qu'il a :
   • [REPRENDRE TEXTUEL DU CHEF 1 CRITIQUÉ]
   • [REPRENDRE TEXTUEL DU CHEF 2 CRITIQUÉ]

Et, statuant à nouveau :

— CONDAMNER [NOM INTIMÉ] à payer à [NOM APPELANT] la somme de [MONTANT] €
  au titre de [CHEF DE PRÉJUDICE], avec intérêts au taux légal à compter de [DATE]

— [AUTRES DEMANDES DE FOND]

— CONDAMNER [NOM INTIMÉ] aux entiers dépens d'appel

— CONDAMNER [NOM INTIMÉ] à payer à [NOM APPELANT] la somme de [MONTANT] €
  au titre de l'article 700 du Code de procédure civile

V. SOUS TOUTES RÉSERVES

─────────────────────────
BORDEREAU DE PIÈCES COMMUNIQUÉES

N°[X] — [INTITULÉ PIÈCE]
N°[X+1] — [INTITULÉ PIÈCE]
...
```

---

## 2. Structure des conclusions d'intimé {#intime}

```
COUR D'APPEL DE [VILLE]
[CHAMBRE] — [NUMERO RG]

CONCLUSIONS D'INTIMÉ
(Récapitulatives — [DATE])

POUR : [NOM INTIMÉ]
CONTRE : [NOM APPELANT]

═══════════════════════════════════════════════════════════
PLAISE À LA COUR
═══════════════════════════════════════════════════════════

[Même structure I-II-III]

IV. PAR CES MOTIFS

Vu les articles [LISTE],

Il est demandé à la Cour de :

— DÉCLARER [NOM APPELANT] mal fondé en son appel,

— CONFIRMER le jugement rendu le [DATE] par le [JURIDICTION] en toutes ses dispositions,

OU SUBSIDIAIREMENT :

— INFIRMER le jugement en ce qu'il a [CHEF DE L'APPEL INCIDENT], et statuant à nouveau :
  [DEMANDES DE L'APPEL INCIDENT]

EN TOUT ÉTAT DE CAUSE :

— CONDAMNER [NOM APPELANT] aux entiers dépens d'appel

— CONDAMNER [NOM APPELANT] à payer à [NOM INTIMÉ] la somme de [MONTANT] €
  au titre de l'article 700 du Code de procédure civile

V. SOUS TOUTES RÉSERVES
```

---

## 3. Modèle de dispositif PAR CES MOTIFS {#dispositif}

### Dispositif appelant — Infirmation totale

```
PAR CES MOTIFS

Vu les articles 901, 954, 562 du Code de procédure civile,
Vu [ARTICLES DE FOND],

Il est demandé à la Cour de :

— RECEVOIR [NOM] en son appel formé à l'encontre du jugement rendu le [DATE]
  par [JURIDICTION] sous le n° RG [NUMERO],

— INFIRMER ledit jugement en toutes ses dispositions,

Et, statuant à nouveau :

— [DEMANDE PRINCIPALE CHIFFRÉE]
— [DEMANDE SUBSIDIAIRE]
— [DEMANDES ACCESSOIRES]

— CONDAMNER [NOM INTIMÉ] aux entiers dépens de première instance et d'appel

— CONDAMNER [NOM INTIMÉ] à payer à [NOM APPELANT] la somme de [X] euros
  au titre de l'article 700 CPC

SOUS TOUTES RÉSERVES
```

### Dispositif appelant — Infirmation partielle

```
— INFIRMER le jugement rendu le [DATE] en ce qu'il a :
   1° [TEXTE CHEF 1 CRITIQUÉ, reproduit textuellement]
   2° [TEXTE CHEF 2 CRITIQUÉ, reproduit textuellement]

— CONFIRMER le jugement en ses autres dispositions

Et, statuant à nouveau sur les chefs infirmés :
[DEMANDES]
```

### Dispositif intimé — Confirmation totale

```
— DÉCLARER [NOM APPELANT] irrecevable et en tout cas mal fondé en son appel,

— CONFIRMER le jugement rendu le [DATE] en toutes ses dispositions,

— CONDAMNER [NOM APPELANT] aux entiers dépens d'appel

— CONDAMNER [NOM APPELANT] à payer à [NOM INTIMÉ] la somme de [X] euros
  au titre de l'article 700 CPC
```

---

## 4. Exemples de syllogismes types {#syllogismes}

### Syllogisme — Responsabilité médicale (faute)

```
En droit :
L'article L. 1142-1 I du Code de la santé publique dispose que hors le cas où leur
responsabilité est encourue en raison d'un défaut d'un produit de santé, les professionnels
de santé mentionnés à la quatrième partie du présent code ne sont responsables des
conséquences dommageables d'actes de prévention, de diagnostic ou de soins qu'en cas de
faute. La Cour de cassation précise que la faute s'apprécie in abstracto par référence
au comportement du professionnel de santé normalement diligent placé dans les mêmes
circonstances (Cass. 1re civ., 7 juill. 1998, n° 96-18.921).

En l'espèce :
Il résulte du rapport d'expertise du Docteur [X] (pièce n°[Y]) que [NOM PRATICIEN]
a commis une faute caractérisée en ce qu'il [DESCRIPTION DE LA FAUTE], alors qu'un
praticien normalement diligent aurait [CE QU'IL AURAIT DÛ FAIRE].

En conséquence :
La responsabilité de [NOM DÉFENDEUR] est engagée sur le fondement de l'article L. 1142-1 I CSP.
Il y a lieu de condamner [NOM DÉFENDEUR] à indemniser [NOM VICTIME] de la totalité
de ses préjudices résultant de cette faute médicale.
```

### Syllogisme — Dommage corporel (accident de la circulation)

```
En droit :
L'article 1er de la loi n° 85-677 du 5 juillet 1985 dispose que les victimes d'un accident
de la circulation auquel est impliqué un véhicule terrestre à moteur, ainsi que leurs
ayants droit, sont indemnisées des dommages résultant des atteintes à leur personne qu'elles
ont subis conformément aux dispositions de la présente loi. L'implication suffit à fonder
le droit à indemnisation (Cass. 2e civ., 23 mars 1994, n° 92-13.247).

En l'espèce :
L'accident survenu le [DATE] sur [LIEU] implique le véhicule assuré par [NOM ASSUREUR]
(pièces n°[X et Y]). [NOM VICTIME] a subi une atteinte corporelle directement en lien
causal avec cet accident, ainsi qu'il ressort du rapport d'expertise du Docteur [Z]
(pièce n°[W]) retenant un état antérieur de [%] AIPP.

En conséquence :
[NOM VICTIME] est fondé à obtenir la réparation intégrale de ses préjudices conformément
aux dispositions de la loi du 5 juillet 1985, le droit à indemnisation n'étant pas discutable.
```

### Syllogisme — Prestation compensatoire (art. 270 C. civ.)

```
En droit :
L'article 270 du Code civil dispose que l'un des époux peut être tenu de verser à l'autre
une prestation destinée à compenser, autant qu'il est possible, la disparité que la rupture
du mariage crée dans les conditions de vie respectifs. Les critères d'appréciation sont
énumérés à l'article 271 du Code civil, qui vise notamment les revenus des époux, leur
patrimoine, leur situation professionnelle, leur âge et leur état de santé.

En l'espèce :
[ANALYSE DE LA DISPARITÉ — revenus respectifs, patrimoines, âge, situation professionnelle]

En conséquence :
La disparité créée par la rupture du mariage dans les conditions de vie des époux justifie
l'allocation d'une prestation compensatoire d'un montant de [MONTANT] euros en faveur
de [NOM BÉNÉFICIAIRE].
```

---

## 5. Formulations élégantes pour conclusions d'appel {#formulations}

### Transitions argumentatives

- « C'est en vain que [NOM ADVERSAIRE] soutient que… »
- « L'argumentation adverse ne résiste pas à l'analyse. »
- « Le premier juge n'a pas tiré les conséquences qui s'imposaient de ses propres constatations. »
- « La cour n'est pas liée par les motifs du premier jugement, mais seulement par son dispositif. »
- « Par une appréciation erronée des faits de la cause, le tribunal a… »
- « Il n'est pas sérieusement contestable que… »
- « Il serait vain de contester que… »
- « La démonstration adverse est construite sur une lecture partielle des pièces versées. »

### Formulations de contre-argumentation

- « Cette affirmation procède d'une confusion entre [X] et [Y]. »
- « L'argument adverse confond la condition [A] et la condition [B]. »
- « La jurisprudence invoquée par [NOM ADVERSE] est inapplicable en l'espèce, car… »
- « La lecture proposée par l'adversaire est en contradiction avec les pièces [N°X, N°Y]. »
- « Il n'est pas davantage fondé à prétendre que… »

### Formulations de critique du jugement

- « En refusant d'admettre [X], le premier juge a méconnu les dispositions de l'article [Y]. »
- « La motivation du jugement entrepris est en contradiction directe avec les pièces du dossier. »
- « Le tribunal n'a pas répondu aux moyens développés par [NOM CLIENT] sur [POINT]. »
- « La décision déférée sera infirmée en ce qu'elle a omis de tenir compte de [ÉLÉMENT]. »
- « Le premier juge a inversé la charge de la preuve en imposant à [NOM] de… »

---

## 6. Appel incident {#appel-incident}

L'appel incident est formé par l'intimé dans ses conclusions dans le délai imparti par
l'article 909 CPC (3 mois à compter de la notification des conclusions de l'appelant).

**Formulation dans le dispositif :**

```
ET FORMANT APPEL INCIDENT en ce que le jugement a :
— [Chef non critiqué par l'appelant mais critiqué par l'intimé — texte textuel]

Il est demandé à la Cour de :
— INFIRMER le jugement en ce qu'il a [CHEF CRITIQUÉ EN APPEL INCIDENT]
— Et, statuant à nouveau : [DEMANDE]
```

**Points d'attention :**
- L'appel incident doit être formé dans les conclusions d'intimé déposées dans le délai art. 909
- Il peut porter sur des chefs non critiqués par l'appelant principal
- Sa recevabilité est liée au maintien de l'appel principal (sauf si l'intimé a formé un
  appel provoqué au sens de l'article 550 CPC)

---

*Modèle type conclusions d'appel — Skill procedure-appel-civil — Architecture LAWIA 2026*
*Créé par Maître Patrice Humbert, SELARL LEXVOX AVOCATS & ASSOCIÉS*
