# Méthodologie — Conclusions d'appel

## Table des matières

1. [Grille d'analyse critique du jugement entrepris](#critique-jugement)
2. [Grille d'évaluation des arguments adverses](#evaluation-adverse)
3. [Processus en 9 étapes](#processus)
4. [Articles fréquemment invoqués](#articles)
5. [Aide-mémoire nomenclature Dintilhac](#dintilhac)

---

## 1. Grille d'analyse critique du jugement entrepris {#critique-jugement}

Analyser le jugement de première instance selon ces 8 types d'erreurs :

| Type d'erreur | Description | Stratégie argumentative |
|---------------|-------------|------------------------|
| Erreur de droit | Mauvaise interprétation d'un texte | Citer l'article exact + jurisprudence contraire |
| Mauvaise application | Texte bien identifié, mal appliqué aux faits | Distinguer in abstracto / in concreto |
| Dénaturation des faits | Faits mal établis ou ignorés | Renvoi aux pièces + rapport d'expertise |
| Dénaturation des pièces | Contenu des pièces mal compris | Citation textuelle du document + pièce n° |
| Défaut de réponse à moyen | Moyen développé, non examiné | Art. 455 CPC + reproduire le moyen non examiné |
| Insuffisance de motivation | Motifs trop lapidaires | Art. 455 CPC + démontrer l'insuffisance |
| Inversion de la charge de preuve | Fardeau probatoire mal assigné | Art. 1353 C. civ. + qui prouve quoi |
| Vice de procédure | Irrégularité de forme ou de fond | Articles CPC pertinents + nullité ou caducité |

---

## 2. Grille d'évaluation des arguments adverses {#evaluation-adverse}

| Niveau | Solidité de l'argument adverse | Stratégie de réponse |
|--------|-------------------------------|---------------------|
| 5 — Très solide | Fondé sur jurisprudence récente de la Cour de cassation | Distinguer les faits, limiter la portée, jurisprudence contraire plus récente |
| 4 — Solide | Fondé en droit, mal appliqué aux faits | Démontrer la distinction in concreto |
| 3 — Moyen | Jurisprudence ancienne, doctrine minoritaire | Démontrer l'évolution + doctrine majoritaire |
| 2 — Faible | Fondement discutable ou pièces insuffisantes | Réfuter frontalement, bref, renvoyer aux pièces |
| 1 — Sans fondement | Argument purement tactique ou contredit par les pièces | Une phrase — « Il n'est pas sérieusement contestable que… » |

---

## 3. Processus de rédaction en 9 étapes {#processus}

**Étape 1 — Collecte** : Rassembler jugement, déclaration d'appel, conclusions adverses si disponibles

**Étape 2 — Analyse du jugement** : Identifier les chefs critiqués et les motifs du premier juge

**Étape 3 — Critique du jugement** : Appliquer la grille des 8 types d'erreurs

**Étape 4 — Vérification des fondements** : Via Lexbase MCP ou OpenLegi si nécessaire

**Étape 5 — Évaluation des arguments adverses** : Appliquer la grille des 5 niveaux

**Étape 6 — Architecture argumentative** : Classer les moyens par solidité (plus fort en premier)

**Étape 7 — Rédaction des 10 sections** :
   1. En-tête et identification
   2. PLAISE À LA COUR
   3. Rappel de procédure
   4. Exposé des faits
   5. Discussion — moyens (structure syllogistique)
   6. Réponse aux arguments adverses (si disponibles)
   7. PAR CES MOTIFS — dispositif récapitulatif COMPLET
   8. SOUS TOUTES RÉSERVES
   9. Bordereau de pièces
   10. Date et signature

**Étape 8 — Contrôle qualité** :
- Toutes les prétentions figurent au dispositif ?
- Structure syllogistique respectée pour chaque moyen ?
- Numérotation des pièces conservée ?
- Délais art. 908-911 rappelés ?

**Étape 9 — Génération .docx** : Via skill docx public

---

## 4. Articles fréquemment invoqués {#articles}

### Procédure civile d'appel

| Article | Objet |
|---------|-------|
| Art. 542 CPC | Objet de l'appel |
| Art. 561-562 CPC | Effet dévolutif |
| Art. 564-566 CPC | Demandes nouvelles |
| Art. 908 CPC | Délai conclusions appelant (3 mois, caducité) |
| Art. 909 CPC | Délai conclusions intimé (3 mois, irrecevabilité) |
| Art. 910 CPC | Délai réponse appelant (3 mois) |
| Art. 910-4 CPC | Irrecevabilité prétentions nouvelles en réponse |
| Art. 954 CPC | Forme des conclusions — dispositif récapitulatif |
| Art. 700 CPC | Frais irrépétibles |
| Art. 455 CPC | Obligation de motiver |

### Responsabilité civile générale

| Article | Objet |
|---------|-------|
| Art. 1240 C. civ. | Responsabilité délictuelle |
| Art. 1241 C. civ. | Responsabilité pour faute par négligence |
| Art. 1231-1 C. civ. | Responsabilité contractuelle |
| Art. 1353 C. civ. | Charge de la preuve |
| Art. 1382 C. civ. (ancien) | Pour les litiges antérieurs à 2016 |

### Responsabilité médicale

| Article | Objet |
|---------|-------|
| Art. L. 1142-1 I CSP | Responsabilité pour faute |
| Art. L. 1142-1 II CSP | Solidarité nationale (aléa thérapeutique) |
| Art. L. 1142-2 CSP | Obligation d'assurance |
| Art. L. 1111-2 CSP | Devoir d'information |

### Loi Badinter

| Article | Objet |
|---------|-------|
| Art. 1 L. 85-677 | Implication du VTAM |
| Art. 3 L. 85-677 | Droit à indemnisation (victimes non conductrices) |
| Art. 4 L. 85-677 | Faute du conducteur victime |
| Art. 5 L. 85-677 | Piétons, cyclistes |

### Droit de la famille

| Article | Objet |
|---------|-------|
| Art. 270 C. civ. | Prestation compensatoire |
| Art. 271 C. civ. | Critères PC |
| Art. 373-2-11 C. civ. | Critères résidence habituelle enfant |
| Art. 371-1 C. civ. | Autorité parentale |

---

## 5. Aide-mémoire nomenclature Dintilhac {#dintilhac}

### Préjudices patrimoniaux temporaires (avant consolidation)

| Poste | Sigle | Notes |
|-------|-------|-------|
| Dépenses de santé actuelles | DSA | Débours sécu + reste à charge |
| Frais divers | FD | Transport, aide ménagère temporaire |
| Perte de gains professionnels actuels | PGPA | Sur justificatifs bulletins de salaire |
| Déficit fonctionnel temporaire | DFT | Gêne dans la vie quotidienne avant conso |

### Préjudices patrimoniaux permanents (après consolidation)

| Poste | Sigle | Notes |
|-------|-------|-------|
| Dépenses de santé futures | DSF | Capitalisation via barème BCRIV |
| Frais de logement adapté | FLA | Si nécessité médicalement justifiée |
| Frais de véhicule adapté | FVA | Si nécessité médicalement justifiée |
| Assistance par tierce personne | ATP | Taux horaire × heures/jour × capitalisation |
| Perte de gains professionnels futurs | PGPF | Capitalisation temporaire ou viagère |
| Incidence professionnelle | IP | Dévalorisation sur marché du travail |
| Préjudice scolaire, universitaire, de formation | PSU | Pour victimes mineurs / étudiants |

### Préjudices extrapatrimoniaux

| Poste | Sigle | Notes |
|-------|-------|-------|
| Déficit fonctionnel permanent | DFP | Taux AIPP × barème jurisprudentiel |
| Souffrances endurées | SE | Cotation /7 par l'expert |
| Préjudice esthétique permanent | PEP | Cotation /7 par l'expert |
| Préjudice d'agrément | PA | Liste activités sportives/loisirs perdues |
| Préjudice sexuel | PS | Atteinte à la libido / capacités reproductrices |
| Préjudice d'établissement | PE | Répercussions sur projet de vie familiale |

---

*Méthodologie conclusions d'appel — Skill procedure-appel-civil — Architecture LAWIA 2026*
*Créé par Maître Patrice Humbert, SELARL LEXVOX AVOCATS & ASSOCIÉS*
