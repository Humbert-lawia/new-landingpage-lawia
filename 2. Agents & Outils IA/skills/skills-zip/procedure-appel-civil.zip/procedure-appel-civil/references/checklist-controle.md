# Checklist de contrôle qualité — Déclaration d'appel

## Table des matières

1. [Contrôle qualité en 12 points](#controle-12-points)
2. [Self-check avant présentation](#self-check)
3. [Rappels critiques](#rappels-critiques)
4. [Garde-fous anti-hallucination](#anti-hallucination)
5. [Points de vigilance spécifiques](#vigilance)
6. [Conseils d'accompagnement types](#conseils)

---

## 1. Contrôle qualité en 12 points {#controle-12-points}

Avant de présenter l'acte à l'utilisateur, parcourir systématiquement cette checklist.
**Tout point échouant doit être corrigé avant présentation.**

### Points sanctionnés à peine de nullité

| N° | Contrôle | Article | Résultat |
|----|----------|---------|----------|
| C1 | L'en-tête « DÉCLARATION D'APPEL » est présent avec indication de la cour d'appel | 901, 4° | ☐ OK / ☐ À corriger |
| C2 | La constitution de l'avocat est complète (nom, prénom, barreau, adresse, téléphone, courriel, toque) | 901, 3° | ☐ OK / ☐ À corriger |
| C3 | L'appelant personne physique est identifié : nom, prénoms, profession, domicile, nationalité, date et lieu de naissance | 901, 1° a) | ☐ OK / ☐ À corriger / ☐ N/A (PM) |
| C3bis | L'appelant personne morale est identifié : forme, dénomination, siège social, organe représentant | 901, 1° b) | ☐ OK / ☐ À corriger / ☐ N/A (PP) |
| C4 | L'intimé est identifié conformément à l'article 901, 2° CPC | 901, 2° | ☐ OK / ☐ À corriger |
| C5 | La décision attaquée est précisément désignée (nature, juridiction, date, numéro RG) | 901, 5° | ☐ OK / ☐ À corriger |
| C6 | L'objet de l'appel (INFIRMER ou ANNULER en majuscules) est expressément mentionné | 901, 6° | ☐ OK / ☐ À corriger |
| C7 | Les chefs critiqués sont reproduits textuellement, numérotés et entre guillemets (sauf annulation) | 901, 7° | ☐ OK / ☐ À corriger / ☐ N/A (annulation) |

### Points recommandés (non sanctionnés à peine de nullité)

| N° | Contrôle | Résultat |
|----|----------|----------|
| C8 | Les chefs non critiqués sont reproduits textuellement et numérotés (sauf annulation) | ☐ OK / ☐ À corriger / ☐ N/A |
| C9 | La formule de limitation de la dévolution est présente (sauf annulation) | ☐ OK / ☐ À corriger / ☐ N/A |
| C10 | La liste des pièces mentionne au minimum le jugement et le pouvoir | ☐ OK / ☐ À corriger |
| C11 | L'acte est daté et comporte la mention formelle de signature | ☐ OK / ☐ À corriger |
| C12 | Le vocabulaire procédural est exact (pas de « stipule » pour un texte de loi, « interjeté » pour l'appel) | ☐ OK / ☐ À corriger |

### Résultat du contrôle

- **12/12 points OK** → Acte conforme, présentation autorisée
- **Tout point C1-C7 échoué** → BLOCAGE — correction obligatoire avant présentation
- **Point C8-C12 échoué** → Correction recommandée, signaler dans les notes d'accompagnement

---

## 2. Self-check avant présentation {#self-check}

**AVANT DE PRÉSENTER L'ACTE, vérifier mentalement chaque point :**

```
☐ Toutes les mentions obligatoires de l'article 901, 1° à 7° CPC sont présentes ?
☐ Aucune information obligatoire n'a été inventée ou déduite ?
☐ Les chefs critiqués sont reproduits TEXTUELLEMENT sans aucune reformulation ?
☐ Les chefs non critiqués sont reproduits textuellement dans une section SÉPARÉE ?
☐ La formule de limitation de la dévolution est présente (sauf annulation) ?
☐ Les accords de genre sont corrects tout au long de l'acte ?
☐ Le vocabulaire procédural est exact et cohérent ?
☐ Le format est en texte brut exploitable dans un logiciel de traitement de texte ou RPVA ?
☐ En cas d'annulation : pas de chefs critiqués individuels, effet dévolutif intégral mentionné ?
☐ En cas de pluralité de parties : chaque partie est identifiée conformément aux exigences ?
```

---

## 3. Rappels critiques {#rappels-critiques}

### Rappel 1 — Mentions à peine de nullité
Chaque mention de l'article 901, 1° à 7° CPC est requise à peine de nullité. L'omission d'une seule mention expose l'acte à un risque d'annulation. **Ne jamais omettre une mention obligatoire, ne jamais générer l'acte si une mention fait défaut.**

### Rappel 2 — Responsabilité de l'avocat
L'avocat demeure seul responsable de l'exactitude des mentions, du respect des délais et de la conformité de l'acte. L'acte généré constitue une aide à la rédaction qui doit impérativement être relue et validée avant transmission au greffe.

### Rappel 3 — Reproduction textuelle des chefs du dispositif
Les chefs du dispositif critiqués et non critiqués doivent être reproduits **textuellement**, sans reformulation, sans résumé, sans interprétation. Toute modification du texte du dispositif compromet la validité de la dévolution et peut entraîner des conséquences procédurales graves (absence de dévolution sur un chef reformulé).

### Rappel 4 — Situations procédurales complexes
En cas de situation procédurale complexe (appel incident, jonction d'instances, renvoi après cassation, pluralité de parties avec intérêts divergents), signaler la complexité et recommander une vérification approfondie des textes applicables et de la jurisprudence récente.

---

## 4. Garde-fous anti-hallucination {#anti-hallucination}

### Interdictions absolues

| N° | Interdiction | Conséquence si violation |
|----|-------------|------------------------|
| AH1 | Ne jamais inventer une mention d'identification (nom, adresse, date de naissance, numéro RG) non fournie par l'utilisateur | Acte contenant des informations fausses, risque de nullité |
| AH2 | Ne jamais reformuler, résumer ou paraphraser les chefs du dispositif du jugement | Dévolution mal délimitée, risque d'irrecevabilité |
| AH3 | Ne jamais inventer ou supposer un numéro de toque, une adresse de cabinet ou un barreau non communiqués | Constitution d'avocat invalide |
| AH4 | Ne jamais affirmer qu'un délai d'appel spécifique s'applique si le régime procédural n'est pas explicitement identifié | Conseil juridique erroné |
| AH5 | Ne jamais citer une jurisprudence sans être certain de son existence et de sa référence exacte | Citation inventée, déontologie |

### Gestion de l'incertitude

En cas d'information incertaine ou ambiguë :
- **Signaler** avec la mention **[À VÉRIFIER]** dans l'acte
- **Ne pas compléter** par supposition
- **Demander confirmation** à l'utilisateur plutôt que deviner

### Informations facultatives manquantes

Pour les informations non obligatoires à peine de nullité mais recommandées (capital social, RCS, etc.) :
- Générer l'acte en omettant la mention
- Signaler l'omission dans les notes d'accompagnement
- Proposer à l'utilisateur de compléter s'il le souhaite

---

## 5. Points de vigilance spécifiques {#vigilance}

### Annexe RPVA (limite 4 080 caractères)

Si les chefs du dispositif critiqués excèdent 4 080 caractères :
- Signaler impérativement à l'utilisateur la nécessité de recourir à l'annexe
- Structurer l'acte principal avec un renvoi à l'annexe
- Générer l'annexe séparément si demandé

### Appel en annulation — Pas de chefs critiqués

En cas d'appel tendant à l'annulation du jugement :
- **Ne pas mentionner** de chefs du dispositif individuels critiqués
- Mentionner que l'effet dévolutif s'étend à l'intégralité du jugement
- Indiquer le motif d'annulation (vice de procédure, incompétence, etc.)
- La formule de limitation de la dévolution ne s'applique pas

### Distinction infirmation partielle / totale

- **Infirmation partielle** : Certains chefs sont critiqués, d'autres non → Section critiqués + section non critiqués + formule de limitation
- **Infirmation totale** : Tous les chefs sont critiqués → Tous les chefs en section critiqués, section non critiqués vide ou absente, formule de limitation adaptée

### Accords de genre — Points d'attention

| Situation | Masculin | Féminin |
|-----------|----------|---------|
| Avocat | Lequel | Laquelle |
| Appelant | Appelant | Appelante |
| Naissance | Né le | Née le |
| Intimé | Intimé | Intimée |
| Profession | Retraité | Retraitée |

Pour les personnes morales : utiliser le genre de la forme sociale (LA SAS, LA SARL, LA SCI, LE syndicat, L'association).

---

## 6. Conseils d'accompagnement types {#conseils}

### Message type après génération

```
Voici la déclaration d'appel conforme à l'article 901 CPC. Merci de vérifier avant transmission :

1. L'exactitude de toutes les mentions obligatoires (identité des parties, constitution d'avocat, décision attaquée)
2. La reproduction textuelle fidèle des chefs du dispositif critiqués et non critiqués
3. Le respect du délai d'appel applicable :
   - Principe : 1 mois à compter de la notification du jugement
   - Référé : 15 jours
   - [Adapter selon le cas d'espèce]
4. La transmission par RPVA au greffe de la cour d'appel
5. La joindre d'une copie intégrale du jugement attaqué et du pouvoir de représentation

Rappels importants :
- En cas de retour de la lettre de notification ou d'absence de constitution de l'intimé dans le mois, le greffe vous avisera pour procéder à la signification dans le mois suivant (article 902 CPC), à peine de caducité relevée d'office.
- L'avocat demeure seul responsable de l'exactitude des mentions et du respect des délais.
```

### Points de vigilance spécifiques à signaler selon le contexte

| Contexte | Point de vigilance à signaler |
|----------|-------------------------------|
| Pluralité d'intimés | Signification à chacun des intimés non constitués |
| Appel incident possible | L'intimé peut former un appel incident dans les délais de conclusion |
| Matière familiale | Vérifier le régime spécial applicable (divorce, autorité parentale, etc.) |
| Dommage corporel | Vérifier la mise en cause de l'assureur et du fonds de garantie le cas échéant |
| Tribunal de commerce | Vérifier la compétence de la cour d'appel (appel des jugements du TC) |
| Conseil de prud'hommes | Vérifier le régime spécifique de l'appel prud'homal |
| Renvoi après cassation | Signaler la complexité et recommander vérification des textes |

---

*Checklist de contrôle qualité — Skill déclaration-appel — Architecture LAWIA 2026*
*Créé par Maître Patrice Humbert, SELARL LEXVOX AVOCATS*
