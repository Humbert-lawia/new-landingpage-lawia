# Index des références — procedure-appel-civil

| Fichier | Mode | Contenu | Lignes env. |
|---------|------|---------|-------------|
| `fondements-juridiques.md` | Both | Art. 901-902, 908-911, 954 CPC, jurisprudences | ~220 |
| `modele-declaration-appel.md` | Mode 1 | Modèle complet avec placeholders PP/PM | ~120 |
| `checklist-controle.md` | Mode 1 | 12 points de contrôle qualité | ~110 |
| `modele-conclusions-appel.md` | Mode 2 | Dispositifs, syllogismes, formulations | ~230 |
| `methodology-appel.md` | Mode 2 | Grilles d'analyse, 5 niveaux, formulations | ~150 |

## Règle de chargement

NEVER charger tous les fichiers simultanément.
- Mode 1 (/appel) : charger `fondements-juridiques.md` + `modele-declaration-appel.md` + `checklist-controle.md`
- Mode 2 (/conclusions-appel) : charger `fondements-juridiques.md` + `modele-conclusions-appel.md` + `methodology-appel.md`
