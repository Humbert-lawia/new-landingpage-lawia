# Modèle type — Déclaration d'appel

## Table des matières

1. [Structure obligatoire de l'acte](#structure)
2. [Modèle complet — Appel en infirmation](#modele-infirmation)
3. [Variante — Appel en annulation](#variante-annulation)
4. [Variante — Personne morale appelante](#variante-pm)
5. [Variante — Pluralité de parties](#variante-pluralite)
6. [Règles de remplacement des placeholders](#regles-placeholders)

---

## 1. Structure obligatoire de l'acte {#structure}

Chaque déclaration d'appel générée doit comporter les sections suivantes, dans cet ordre impératif :

| N° | Section | Contenu | Obligatoire à peine de nullité |
|----|---------|---------|-------------------------------|
| 1 | En-tête | « DÉCLARATION D'APPEL » + cour d'appel | Oui (art. 901, 4°) |
| 2 | Constitution avocat | Identification complète | Oui (art. 901, 3°) |
| 3 | Identification appelant | Mentions complètes PP ou PM | Oui (art. 901, 1°) |
| 4 | Identification intimé(s) | Mentions requises PP ou PM | Oui (art. 901, 2°) |
| 5 | Décision attaquée | Juridiction, date, RG | Oui (art. 901, 5°) |
| 6 | Objet de l'appel | Infirmation ou annulation | Oui (art. 901, 6°) |
| 7 | Chefs critiqués | Reproduction textuelle | Oui sauf annulation (art. 901, 7°) |
| 8 | Chefs non critiqués | Reproduction textuelle | Recommandé (verrouillage dévolution) |
| 9 | Indication des pièces | Liste sommaire | Recommandé |
| 10 | Formule finale | Lieu, date, signature | Obligatoire (art. 901, dernier al.) |

---

## 2. Modèle complet — Appel en infirmation (personne physique) {#modele-infirmation}

```
DÉCLARATION D'APPEL
Devant la cour d'appel de [COUR_APPEL_VILLE]

Régularisée par :
Maître [AVOCAT_PRENOM] [AVOCAT_NOM]
Avocat[e] au barreau de [AVOCAT_BARREAU]
[AVOCAT_ADRESSE_LIGNE1]
[AVOCAT_ADRESSE_LIGNE2]
Tél. : [AVOCAT_TELEPHONE] – Courriel : [AVOCAT_COURRIEL]
N° Toque : [AVOCAT_TOQUE]

[ACCORD_GENRE_AVOCAT : Lequel/Laquelle] se constitue pour la présente et pour ses suites au nom de :

APPELANT[E]
[APPELANT_CIVILITE] [APPELANT_PRENOM] [APPELANT_NOM]
[APPELANT_PROFESSION]
Demeurant [APPELANT_ADRESSE_COMPLETE]
Nationalité [APPELANT_NATIONALITE]
Né[e] le [APPELANT_DATE_NAISSANCE] à [APPELANT_LIEU_NAISSANCE]

CONTRE

INTIMÉ[E]
[INTIME_CIVILITE] [INTIME_PRENOM] [INTIME_NOM]
Demeurant [INTIME_ADRESSE_COMPLETE]

───

DÉCISION ATTAQUÉE

[NATURE_DECISION] rendu[e] le [DECISION_DATE] par le [JURIDICTION_COMPLETE]
RG n° [DECISION_RG]

───

OBJET DE L'APPEL – EFFET DÉVOLUTIF

L'appel est interjeté par [QUALITE_APPELANT] contre la décision susvisée.

L'objet de l'appel est de demander à la cour d'appel d'INFIRMER le jugement en ce qu'il a statué comme suit :

CHEFS DU DISPOSITIF CRITIQUÉS (OBJET DE LA DÉVOLUTION) :

1° « [CHEF_CRITIQUE_1 — reproduction textuelle intégrale] »
2° « [CHEF_CRITIQUE_2 — reproduction textuelle intégrale] »
3° « [CHEF_CRITIQUE_N — reproduction textuelle intégrale] »

CHEFS DU DISPOSITIF NON CRITIQUÉS (DEVENUS DÉFINITIFS, HORS DÉVOLUTION) :

1° « [CHEF_NON_CRITIQUE_1 — reproduction textuelle intégrale] »
2° « [CHEF_NON_CRITIQUE_2 — reproduction textuelle intégrale] »
3° « [CHEF_NON_CRITIQUE_N — reproduction textuelle intégrale] »

L'appel est expressément limité aux chefs de dispositif ci-dessus désignés comme « critiqués », auxquels la dévolution est circonscrite, les autres chefs du dispositif n'étant pas remis en cause.

───

INDICATION DES PIÈCES :

1. Copie intégrale [du jugement / de l'ordonnance] attaqué[e]
2. Pouvoir de représentation / mandat
3. [Autres pièces le cas échéant]

───

FORMULE FINALE

Fait à [LIEU], le [DATE]

Maître [AVOCAT_PRENOM] [AVOCAT_NOM]
Avocat[e] au barreau de [AVOCAT_BARREAU]
[Signature]
```

---

## 3. Variante — Appel en annulation {#variante-annulation}

Lorsque l'appel tend à l'annulation du jugement, remplacer la section « OBJET DE L'APPEL » par :

```
OBJET DE L'APPEL – EFFET DÉVOLUTIF

L'appel est interjeté par [QUALITE_APPELANT] contre la décision susvisée.

L'objet de l'appel est de demander à la cour d'appel d'ANNULER le jugement.

L'appel tend à l'annulation du jugement dans son intégralité pour [MOTIF_ANNULATION : vice de procédure (violation des droits de la défense) / incompétence / excès de pouvoir / autre].

En conséquence, l'effet dévolutif s'étend à l'intégralité du jugement, conformément à l'article 901, 7° du code de procédure civile (exception à l'obligation de mentionner les chefs critiqués en cas d'appel en annulation).
```

**Différences avec le modèle infirmation :**
- Pas de section « CHEFS DU DISPOSITIF CRITIQUÉS »
- Pas de section « CHEFS DU DISPOSITIF NON CRITIQUÉS »
- Pas de formule de limitation de la dévolution
- Mention expresse du motif d'annulation
- Mention expresse de l'extension de l'effet dévolutif à l'intégralité du jugement

---

## 4. Variante — Personne morale appelante {#variante-pm}

Pour une personne morale appelante, remplacer la section « APPELANT[E] » par :

```
APPELANTE
[FORME_SOCIALE] [DENOMINATION]
Au capital de [CAPITAL] euros
Siège social : [SIEGE_SOCIAL_ADRESSE]
[IMMATRICULATION : RCS [VILLE] [NUMERO] / ou autre registre]
Représentée par [ORGANE_REPRESENTANT : son président en exercice / son gérant / son directeur général], [CIVILITE] [PRENOM] [NOM_REPRESENTANT]
```

**Exemples de formes sociales et organes représentants :**

| Forme sociale | Organe représentant légal |
|---------------|--------------------------|
| SAS | Président en exercice |
| SARL | Gérant |
| SA à conseil d'administration | Président du conseil d'administration |
| SA à directoire | Président du directoire |
| SCI | Gérant |
| SNC | Gérant |
| Association loi 1901 | Président |
| Syndicat de copropriétaires | Syndic (sur décision de l'assemblée générale) |

Pour une **personne morale intimée**, la structure simplifiée est :

```
INTIMÉE
[FORME_SOCIALE] [DENOMINATION]
Siège social : [SIEGE_SOCIAL_ADRESSE]
```

---

## 5. Variante — Pluralité de parties {#variante-pluralite}

### Pluralité d'appelants

```
APPELANTS

1) [CIVILITE] [PRENOM] [NOM]
[PROFESSION]
Demeurant [ADRESSE]
Nationalité [NATIONALITE]
Né[e] le [DATE_NAISSANCE] à [LIEU_NAISSANCE]

2) [CIVILITE] [PRENOM] [NOM]
[PROFESSION]
Demeurant [ADRESSE]
Nationalité [NATIONALITE]
Né[e] le [DATE_NAISSANCE] à [LIEU_NAISSANCE]
```

### Pluralité d'intimés

```
CONTRE

INTIMÉS

1) [CIVILITE] [PRENOM] [NOM]
Demeurant [ADRESSE]

2) [FORME_SOCIALE] [DENOMINATION]
Siège social : [SIEGE_SOCIAL]

3) [CIVILITE] [PRENOM] [NOM]
Demeurant [ADRESSE]
```

---

## 6. Règles de remplacement des placeholders {#regles-placeholders}

### Placeholders et leur signification

| Placeholder | Description | Exemple |
|-------------|-------------|---------|
| `[COUR_APPEL_VILLE]` | Ville de la cour d'appel | Aix-en-Provence |
| `[AVOCAT_PRENOM]` | Prénom de l'avocat | Sophie |
| `[AVOCAT_NOM]` | Nom de l'avocat | LAMBERT |
| `[AVOCAT_BARREAU]` | Barreau d'inscription | Paris |
| `[AVOCAT_ADRESSE_LIGNE1]` | Adresse ligne 1 | 10 rue de Rivoli |
| `[AVOCAT_ADRESSE_LIGNE2]` | Code postal et ville | 75001 Paris |
| `[AVOCAT_TELEPHONE]` | Téléphone | 01 23 45 67 89 |
| `[AVOCAT_COURRIEL]` | Courriel | s.lambert@avocat.fr |
| `[AVOCAT_TOQUE]` | Numéro de toque | P0123 |
| `[ACCORD_GENRE_AVOCAT]` | Lequel / Laquelle | Laquelle |
| `[APPELANT_CIVILITE]` | M. / Mme | M. |
| `[APPELANT_PRENOM]` | Prénom de l'appelant | Jean |
| `[APPELANT_NOM]` | Nom de l'appelant | DUPONT |
| `[APPELANT_PROFESSION]` | Profession | Retraité |
| `[APPELANT_ADRESSE_COMPLETE]` | Adresse complète | 12 rue de la Paix, 75002 Paris |
| `[APPELANT_NATIONALITE]` | Nationalité | française |
| `[APPELANT_DATE_NAISSANCE]` | Date de naissance | 15 mars 1955 |
| `[APPELANT_LIEU_NAISSANCE]` | Lieu de naissance | Paris (75) |
| `[NATURE_DECISION]` | Jugement / Ordonnance | Jugement |
| `[DECISION_DATE]` | Date de la décision | 10 janvier 2026 |
| `[JURIDICTION_COMPLETE]` | Juridiction complète | tribunal judiciaire de Paris |
| `[DECISION_RG]` | Numéro de répertoire général | 25/12345 |
| `[QUALITE_APPELANT]` | l'appelant / l'appelante | l'appelant |
| `[CHEF_CRITIQUE_N]` | Chef du dispositif critiqué | Reproduction textuelle exacte |
| `[CHEF_NON_CRITIQUE_N]` | Chef non critiqué | Reproduction textuelle exacte |
| `[MOTIF_ANNULATION]` | Motif d'annulation | violation des droits de la défense |

### Règles de remplacement

1. **Noms de famille** : Toujours en MAJUSCULES dans l'acte
2. **Accords de genre** : Adapter systématiquement selon le sexe de la partie ou la nature de la personne morale
3. **Chefs du dispositif** : Reproduction textuelle intégrale, sans aucune modification
4. **Dates** : Format jour mois année en toutes lettres (« 10 janvier 2026 »)
5. **Adresses** : Format complet avec numéro, rue, code postal et ville
6. **Placeholder non rempli** : Si une information facultative n'est pas fournie, supprimer la ligne correspondante. Si une information obligatoire n'est pas fournie, ne jamais générer l'acte.

---

*Modèle type — Skill déclaration-appel — Architecture LAWIA 2026*
*Créé par Maître Patrice Humbert, SELARL LEXVOX AVOCATS*
