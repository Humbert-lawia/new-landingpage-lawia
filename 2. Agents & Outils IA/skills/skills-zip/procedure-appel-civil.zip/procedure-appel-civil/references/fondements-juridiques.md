# Fondements juridiques — Procédure d'appel civil français

## Table des matières

1. [Art. 901 CPC — Déclaration d'appel (mentions obligatoires)](#art-901)
2. [Art. 902 CPC — Signification et caducité](#art-902)
3. [Art. 542 et 561-562 CPC — Effet dévolutif](#effet-devolutif)
4. [Art. 564-566 CPC — Demandes nouvelles en appel](#demandes-nouvelles)
5. [Art. 908-911 CPC — Délais de conclusions](#delais-conclusions)
6. [Art. 954 CPC — Forme des conclusions d'appel](#art-954)
7. [Art. 910-4 CPC — Irrecevabilité des prétentions nouvelles](#art-910-4)
8. [Délais d'appel par matière](#delais-appel)
9. [Régime des nullités](#nullites)
10. [Jurisprudences de référence](#jurisprudences)
11. [Sources et textes de référence](#sources)

---

## 1. Article 901 CPC — Déclaration d'appel {#art-901}

**Version consolidée — Décret n° 2023-1391 du 29 décembre 2023 (entrée en vigueur 1er sept. 2024)**

La déclaration d'appel, qui peut comporter une annexe, est faite par un acte contenant,
**à peine de nullité** :

1° Pour chacun des appelants :
   a) Personne physique : nom, prénoms, profession, domicile, nationalité, date et lieu de naissance
   b) Personne morale : forme, dénomination, siège social, organe représentant légalement

2° Pour chacun des intimés : nom, prénoms, domicile (PP) ou dénomination, siège (PM)

3° La constitution de l'avocat de l'appelant

4° L'indication de la cour devant laquelle l'appel est porté

5° L'indication de la décision attaquée

6° L'objet de l'appel en ce qu'il tend à l'infirmation ou à l'annulation du jugement

7° Les chefs du dispositif du jugement expressément critiqués auxquels l'appel est limité,
   sauf si l'appel tend à l'annulation du jugement

Elle est datée et signée par l'avocat constitué. Elle est accompagnée d'une copie de la
décision et sa remise au greffe vaut demande d'inscription au rôle.

**Points d'attention critiques :**
- **Annexe** : Expressément prévue si les chefs excèdent 4 080 caractères (limite RPVA)
- **Exception annulation** : Pas de chefs critiqués individuels — effet dévolutif intégral
- **Art. 915-2 CPC** : Le CME peut étendre la dévolution au-delà des chefs initialement critiqués

---

## 2. Article 902 CPC — Signification et caducité {#art-902}

Le greffier adresse à chacun des intimés, par lettre simple, un exemplaire de la déclaration
d'appel avec l'indication de l'obligation de constituer avocat.

En cas de retour au greffe ou si l'intimé n'a pas constitué avocat dans un délai d'un mois
à compter de l'envoi de la lettre de notification, le greffier avise l'avocat de l'appelant.

**À peine de caducité relevée d'office** : la signification doit être effectuée dans le
mois suivant la réception de l'avis du greffe.

L'acte de signification doit indiquer à l'intimé, **à peine de nullité** :
- Qu'il s'expose à un arrêt rendu sur les seuls éléments de l'adversaire (s'il ne constitue
  avocat dans les 15 jours)
- Qu'il s'expose à l'irrecevabilité de ses conclusions (s'il ne conclut pas dans le délai art. 909)

**Points d'attention :**
- Le délai d'un mois court à compter de la RÉCEPTION de l'avis du greffe (non de l'envoi)
- La caducité est relevée **d'office** — pas de condition de grief

---

## 3. Articles 542 et 561-562 CPC — Effet dévolutif {#effet-devolutif}

**Art. 542 CPC** : L'appel tend à faire réformer ou annuler par la cour d'appel un jugement
rendu par une juridiction du premier degré.

**Art. 561 CPC** : L'appel remet la chose jugée en question devant la juridiction d'appel
pour qu'il soit à nouveau statué en fait et en droit.

**Art. 562 CPC** : L'appel défère à la cour la connaissance des chefs du jugement qu'il
critique expressément et de ceux qui en dépendent.
- La dévolution ne s'opère que pour les chefs critiqués dans la déclaration d'appel
- Exception : appel en annulation (dévolution intégrale)

**Conséquences pratiques :**
- Les chefs non critiqués dans la déclaration d'appel deviennent **définitifs**
- Impossible d'étendre la dévolution dans les conclusions si absente de la déclaration d'appel
- La reproduction des chefs non critiqués dans la déclaration verrouille définitivement
  l'étendue de la dévolution

---

## 4. Articles 564-566 CPC — Demandes nouvelles en appel {#demandes-nouvelles}

**Art. 564 CPC** : À peine d'irrecevabilité relevée d'office, les parties ne peuvent soumettre
à la cour de nouvelles prétentions si ce n'est pour opposer compensation, faire écarter
les prétentions adverses ou faire juger les questions nées de l'intervention d'un tiers ou
de la survenance ou révélation d'un fait.

**Art. 565 CPC** : Les prétentions ne sont pas nouvelles dès lors qu'elles tendent aux
mêmes fins que celles soumises au premier juge, même si leur fondement juridique est différent.

**Art. 566 CPC** : Les parties peuvent aussi expliciter les prétentions qui étaient
virtuellement comprises dans les demandes et défenses soumises au premier juge et ajouter
à celles-ci toutes les demandes qui en sont l'accessoire, la conséquence ou le complément.

**Points d'attention :**
- L'irrecevabilité des demandes nouvelles est relevée **d'office**
- La demande en compensation est toujours recevable (art. 564)
- Le changement de fondement juridique n'est pas une demande nouvelle (art. 565)

---

## 5. Articles 908-911 CPC — Délais de conclusions {#delais-conclusions}

**Art. 908 CPC — Appelant principal** :
À peine de **caducité de la déclaration d'appel**, relevée d'office, l'appelant dépose et
notifie ses conclusions dans un délai de **3 mois** à compter de la déclaration d'appel.

**Art. 909 CPC — Intimé principal** :
À peine d'**irrecevabilité de ses conclusions**, relevée d'office, l'intimé dépose et notifie
ses conclusions dans un délai de **3 mois** à compter de la notification des conclusions
de l'appelant.
- Le cas échéant, forme son appel incident dans le même délai.

**Art. 910 CPC — Réponse de l'appelant** :
À peine d'**irrecevabilité**, l'appelant dépose et notifie ses conclusions en réponse dans
un délai de **3 mois** à compter de la notification des conclusions de l'intimé.

**Art. 911 CPC — Notification** :
Sous les sanctions des articles 908 à 910, les conclusions sont notifiées aux avocats des
parties dans le délai de leur remise au greffe.

**Tableau récapitulatif :**

| Partie | Point de départ | Délai | Sanction |
|--------|----------------|-------|---------|
| Appelant principal | Déclaration d'appel | 3 mois | Caducité d'office |
| Intimé | Notification concl. appelant | 3 mois | Irrecevabilité d'office |
| Appelant (réponse) | Notification concl. intimé | 3 mois | Irrecevabilité d'office |
| Appel incident (intimé) | Dans le délai art. 909 | 3 mois | Irrecevabilité |

---

## 6. Article 954 CPC — Forme des conclusions d'appel {#art-954}

**Version consolidée**

Les conclusions d'appel comprennent distinctement un exposé des faits et de la procédure,
l'énoncé des chefs de jugement critiqués, une discussion des prétentions et des moyens ainsi
qu'un dispositif récapitulant les prétentions.

**La cour ne statue que sur les prétentions énoncées au dispositif.**

Les parties doivent reprendre, dans leurs dernières conclusions, les prétentions et moyens
précédemment présentés ou invoqués dans leurs conclusions antérieures. À défaut, elles sont
réputées les avoir abandonnés et la cour ne statue que sur les dernières conclusions déposées.

**Mentions obligatoires (à peine d'irrecevabilité) :**
- Identification des parties
- Énoncé des chefs de jugement critiqués
- Discussion des prétentions et moyens
- **Dispositif récapitulatif** de TOUTES les prétentions

**Points d'attention critiques :**
- Une prétention absente du dispositif est considérée abandonnée (Cass. 2e civ., 17 sept. 2020)
- Les conclusions intermédiaires sont abandonnées si non reprises (principe récapitulatif)
- Conserver impérativement la numérotation des pièces si bordereau existant

---

## 7. Article 910-4 CPC — Irrecevabilité des prétentions nouvelles {#art-910-4}

À peine d'irrecevabilité relevée d'office, les parties ne peuvent présenter de nouvelles
prétentions à l'occasion de leurs conclusions en réponse au sens des articles 905-2 et 910 CPC.

Sont néanmoins recevables les prétentions destinées à répliquer aux conclusions et pièces
adverses, à faire juger les questions nées, postérieurement aux premières conclusions, de
l'intervention d'un tiers ou de la survenance ou révélation d'un fait, ainsi que les demandes
reconventionnelles.

---

## 8. Délais d'appel par matière {#delais-appel}

| Matière | Délai | Texte |
|---------|-------|-------|
| Droit commun | 1 mois | Art. 538 CPC |
| Référé | 15 jours | Art. 490 CPC |
| Ordonnance sur requête | 15 jours | Art. 496 CPC |
| Ordonnance JME | 15 jours | Art. 795 CPC |
| Matière gracieuse | 15 jours | Art. 950 CPC |
| Divorce (JAF) | 1 mois | Art. 538 CPC |
| Assistance éducative | 15 jours | Art. 1191 CPC |
| Conseil de prud'hommes | 1 mois | Art. R. 1461-1 Code du travail |
| Tribunal de commerce | 1 mois | Art. 538 CPC |
| Expropriation | 1 mois | Art. R. 311-21 Code expropriation |

**Point de départ** : Notification (signification) du jugement, sauf en matière gracieuse.
**Prorogation** : 2 mois pour parties à l'étranger (art. 643 CPC), 1 mois outre-mer (art. 644 CPC).

---

## 9. Régime des nullités {#nullites}

### Nullités de forme (art. 112-116 CPC)

Applicable aux mentions obligatoires de l'article 901 CPC (« à peine de nullité ») :
- L'irrégularité doit être expressément prévue par un texte ✓
- Ne peut être invoquée que par celui qui la subit (art. 114, al. 1)
- La nullité nécessite la preuve d'un **grief** (art. 114, al. 2)
- Doit être soulevée avant toute défense au fond (art. 112)

### Nullités de fond (art. 117 CPC)

- Défaut de capacité d'ester en justice
- Défaut de pouvoir d'une partie ou de son représentant légal
- Défaut de capacité de l'avocat postulant

Régime : pas de condition de grief, peut être soulevée en tout état de cause, relevée d'office.

### Caducité (art. 908 et 902 CPC)

- Relevée **d'office** par le greffier ou le CME
- Pas de condition de grief
- Rend l'appel non avenu — le jugement de première instance redevient définitif

---

## 10. Jurisprudences de référence {#jurisprudences}

### Déclaration d'appel — Chefs critiqués

- **Cass. 2e civ., 1er juill. 2021, n° 20-10.694** : Précisions sur l'étendue de l'obligation
  de mentionner les chefs du dispositif critiqués — reproduction textuelle obligatoire
- **Cass. 2e civ., 2 juill. 2020, n° 19-16.954** : Sanction du défaut de mention des chefs
  critiqués dans la déclaration d'appel — irrecevabilité des demandes non devoluées
- **Cass. 2e civ., 13 janv. 2022, n° 20-17.516** : Application du principe de dévolution
  limitée aux chefs expressément critiqués
- **Cass. 2e civ., 9 sept. 2021, n° 20-13.673** : Exception en cas d'appel en annulation —
  pas de chefs individuels requis, dévolution intégrale

### Conclusions d'appel — Article 954 CPC

- **Cass. 2e civ., 17 sept. 2020, n° 18-23.626** : La cour ne statue que sur les prétentions
  énoncées au dispositif des conclusions — prétention absente du PAR CES MOTIFS = abandonnée
- **Cass. 2e civ., 3 mars 2022, n° 20-20.390** : Irrecevabilité des demandes nouvelles en appel
  (art. 564 CPC) — relevée d'office
- **Cass. 2e civ., 4 févr. 2021, n° 19-23.305** : Obligation récapitulative des conclusions —
  moyens non repris dans les dernières conclusions réputés abandonnés
- **Cass. 2e civ., 16 déc. 2021, n° 20-16.485** : Non-respect du délai de l'art. 908 CPC —
  caducité relevée d'office, même si l'intimé a constitué avocat

### Signification — Article 902 CPC

- **Cass. 2e civ., 26 juin 2014, n° 13-19.792** : Le délai de signification court à compter de
  la réception de l'avis du greffe par l'avocat de l'appelant, non de l'envoi
- **Cass. 2e civ., 7 janv. 2021, n° 19-25.233** : Caducité d'office sans condition de grief
  en cas de non-respect du délai de signification (art. 902 CPC)

⚠ **RÈGLE ANTI-HALLUCINATION** : Ne citer ces références que si elles sont pertinentes au cas
d'espèce. En cas de doute sur une décision, utiliser la formule « selon la jurisprudence
constante » sans inventer de référence. Vérifier via Lexbase MCP si nécessaire.

---

## 11. Sources et textes de référence {#sources}

### Textes législatifs et réglementaires

- Code de procédure civile, articles 900 à 930-1 (procédure avec représentation obligatoire)
- Article 901 CPC (version consolidée 1er sept. 2024 — Décret n° 2023-1391 du 29 déc. 2023)
- Article 902 CPC (signification et caducité)
- Articles 908-911 CPC (délais de conclusions en appel)
- Article 954 CPC (forme des conclusions d'appel)
- Articles 112-121 CPC (nullités de forme et vices de fond)
- Articles 538-540 CPC (délais d'appel)
- Articles 542, 561-562 CPC (effet dévolutif)
- Articles 564-566 CPC (demandes nouvelles en appel)
- Article 910-4 CPC (irrecevabilité des prétentions nouvelles)
- Article 5 de la loi n° 71-1130 du 31 décembre 1971 (postulation et multipostulation)
- Décret n° 2023-1391 du 29 décembre 2023 (réforme de la procédure d'appel)

### Doctrine

- Guinchard, Chainais, Ferrand, Mayer, Travichon, Douchy-Oudot, Laganier — Droit processuel, Précis Dalloz
- Perrot, Fricero — Procédure civile, PUF
- Cadiet, Jeuland — Droit judiciaire privé, LexisNexis
- Revue de jurisprudence de droit des affaires (RJDA) — chroniques appel civil

---

*Fondements juridiques — Skill procedure-appel-civil — Architecture LAWIA 2026*
*Créé par Maître Patrice Humbert, SELARL LEXVOX AVOCATS & ASSOCIÉS*
