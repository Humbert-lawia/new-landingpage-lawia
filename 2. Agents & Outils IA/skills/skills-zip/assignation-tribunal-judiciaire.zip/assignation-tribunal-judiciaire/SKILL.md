---
name: assignation-tribunal-judiciaire
description: "Rédaction d'assignations en référé et au fond devant le tribunal judiciaire en matière civile. Utiliser SYSTÉMATIQUEMENT dès que l'utilisateur mentionne : rédiger une assignation, assignation en référé, assignation au fond, référé expertise, référé provision, saisir le tribunal judiciaire, acte introductif d'instance, citation en justice, assignation dommage corporel, assignation responsabilité médicale, assignation droit de la consommation, assignation construction, référé article 145 CPC, référé article 834 835 CPC. Applicable au dommage corporel, responsabilité médicale, droit de la consommation, droit de la construction, et droit civil général. Couvre la procédure écrite (>10 000 €) et orale (≤10 000 €), avec ou sans représentation obligatoire. Commandes : /assignation, /refere, /fond. Ne PAS utiliser pour les divorces (convention-divorce-consentement-mutuel ou requete-dvh-jaf), pour les actes devant la cour d'appel (declaration-appel), ni pour les référés administratifs (requete-tribunal-administratif). Architecture LAWIA 2026 — SELARL LEXVOX AVOCATS & ASSOCIÉS."
metadata:
  author: Maître Patrice Humbert — LAWIA
  license: LAWIA Contrat de Licence V1
  version: 2026.04.04
---

# Assignation devant le tribunal judiciaire — Référé et fond

Skill unifié de rédaction d'assignations en référé et au fond devant le tribunal judiciaire, en droit civil, dommage corporel, responsabilité médicale, droit de la consommation et droit de la construction.

---

## Modes opératoires

Deux modes activables par commande ou détection contextuelle :

| Mode | Commande | Déclencheur | Acte produit |
|------|----------|-------------|-------------|
| **Référé** | `/refere` | "référé", "urgence", "référé expertise", "référé provision", "art. 834", "art. 835", "art. 145 CPC" | Assignation en référé devant le président du TJ |
| **Fond** | `/fond` ou `/assignation` | "assignation au fond", "saisine du tribunal", "acte introductif", "assignation", "citation en justice" | Assignation au fond devant le TJ |

Si le mode n'est pas déterminable, poser la question suivante : **« S'agit-il d'une assignation en référé ou au fond ? »** avant toute rédaction.

---

## Matières couvertes

| Matière | Fondements principaux | Spécificités |
|---------|----------------------|-------------|
| **Dommage corporel** | Art. 1240-1242 C. civ., Loi Badinter 5 juill. 1985 | Nomenclature Dintilhac, recours tiers payeurs |
| **Responsabilité médicale** | Art. L.1142-1 s. CSP, Loi Kouchner 4 mars 2002 | Faute/aléa/nosocomial, expertise médicale, ONIAM |
| **Droit de la consommation** | Art. L.211-1 s., L.217-1 s. C. consom. | Garantie conformité, clauses abusives, prescription 2 ans |
| **Droit de la construction** | Art. 1792 s. C. civ., art. L.241-1 s. C. assur. | Garanties décennale/biennale/parfait achèvement, DO |
| **Droit civil général** | Art. 1101 s., 1231-1 s., 1240 s. C. civ. | Responsabilité contractuelle et délictuelle |

**Exclusions** : divorces, droit de la famille (utiliser les skills dédiés), droit pénal, droit administratif.

---

## Étape 1 — Détermination du régime procédural

Avant toute rédaction, déterminer impérativement le régime applicable. Consulter **[references/mentions-obligatoires.md](references/mentions-obligatoires.md)** pour le détail des articles.

### A. Référé ou fond ?

| Critère | Référé | Fond |
|---------|--------|------|
| **Urgence** | Requise (art. 834 CPC) ou non (art. 835 CPC) | Non requise |
| **Juge** | Président du TJ ou juge des contentieux de la protection | Formation collégiale ou juge unique |
| **Objet** | Mesures conservatoires, provision, expertise (art. 145 CPC) | Trancher le litige au principal |
| **Décision** | Ordonnance (provisoire, pas d'autorité de chose jugée au principal) | Jugement (définitif) |
| **Exécution provisoire** | De droit (art. 514 CPC) | De droit sauf exception (art. 514 s. CPC) |

### B. Représentation obligatoire ou non ?

| Situation | Représentation | Article CPC | Mentions assignation |
|-----------|---------------|-------------|---------------------|
| Fond > 10 000 € | **Obligatoire** | Art. 760 | Art. 752 CPC (constitution avocat + délai) |
| Fond ≤ 10 000 € (hors compétence exclusive) | **Non obligatoire** | Art. 761 | Art. 753 CPC (élection domicile + art. 832 + modalités représentation) |
| Référé TJ (matière > 10 000 € ou compétence exclusive) | **Obligatoire** | Art. 760 | Art. 752 CPC |
| Référé TJ (matière ≤ 10 000 € hors compétence exclusive) | **Non obligatoire** | Art. 761 | Art. 753 CPC |
| Matières de compétence exclusive TJ | **Toujours obligatoire** | Art. 760 | Art. 752 CPC |

### C. Procédure écrite ou orale ?

- **Procédure écrite** : représentation obligatoire (art. 760-761 CPC) → assignation avec constitution d'avocat
- **Procédure orale** : représentation non obligatoire → assignation avec mentions art. 753 CPC

---

## Étape 2 — Collecte des informations

Consulter **[references/workflow-collecte.md](references/workflow-collecte.md)** pour le questionnaire détaillé en 7 phases.

Recueillir impérativement :

### Phase 1 : Mode et régime procédural
- Référé ou fond ?
- Matière concernée (dommage corporel, responsabilité médicale, consommation, construction, civil général)
- Montant estimé de la demande (pour déterminer représentation obligatoire/orale)

### Phase 2 : Identification des parties
- Demandeur(s) : état civil complet ou identification personne morale, adresse
- Défendeur(s) : identification complète, adresse, qualité juridique
- Avocats : cabinet, barreau, adresses, toque (plaidant et postulant si applicable)

### Phase 3 : Juridiction et audience
- Tribunal judiciaire compétent (ville)
- Date, heure, salle d'audience (si connues)
- Formation saisie (référés, pôle civil section X, JCP)

### Phase 4 : Éléments factuels
- Chronologie détaillée des faits
- Date(s) de l'événement générateur
- Circonstances précises et évolution
- Démarches précontentieuses (mise en demeure, expertise amiable, CRCI, médiation)

### Phase 5 : Fondements juridiques
- Articles de loi applicables
- Jurisprudences pertinentes (si fournies par l'utilisateur)
- Rapport d'expertise (judiciaire ou amiable) si disponible
- Date de consolidation (dommage corporel)

### Phase 6 : Préjudices et demandes
- Nature et quantum de chaque chef de préjudice (nomenclature Dintilhac si dommage corporel)
- Montant total demandé
- Demandes accessoires (exécution provisoire, art. 700 CPC, dépens)
- En référé : objet précis de la mesure sollicitée (expertise, provision, etc.)

### Phase 7 : Pièces justificatives
- Liste des pièces versées aux débats avec désignation précise
- Checklist des pièces indispensables selon la matière (voir workflow-collecte.md)

---

## Étape 3 — Lecture des références

**OBLIGATOIRE — Lire intégralement dans cet ordre :**

1. `references/mentions-obligatoires.md` : mentions légales selon le régime procédural
2. `references/structure-assignation.md` : architecture détaillée selon référé ou fond
3. `references/formules-types.md` : vocabulaire, expressions consacrées, style judiciaire
4. `references/variantes-matieres.md` : adaptations par matière (dommage corporel, médical, consommation, construction)
5. `/mnt/skills/public/docx/SKILL.md` : guide de création du fichier Word final

**Ne jamais limiter la lecture à une plage de lignes. Lire l'intégralité de chaque fichier.**

---

## Étape 4 — Structure de l'acte

### Structure de l'assignation en référé

Consulter `references/structure-assignation.md` section « RÉFÉRÉ » pour le template complet.

Architecture en 6 parties :
1. **En-tête** : identification cabinet, titre « ASSIGNATION EN RÉFÉRÉ DEVANT M. LE PRÉSIDENT DU TRIBUNAL JUDICIAIRE DE [VILLE] », formule d'ouverture
2. **Identification des parties** : demandeur, avocat(s), formule commissaire de justice, défendeur(s), convocation
3. **Mentions obligatoires** : selon le régime procédural déterminé à l'étape 1 (voir mentions-obligatoires.md)
4. **Corps** :
   - I. Rappel des faits et de la procédure
   - II. Discussion juridique (fondement du référé + objet de la mesure)
   - III. Sur l'article 700 CPC et les dépens
5. **Dispositif** : « PAR CES MOTIFS » — demandes structurées
6. **Bordereau de pièces**

### Structure de l'assignation au fond

Consulter `references/structure-assignation.md` section « FOND » pour le template complet.

Architecture en 7 parties :
1. **En-tête** : identification cabinet, titre « ASSIGNATION DEVANT LE TRIBUNAL JUDICIAIRE DE [VILLE] », formule d'ouverture
2. **Identification des parties** : demandeur, avocat(s), formule commissaire de justice, défendeur(s), convocation
3. **Mentions obligatoires** : selon le régime procédural (voir mentions-obligatoires.md)
4. **Corps** :
   - I. Rappel des faits et de la procédure
   - II. Discussion juridique — moyens structurés (en droit / en l'espèce)
   - III. Tableau récapitulatif des préjudices (si dommage corporel)
   - IV. Sur l'exécution provisoire (art. 514 s. CPC)
   - V. Frais irrépétibles et dépens
5. **Dispositif** : « PAR CES MOTIFS / PLAISE AU TRIBUNAL »
6. **Bordereau de pièces**

---

## Étape 5 — Style et rédaction

### Principes rédactionnels

**Vocabulaire et ton** — Registre Badinter :
- Vocabulaire juridique rigoureux, précis, varié
- Phrases structurées avec subordonnées — alternance longueur
- Formules consacrées du style judiciaire français classique (cf. formules-types.md)
- Ton mesuré, respectueux mais ferme — affirmations étayées
- Absence de polémique gratuite

**Architecture argumentaire** :
- Progression logique : faits → droit → application → conclusion
- Hiérarchisation des moyens (principal, subsidiaire, plus subsidiaire)
- Syllogisme juridique complet pour chaque moyen : majeure (règle de droit) → mineure (faits d'espèce) → conclusion
- Anticipation des objections adverses

**Citations et références** :
- Citation exacte des textes légaux (article, alinéa, code, version en vigueur)
- Référence complète des jurisprudences (juridiction, chambre, date, n° pourvoi/RG)
- Renvoi aux pièces pour chaque fait allégué (« ainsi qu'en atteste la pièce n° X »)

**Adaptations par matière** : consulter `references/variantes-matieres.md`

---

## Étape 6 — Création du fichier Word

**Créer impérativement un fichier .docx** (ne pas se contenter d'un rendu textuel).

Workflow de création :
1. Lire intégralement `/mnt/skills/public/docx/SKILL.md`
2. Créer le document avec docx-js
3. Appliquer le formatage : marges 2,5 cm, Times New Roman ou Garamond 12, interligne 1,15 ou 1,5, titres en gras et soulignés, citations en italique, numérotation des pages
4. Sauvegarder dans `/mnt/user-data/outputs/`
5. Présenter le fichier avec `present_files`

---

## Étape 7 — Vérification finale

Consulter **[references/checklist-verification.md](references/checklist-verification.md)** pour la checklist granulaire complète.

### Vérifications impératives

**Complétude formelle** :
- ✓ Toutes les mentions obligatoires selon le régime procédural sont présentes
- ✓ L'identification des parties est complète
- ✓ Les articles de loi sont correctement cités
- ✓ Le bordereau de pièces est cohérent avec les renvois dans le texte

**Cohérence juridique** :
- ✓ Les fondements du référé (art. 834/835/145 CPC) ou du fond sont correctement visés
- ✓ L'argumentation suit une logique syllogistique
- ✓ Les demandes du dispositif correspondent aux développements
- ✓ Le quantum est justifié

**Qualité rédactionnelle** :
- ✓ Vocabulaire juridiquement rigoureux
- ✓ Style conforme aux standards de la profession
- ✓ Transitions fluides — formatage professionnel

---

## Règles impératives

**NE JAMAIS :**
- Omettre les mentions légales obligatoires
- Confondre les mentions art. 752 (représentation obligatoire) et art. 753 (non obligatoire)
- Inventer des jurisprudences ou des références inexistantes
- Employer un langage familier ou approximatif
- Livrer un texte sans créer le fichier .docx
- Appliquer les formules du tribunal de commerce (art. 853, 861-2, 873 CPC) au tribunal judiciaire

**TOUJOURS :**
- Déterminer le régime procédural AVANT de rédiger
- Lire intégralement les références avant de rédiger
- Vérifier la cohérence entre les développements et le dispositif
- Citer les sources légales et jurisprudentielles
- Justifier chaque demande chiffrée
- Placer le fichier final dans `/mnt/user-data/outputs/`

---

## Ressources disponibles

- `references/mentions-obligatoires.md` : Mentions légales selon le régime procédural (référé/fond, avec/sans représentation obligatoire)
- `references/structure-assignation.md` : Architecture complète en référé et au fond
- `references/formules-types.md` : Vocabulaire, expressions consacrées, style judiciaire
- `references/variantes-matieres.md` : Adaptations par matière (dommage corporel, médical, consommation, construction)
- `references/workflow-collecte.md` : Questionnaire de collecte en 7 phases
- `references/checklist-verification.md` : Contrôle qualité granulaire avant livraison
- `references/jurisprudence-reference.md` : Jurisprudences types par matière

**Note** : Pour les actes devant la Cour d'appel → skill `declaration-appel`. Pour les divorces → skill `convention-divorce-consentement-mutuel`. Pour le droit administratif → skill `requete-tribunal-administratif`.
