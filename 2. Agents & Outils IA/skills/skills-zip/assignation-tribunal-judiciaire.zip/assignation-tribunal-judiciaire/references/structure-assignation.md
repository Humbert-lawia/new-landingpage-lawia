# Structure de l'assignation devant le tribunal judiciaire

## Table des matières

1. [Structure commune — En-tête et identification](#structure-commune)
2. [Structure RÉFÉRÉ](#structure-référé)
3. [Structure FOND](#structure-fond)
4. [Formules du dispositif](#formules-du-dispositif)
5. [Bordereau de pièces](#bordereau-de-pièces)

---

## Structure commune — En-tête et identification

### 1. En-tête de l'acte

#### 1.1 Référence du dossier
```
## [INITIALES AVOCAT]/ [INITIALES CLIENT] - [NUMÉRO DOSSIER]/ [INITIALES]
```

#### 1.2 Identification du cabinet
```
**SELARL LEXVOX AVOCATS & ASSOCIÉS**

Maître [PRÉNOM NOM]
Avocat spécialisé en [SPÉCIALITÉ]
[Adresse complète]
Tél : [téléphone] — Email : [email]
```

#### 1.3 Titre de l'acte

**En référé :**
```
**ASSIGNATION EN RÉFÉRÉ
DEVANT MADAME OU MONSIEUR LE PRÉSIDENT
DU TRIBUNAL JUDICIAIRE DE [VILLE]
(Article [834 / 835 / 145] du Code de procédure civile)**
```

**Au fond :**
```
**ASSIGNATION DEVANT LE TRIBUNAL JUDICIAIRE DE [VILLE]**
```

Suivi du numéro de RG provisoire si connu :
`N° RG provisoire : [NUMÉRO]`

#### 1.4 Formule d'ouverture
```
**L'AN deux mille [année en lettres] et le**
```

### 2. Identification des parties

#### 2.1 Le demandeur

```
**A LA DEMANDE DE :**

**Madame/Monsieur [PRÉNOM NOM]**, né(e) le [date] à [ville (code postal)],
de nationalité [nationalité], [profession], [situation familiale],
demeurant [adresse complète]

[Pour une personne morale :]
La société [DÉNOMINATION], [forme juridique] au capital de [montant] euros,
immatriculée au RCS de [ville] sous le numéro [RCS], dont le siège social
est sis [adresse complète], prise en la personne de son représentant légal
en exercice, domicilié en cette qualité audit siège.
```

#### 2.2 Avocat(s)

**Si représentation obligatoire :**
```
**Ayant pour avocat plaidant :**
[SELARL/Maître] [Prénom NOM], Avocat au Barreau de [Ville],
[Adresse complète]
Tél : [téléphone] — Email : [email] — Toque : [numéro]

**Ayant pour avocat postulant :** [si barreau différent]
Maître [Prénom NOM], Avocat au Barreau de [Ville],
[Adresse]
Qui se constitue et occupera pour lui/elle sur la présente assignation et ses suites.
```

**Si représentation non obligatoire et avocat :**
```
**Ayant pour avocat :**
[SELARL/Maître] [Prénom NOM], Avocat au Barreau de [Ville],
[Adresse complète]
```

#### 2.3 Formule du commissaire de justice
```
**J'AI, COMMISSAIRE DE JUSTICE DÉSIGNÉ,**

**L'HONNEUR D'INFORMER**
```

#### 2.4 Le(s) défendeur(s)

Numérotation pour chaque défendeur : **1/** **2/** etc.

```
**1/** [Identification complète du défendeur — personne physique ou morale]
[Adresse complète]
[Pour les personnes morales :] Prise en la personne de son représentant légal
y domicilié.
```

#### 2.5 Formule de transition

**En référé :**
```
Qu'il(s)/elle(s) est(sont) convoqué(e)(s) devant Madame ou Monsieur le Président
du Tribunal Judiciaire de [VILLE], statuant en référé, siégeant en ladite ville,
[adresse du tribunal]
```

**Au fond :**
```
Qu'un procès lui (leur) est intenté pour les raisons ci-après exposées devant
le Tribunal Judiciaire de [VILLE], siégeant en ladite ville, [adresse du tribunal]
```

### 3. Convocation à l'audience

**En référé :**
```
**À l'audience de référé qui se tiendra le [DATE] à [HEURE]**
[Adresse du tribunal — Salle si connue]
```

**Au fond :**
```
**À l'audience du Pôle Civil Section [X] qui se tiendra le [DATE] à [HEURE]
(salle [nom de salle])**
```

### 4. Mentions obligatoires

**→ Insérer ici les mentions correspondant au régime procédural déterminé.**
Consulter impérativement `references/mentions-obligatoires.md` pour le texte exact des avertissements selon :
- Représentation obligatoire (art. 752 CPC) → version « constitution d'avocat obligatoire »
- Représentation non obligatoire (art. 753 CPC) → version « comparution avec ou sans avocat »

---

## Structure RÉFÉRÉ

### Corps de l'assignation en référé

#### Formule d'ouverture
```
PLAISE À MADAME OU MONSIEUR LE PRÉSIDENT
```

#### I. Rappel des faits

Narration chronologique, factuelle et précise :
- Circonstances de l'événement générateur
- Déroulement des faits
- Conséquences immédiates
- Démarches entreprises (médicales, amiables, expertise)
- Justification de la saisine en référé

Style : factuel, daté, précis. Chaque fait important est accompagné d'un renvoi à une pièce.

#### II. Discussion juridique

**Structure en trois temps :**

##### A. Sur la compétence du juge des référés

Selon le fondement :

**Article 145 CPC (référé expertise / mesure d'instruction in futurum) :**
```
En droit :
L'article 145 du Code de procédure civile dispose :
« S'il existe un motif légitime de conserver ou d'établir avant tout procès la
preuve de faits dont pourrait dépendre la solution d'un litige, les mesures
d'instruction légalement admissibles peuvent être ordonnées à la demande de
tout intéressé, sur requête ou en référé. »

En l'espèce :
[Démontrer le motif légitime — exposer les faits justifiant la mesure]
[Démontrer qu'aucune instance au fond n'est en cours sur le même objet]
```

**Article 834 CPC (référé urgence) :**
```
En droit :
L'article 834 du Code de procédure civile dispose :
« Dans tous les cas d'urgence, le président du tribunal judiciaire ou le juge
des contentieux de la protection dans les limites de sa compétence, peuvent
ordonner en référé toutes les mesures qui ne se heurtent à aucune contestation
sérieuse ou que justifie l'existence d'un différend. »

En l'espèce :
[Caractériser l'urgence — exposer les circonstances]
[Démontrer l'absence de contestation sérieuse]
```

**Article 835 alinéa 1 CPC (trouble manifestement illicite / dommage imminent) :**
```
En droit :
L'article 835 alinéa 1er du Code de procédure civile dispose :
« Le président du tribunal judiciaire ou le juge des contentieux de la protection
dans les limites de sa compétence peuvent toujours, même en présence d'une
contestation sérieuse, prescrire en référé les mesures conservatoires ou de
remise en état qui s'imposent, soit pour prévenir un dommage imminent, soit
pour faire cesser un trouble manifestement illicite. »

En l'espèce :
[Caractériser le trouble manifestement illicite ou le dommage imminent]
```

**Article 835 alinéa 2 CPC (référé provision) :**
```
En droit :
L'article 835 alinéa 2 du Code de procédure civile dispose :
« Dans les cas où l'existence de l'obligation n'est pas sérieusement contestable,
[le président] peut accorder une provision au créancier, ou ordonner l'exécution
de l'obligation même s'il s'agit d'une obligation de faire. »

En l'espèce :
[Démontrer que l'obligation n'est pas sérieusement contestable]
[Chiffrer la provision demandée]
```

##### B. Sur le fond de la demande (adapté à la matière)

Développer les moyens juridiques spécifiques à la matière (voir variantes-matieres.md).

##### C. Sur l'article 700 CPC et les dépens

```
Il serait inéquitable de laisser à la charge du requérant les frais irrépétibles
qu'il a dû exposer pour la préservation de ses droits, ce qui justifie la
condamnation de [DÉFENDEUR] à lui verser la somme de [montant] € au titre
de l'article 700 du Code de procédure civile.
```

#### Dispositif du référé

```
PAR CES MOTIFS,

Vu l'article [834 / 835 / 145] du Code de procédure civile,
[Vu les textes spécifiques à la matière],
Vu les pièces versées aux débats,

Il est demandé à Madame ou Monsieur le Président du Tribunal Judiciaire
de [VILLE], statuant en référé, de :

[DEMANDES — voir formules du dispositif ci-dessous]

CONDAMNER [DÉFENDEUR] à payer à [DEMANDEUR] la somme de [montant] €
au titre de l'article 700 du Code de procédure civile

CONDAMNER [DÉFENDEUR] aux dépens

SOUS TOUTES RÉSERVES
```

---

## Structure FOND

### Corps de l'assignation au fond

#### Formule d'ouverture
```
PLAISE AU TRIBUNAL
```

#### I. Rappel des faits et de la procédure

Narration chronologique complète :
- Circonstances de l'événement générateur (dates, lieux, contexte)
- Déroulement des faits
- Conséquences immédiates et différées
- Démarches précontentieuses (mises en demeure, expertises, saisines)
- Procédure de référé antérieure (si applicable)
- Résultat de l'expertise (si applicable)
- Tentative de résolution amiable (si obligatoire)

#### II. Discussion juridique (EN DROIT)

Organisation par moyens juridiques principaux. Pour chaque moyen :

##### Structure d'un moyen

**A. Intitulé du moyen** — souligné et mis en évidence
Exemple : `**Sur la responsabilité de [DÉFENDEUR]**`

**B. Rappel du cadre légal** — citation des textes
```
L'article [numéro] du [Code] dispose :
« [texte de l'article] »
```

**C. Rappel du cadre jurisprudentiel**
```
La Cour de cassation, [chambre], dans un arrêt du [date], n° [pourvoi], a jugé que :
« [principe dégagé] »
```

**D. Application au cas d'espèce** — syllogisme juridique
```
En l'espèce, [rappel des faits pertinents].
Il résulte de ces éléments que [application de la règle de droit aux faits].
Par conséquent, [conclusion juridique].
```

**E. Pour les préjudices corporels** — un développement par poste Dintilhac :
- Définition du poste de préjudice
- Cotation par l'expert / éléments de preuve
- Évaluation motivée du quantum
- Référence aux barèmes et jurisprudences indicatives

#### III. Tableau récapitulatif des préjudices (dommage corporel)

```
EN CONCLUSION — TABLEAU RÉCAPITULATIF DES POSTES DE PRÉJUDICE

| Poste de préjudice | Montant demandé |
|---------------------|-----------------|
| DFT total (X jours) | X € |
| DFT partiel (X jours) | X € |
| Souffrances endurées (X/7) | X € |
| DFP (X %) | X € |
| ... | ... |
| **TOTAL** | **X €** |
```

#### IV. Sur l'exécution provisoire

```
En tout état de cause, sur l'exécution provisoire :

L'article 514 du Code de procédure civile dispose que les décisions de première
instance sont de droit exécutoires à titre provisoire, à moins que la loi ou la
décision rendue n'en dispose autrement.

Il n'existe en l'espèce aucun motif de nature à justifier l'écart de ce principe.
```

#### V. Frais irrépétibles et dépens

```
Il serait inéquitable de laisser à la charge du requérant les frais irrépétibles
qu'il a dû exposer, ce qui conduira le Tribunal à condamner [DÉFENDEUR(S)] à lui
verser la somme de [montant] € au titre de l'article 700 du Code de procédure civile.

[DÉFENDEUR(S)] sera(ont) en outre condamné(s) aux entiers dépens, en ce compris les
frais d'expertise judiciaire.
```

#### Dispositif au fond

```
PAR CES MOTIFS,

PLAISE AU TRIBUNAL

Vu les dispositions de [textes applicables],
Vu les jurisprudences citées,
Vu le rapport d'expertise [si applicable],
Vu les pièces produites,

Faisant corps avec le présent dispositif, et tous autres à suppléer si besoin est,

[DEMANDES — voir formules du dispositif ci-dessous]

SOUS TOUTES RÉSERVES

DONT ACTE
```

---

## Formules du dispositif

### Demandes principales — Fond

```
DIRE et JUGER [DEMANDEUR] recevable et bien fondé(e) en l'ensemble de ses demandes

DIRE et JUGER que la responsabilité de [DÉFENDEUR] est engagée [fondement juridique]

[Si expertise :] HOMOLOGUER le rapport d'expertise du [expert] en date du [date]

[Si consolidation :] Fixer la date de consolidation au [date]

EN CONSÉQUENCE,

CONDAMNER [solidairement / in solidum] [DÉFENDEUR(S)] à payer à [DEMANDEUR]
la somme totale de [MONTANT] euros décomposée comme suit :
[détail des postes si nécessaire]

JUGER que les sommes d'ores et déjà exigibles s'entendent en deniers ou quittances,
les provisions allouées devant être déduites

JUGER que les condamnations porteront intérêts au taux légal à compter du jugement
à intervenir

ORDONNER la capitalisation des intérêts conformément à l'article 1343-2 du Code civil
```

### Demandes accessoires

```
FIXER la créance de [ORGANISME SOCIAL] selon les justificatifs produits

DÉCLARER le jugement commun à [TIERS INTÉRESSÉ]

CONDAMNER [solidairement / in solidum] [DÉFENDEUR(S)] à payer au requérant
la somme de [montant] € au titre des frais irrépétibles (article 700 CPC)

CONDAMNER [solidairement / in solidum] [DÉFENDEUR(S)] aux entiers dépens,
en ce compris les frais d'expertise [judiciaire / amiable]
```

---

## Bordereau de pièces

```
PIÈCES VERSÉES AUX DÉBATS

Pièce 1 : [Désignation complète avec date]

Pièce 2 : [Désignation complète avec date]

Pièce 3 : [Désignation complète avec date]

[...]

SOUS TOUTES RÉSERVES
```

**Règles de numérotation :**
- Numérotation continue et séquentielle
- Désignation précise et datée de chaque pièce
- Cohérence entre les renvois dans le corps de l'assignation et le bordereau
- Les pièces sont classées dans un ordre logique (identité → faits → preuve → préjudice → procédure)
