# Workflow de collecte d'informations — Assignation TJ

## Table des matières

1. [Phase 1 : Mode et régime procédural](#phase-1)
2. [Phase 2 : Identification des parties](#phase-2)
3. [Phase 3 : Juridiction et audience](#phase-3)
4. [Phase 4 : Éléments factuels](#phase-4)
5. [Phase 5 : Fondements juridiques et expertise](#phase-5)
6. [Phase 6 : Préjudices et demandes](#phase-6)
7. [Phase 7 : Pièces justificatives](#phase-7)

---

## Phase 1 : Mode et régime procédural

**Questions préliminaires impératives :**

1. **S'agit-il d'une assignation en référé ou au fond ?**
   - Référé : quelle mesure est sollicitée ? (expertise art. 145 CPC, provision art. 835 al. 2, mesure conservatoire art. 834, cessation de trouble art. 835 al. 1)
   - Fond : action au principal après expertise, action directe, etc.

2. **Quelle est la matière concernée ?**
   - Dommage corporel (accident de la circulation, accident de la vie, agression)
   - Responsabilité médicale (faute, aléa, infection nosocomiale, défaut d'information)
   - Droit de la consommation (conformité, vices cachés, clauses abusives)
   - Droit de la construction (garantie décennale, biennale, parfait achèvement, dommage ouvrage)
   - Droit civil général (responsabilité contractuelle ou délictuelle)

3. **Quel est le montant estimé de la demande ?**
   - > 10 000 € : représentation obligatoire (art. 760 CPC)
   - ≤ 10 000 € : représentation non obligatoire sauf compétence exclusive (art. 761 CPC)
   - Demande indéterminée : vérifier si l'obligation dont elle résulte excède ou non 10 000 €

4. **La matière relève-t-elle de la compétence exclusive du TJ ?**
   - Si oui : représentation obligatoire quel que soit le montant

---

## Phase 2 : Identification des parties

5. **Qui est le demandeur ?**
   - Personne physique : civilité, prénom, NOM, date et lieu de naissance, nationalité, profession, situation familiale, adresse complète
   - Personne morale : forme juridique, dénomination, capital, RCS, siège social, représentant légal
   - Pluralité de demandeurs : identifier chacun

6. **Qui est (sont) le(s) défendeur(s) ?**
   - Mêmes informations que pour le demandeur
   - Qualité juridique (responsable, assureur, organisme, etc.)
   - En responsabilité médicale : praticien + établissement + assureur
   - En accident circulation : conducteur + propriétaire + assureur
   - En construction : entrepreneur + sous-traitant + maître d'œuvre + assureur DO/décennale
   - En consommation : vendeur/prestataire professionnel

7. **Identification des avocats ?**
   - Avocat plaidant : nom, prénom, structure (SELARL, etc.), barreau, adresse, toque, téléphone, email
   - Avocat postulant (si barreau différent) : mêmes informations
   - Si représentation non obligatoire et pas d'avocat : indiquer le nom du représentant éventuel

---

## Phase 3 : Juridiction et audience

8. **Quel tribunal judiciaire est compétent ?**
   - Lieu du domicile du défendeur (règle générale, art. 42 CPC)
   - Lieu du fait dommageable ou du préjudice (option en matière délictuelle, art. 46 CPC)
   - Lieu d'exécution du contrat (option en matière contractuelle, art. 46 CPC)
   - Clause attributive de compétence (si applicable entre professionnels)
   - Compétence du JCP (si ancienne compétence TI et matière spéciale)

9. **Date et heure d'audience ?**
   - Si connues : préciser date, heure, salle
   - En référé : vérifier le calendrier des audiences de référé du tribunal
   - En fond : prise de date selon l'article 751 CPC (placement puis audience d'orientation)

10. **Formation saisie ?**
    - Référé : « Madame ou Monsieur le Président du Tribunal Judiciaire de [Ville], statuant en référé »
    - Fond : Pôle civil, section, chambre (si connus)
    - JCP : juge des contentieux de la protection (ancienne compétence TI)

---

## Phase 4 : Éléments factuels

11. **Quelle est la chronologie détaillée des faits ?**
    - Date et circonstances précises de l'événement générateur
    - Description factuelle chronologique
    - Évolution de la situation depuis l'événement
    - Conséquences immédiates et différées

12. **Quelles démarches précontentieuses ont été entreprises ?**
    - Mise(s) en demeure (dates, contenu, réponses)
    - Expertise amiable ou judiciaire (dates, expert, conclusions)
    - Saisine d'un organisme (CRCI, CCI, médiateur, conciliateur)
    - Tentative de résolution amiable (obligatoire au fond pour demandes ≤ 5 000 €)
    - Courriers d'assurance (offre / refus d'offre)

13. **Le défendeur a-t-il contesté sa responsabilité ?**
    - Si oui : nature et contenu de la contestation
    - Si non : absence de réponse aux relances
    - Si partiellement : éléments reconnus et éléments contestés

---

## Phase 5 : Fondements juridiques et expertise

14. **Quels sont les fondements juridiques de l'action ?**
    - Articles de loi applicables
    - Loi spéciale applicable (loi Badinter, loi Kouchner, code de la consommation, etc.)
    - Régime de responsabilité (contractuelle / délictuelle / spéciale)

15. **Existe-t-il un rapport d'expertise ?**
    - Expertise judiciaire ou amiable ?
    - Conclusions principales de l'expert
    - Date de consolidation (dommage corporel)
    - Taux de DFP, cotation des souffrances, préjudice esthétique
    - Imputabilité retenue par l'expert
    - Faute retenue ou écartée (responsabilité médicale)
    - Désordres constatés (construction)
    - Non-conformité constatée (consommation)

16. **L'utilisateur dispose-t-il de jurisprudences pertinentes ?**
    - Si oui : les répertorier pour intégration
    - Si non : utiliser les jurisprudences de référence (voir jurisprudence-reference.md) et/ou rechercher via Lexbase/OpenLegi

---

## Phase 6 : Préjudices et demandes

17. **En référé — Quelle mesure est sollicitée ?**
    - Expertise médicale / technique (art. 145 CPC) : mission de l'expert demandée
    - Provision (art. 835 al. 2 CPC) : montant de la provision sollicitée et justification
    - Mesure conservatoire (art. 834 CPC) : nature de la mesure
    - Cessation de trouble (art. 835 al. 1 CPC) : description du trouble

18. **Au fond — Quels préjudices sont invoqués ?**

    *Dommage corporel (nomenclature Dintilhac) :*
    - Préjudices patrimoniaux temporaires : DSA, FD, PGPF avant consolidation
    - Préjudices patrimoniaux permanents : DSF, FLA, PGPF après consolidation, IP, frais de véhicule adapté, frais de logement adapté
    - Préjudices extra-patrimoniaux temporaires : DFT, SE, PET
    - Préjudices extra-patrimoniaux permanents : DFP, PA, PEP, préjudice sexuel, préjudice d'établissement
    - Préjudices des proches : préjudice d'affection, préjudice d'accompagnement

    *Consommation :*
    - Remboursement du prix, remplacement, réparation
    - Dommages-intérêts complémentaires
    - Préjudice de jouissance

    *Construction :*
    - Coût des travaux de reprise
    - Préjudice de jouissance
    - Préjudice immatériel consécutif

19. **Quelles sont les demandes accessoires ?**
    - Exécution provisoire (art. 514 CPC — de droit, mais motivation si contestée)
    - Article 700 CPC : montant demandé
    - Dépens (y compris frais d'expertise le cas échéant)
    - Intérêts au taux légal (point de départ)
    - Capitalisation des intérêts (anatocisme, art. 1343-2 C. civ.)
    - Créance du tiers payeur (CPAM, mutuelle, employeur)

---

## Phase 7 : Pièces justificatives

20. **Quels documents sont disponibles ?**

    **Pièces communes à toutes les matières :**
    - [ ] Pièce d'identité du demandeur
    - [ ] Mise(s) en demeure
    - [ ] Correspondances échangées
    - [ ] Justificatifs de préjudice

    **Pièces spécifiques — Dommage corporel :**
    - [ ] Rapport d'expertise (judiciaire ou amiable)
    - [ ] Certificats médicaux (initial + évolutifs)
    - [ ] Justificatifs de frais médicaux (DSA, frais restés à charge)
    - [ ] Attestation de la CPAM (créance définitive)
    - [ ] Avis d'arrêt de travail / attestations employeur
    - [ ] Justificatifs tierce personne
    - [ ] Avis d'imposition (PGPF)
    - [ ] Factures (logement adapté, véhicule adapté)
    - [ ] Attestations de proches (préjudice d'affection)
    - [ ] Constat amiable / procès-verbal (accident circulation)

    **Pièces spécifiques — Responsabilité médicale :**
    - [ ] Dossier médical complet
    - [ ] Rapport d'expertise
    - [ ] Avis CCI/CRCI (si applicable)
    - [ ] Correspondance avec l'ONIAM (si applicable)

    **Pièces spécifiques — Consommation :**
    - [ ] Contrat / bon de commande / facture d'achat
    - [ ] CGV du professionnel
    - [ ] Preuves du défaut de conformité (photos, rapports, constats)
    - [ ] Courrier de mise en œuvre de la garantie
    - [ ] Devis de remplacement / réparation

    **Pièces spécifiques — Construction :**
    - [ ] Contrat de construction / marché de travaux
    - [ ] Procès-verbal de réception (avec ou sans réserves)
    - [ ] Rapport d'expertise (judiciaire ou amiable)
    - [ ] Attestation d'assurance décennale du constructeur
    - [ ] Attestation d'assurance dommage-ouvrage
    - [ ] Photos des désordres
    - [ ] Devis de reprise
