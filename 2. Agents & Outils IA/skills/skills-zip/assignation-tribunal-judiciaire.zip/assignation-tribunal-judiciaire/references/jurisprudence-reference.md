# Jurisprudences et principes juridiques de référence

## Avertissement

Les jurisprudences citées dans ce document sont des exemples types fréquemment utilisés en matière de dommage corporel et de responsabilité médicale. Lors de la rédaction d'une assignation, il convient toujours de :
- Vérifier l'actualité des jurisprudences citées
- Rechercher des jurisprudences plus récentes si disponibles
- Adapter les références au cas d'espèce spécifique
- Ne jamais inventer de jurisprudences inexistantes

## Responsabilité médicale - Principes généraux

### Fondement de la responsabilité
**Loi Kouchner du 4 mars 2002**
Codifiée aux articles L.1142-1 et suivants du Code de la santé publique

Principe : La responsabilité des professionnels de santé est engagée en cas de faute médicale, défaut d'information ou infection nosocomiale.

### Obligation de moyens
**Cass. 1re civ., 20 mai 1936, Mercier**
Le contrat médical comporte pour le praticien l'engagement de donner des soins consciencieux, attentifs et conformes aux données acquises de la science, sans garantir la guérison.

**Cass. 1re civ., 25 février 1997, n° 94-19.685**
La responsabilité du médecin ne peut être retenue que s'il est établi que le praticien a commis une faute dans l'exécution de son obligation de moyens.

### Obligation d'information
**Cass. 1re civ., 25 février 1997, arrêt Hédreul**
Principe de l'obligation d'information du patient sur les risques graves inhérents aux actes médicaux, même exceptionnels.

**Cass. 1re civ., 7 octobre 1998, n° 97-11.044**
Le défaut d'information cause au patient un préjudice distinct de celui résultant de la réalisation du risque, qui doit être réparé.

**Loi du 4 mars 2002, article L.1111-2 CSP**
Toute personne a le droit d'être informée sur son état de santé et sur les risques fréquents ou graves des investigations, traitements ou actions de prévention proposés.

### Perte de chance
**Cass. 1re civ., 17 novembre 1982**
La perte de chance constitue un préjudice distinct et autonome réparable lorsqu'il est démontré que la faute a fait perdre une chance réelle de survie ou de guérison.

**Cass. 1re civ., 14 octobre 2010, n° 09-69.195**
L'évaluation de la perte de chance doit tenir compte du pourcentage de chances perdues, sans pour autant procéder à une réparation intégrale du dommage final.

## Dommage corporel - Nomenclature Dintilhac

### Principes généraux
La nomenclature Dintilhac, élaborée en 2005, constitue la référence pour l'évaluation des préjudices corporels.

**Distinction fondamentale**
- Préjudices patrimoniaux (économiques)
- Préjudices extrapatrimoniaux (non économiques)
- Préjudices temporaires (avant consolidation)
- Préjudices permanents (après consolidation)

### Déficit fonctionnel temporaire (DFT)
**Cass. 2e civ., 28 mai 2009, n° 08-16.829**
Le déficit fonctionnel temporaire indemnise la perte de qualité de vie et les troubles ressentis durant la maladie traumatique. Il inclut l'hospitalisation, les souffrances physiques et morales, et la gêne dans les actes de la vie courante.

Evaluation : Généralement entre 20 et 40 euros par jour selon l'intensité du déficit.

### Souffrances endurées
**Echelle de 0/7 à 7/7**
Codification internationale des souffrances physiques et psychiques endurées durant la maladie traumatique.

**Jurisprudence constante**
L'évaluation se fait sur la base d'une échelle médicale objective, confirmée par l'expert judiciaire.

Barèmes indicatifs :
- 0/7 à 1/7 : 1 500 à 3 000 euros
- 2/7 : 3 000 à 8 000 euros
- 3/7 : 8 000 à 15 000 euros
- 4/7 : 15 000 à 30 000 euros
- 5/7 et au-delà : évaluation au cas par cas

### Préjudice esthétique temporaire et permanent
**Echelle de 0/7 à 7/7**
Evaluation du préjudice résultant de l'altération de l'apparence physique.

**Cass. 2e civ., 19 juin 2003, n° 01-13.327**
Le préjudice esthétique constitue un chef de préjudice distinct et autonome qui doit être indemnisé indépendamment du déficit fonctionnel.

Barèmes indicatifs :
- 1/7 : 1 500 à 3 000 euros
- 2/7 : 3 000 à 8 000 euros
- 3/7 : 8 000 à 15 000 euros
- 4/7 : 15 000 à 30 000 euros
- 5/7 et au-delà : évaluation individualisée

### Déficit fonctionnel permanent (DFP)
**Anciennement AIPP (Atteinte à l'Intégrité Physique et Psychique)**

**Cass. 2e civ., 6 novembre 2014, n° 13-24.144**
Le déficit fonctionnel permanent indemnise les atteintes aux fonctions physiologiques et les préjudices d'agrément liés aux loisirs et activités spécifiques.

**Méthode d'évaluation**
Capitalisation selon le taux d'IPP, l'âge de la victime et le barème de capitalisation en vigueur.

Points de capitalisation (référence Gazette du Palais) :
- Variable selon l'âge de consolidation
- Multiplicateur appliqué au taux d'IPP
- Valeur du point généralement entre 1 500 et 2 000 euros

### Préjudice professionnel
**Cass. 2e civ., 22 novembre 2012, n° 11-24.09**
L'incidence professionnelle constitue un poste de préjudice distinct du déficit fonctionnel permanent et doit être indemnisée séparément.

**Evaluation**
En cas de perte d'emploi : capitalisation de la perte de revenus
En cas de déclassement : différentiel de rémunération capitalisé
En cas de difficulté professionnelle sans perte : indemnisation forfaitaire

### Préjudice d'agrément
**Cass. 2e civ., 28 octobre 2010, n° 09-69.195**
Le préjudice d'agrément indemnise l'impossibilité de pratiquer une activité spécifique sportive ou de loisirs.

**Condition d'indemnisation**
- Pratique régulière et établie de l'activité avant l'accident
- Impossibilité totale ou partielle de poursuivre cette activité
- Distinction avec le préjudice d'agrément inclus dans le DFP

Montants indicatifs : 3 000 à 15 000 euros selon l'importance de l'activité

### Préjudice sexuel
**Cass. 2e civ., 5 juillet 2007, n° 06-15.044**
Le préjudice sexuel constitue un poste autonome comprenant trois dimensions :
- Le préjudice morphologique (atteinte aux organes sexuels)
- Le préjudice relatif à l'acte sexuel (impuissance, dyspareunie)
- Le préjudice concernant la fertilité et la procréation

### Préjudice d'établissement
**Cass. 2e civ., 4 juin 2009, n° 08-16.549**
Ce préjudice indemnise le préjudice spécifique subi par la victime dans sa vie personnelle et affective : impossibilité de se marier, de fonder une famille, de mener une vie de couple normale.

**Condition**
Réservé aux très jeunes victimes ou aux victimes dont le handicap empêche matériellement la vie de couple et la fondation d'une famille.

Montants : généralement entre 20 000 et 80 000 euros

### Préjudice d'un proche
**Loi du 21 décembre 2006 (loi Badinter pour les accidents de la circulation)**
**Article 1386-19 du Code civil**

**Cass. 2e civ., 8 avril 2004, n° 02-13.445**
Les proches de la victime peuvent être indemnisés de leur préjudice d'affection et des troubles dans les conditions d'existence.

## Frais et dépenses de santé

### Frais médicaux et pharmaceutiques
**Article 1382 du Code civil (ancien) / Article 1240 (nouveau)**
Réparation intégrale des frais exposés, qu'ils soient remboursés ou non par l'assurance maladie.

### Créance de la Sécurité sociale
**Articles L.376-1 et suivants du Code de la sécurité sociale**
La caisse primaire d'assurance maladie dispose d'un recours subrogatoire contre le responsable pour récupérer les prestations versées.

**Cass. 2e civ., 15 mai 2008, n° 07-14.932**
La créance de la CPAM doit être fixée dans le jugement et le jugement lui est opposable.

## Dommages-intérêts et intérêts légaux

### Intérêts au taux légal
**Article 1231-6 du Code civil**
Les dommages et intérêts portent intérêts au taux légal à compter du jugement.

**Cass. 2e civ., 8 juillet 2004, n° 03-30.039**
En matière de préjudice corporel, les intérêts courent à compter de la date du jugement sauf si la victime avait formulé une offre chiffrée antérieure.

### Exécution provisoire
**Article 514 du Code de procédure civile**
Les décisions de première instance sont de droit exécutoires à titre provisoire.

**Cass. 2e civ., 3 février 2011, n° 10-10.593**
L'exécution provisoire ne peut être écartée que par décision spécialement motivée lorsqu'elle est incompatible avec la nature de l'affaire.

## Prescription

### Délai de droit commun
**Article 2226 du Code civil**
L'action en responsabilité se prescrit par 10 ans à compter de la consolidation du dommage ou de la révélation de celui-ci.

### Responsabilité médicale
**Article L.1142-28 du Code de la santé publique**
Prescription de 10 ans à compter de la consolidation du dommage.

**Cass. 1re civ., 17 mars 2016, n° 15-13.995**
Le point de départ du délai est la date de consolidation ou de la première manifestation du dommage.

## Causalité

### Lien de causalité
**Théorie de l'équivalence des conditions**
**Cass. 2e civ., 4 juin 2009, n° 08-13.396**
Pour être réparable, le préjudice doit être en lien de causalité direct et certain avec le fait dommageable.

### Perte de chance
**Cass. 1re civ., 17 novembre 1982**
La perte de chance doit être réelle, actuelle et certaine. Elle ne peut être évaluée par rapport au dommage final mais uniquement par rapport aux chances perdues.

## Barèmes indicatifs

### Principe
**Cass. 2e civ., 15 mai 2014, n° 13-17.091**
Les barèmes indicatifs ne s'imposent pas au juge qui dispose d'un pouvoir souverain d'appréciation pour évaluer le préjudice.

### Référence Mornet
Barème d'indemnisation du déficit fonctionnel permanent, largement utilisé par les juridictions françaises.

### Valeur du point de préjudice corporel
Evolution jurisprudentielle : augmentation progressive pour tenir compte de l'inflation et de l'évolution des conditions de vie.

Tendance actuelle : 1 800 à 2 000 euros par point d'IPP pour les victimes jeunes.

## Note importante

Cette liste n'est pas exhaustive et doit être complétée par une recherche jurisprudentielle actualisée pour chaque dossier spécifique. Les montants et principes évoluent régulièrement en fonction de la jurisprudence.

En cas de doute, il convient de :
- Vérifier la jurisprudence la plus récente
- Consulter les bases de données juridiques (Légifrance, Dalloz, JurisData)
- S'assurer de l'applicabilité de la jurisprudence au cas d'espèce
- Ne jamais citer une jurisprudence sans l'avoir vérifiée
