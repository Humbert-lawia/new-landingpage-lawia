# Mentions obligatoires de l'assignation devant le tribunal judiciaire

## Table des matières

1. [Socle commun — Articles 54 et 56 CPC](#socle-commun)
2. [Mentions spécifiques — Représentation obligatoire (art. 752 CPC)](#représentation-obligatoire)
3. [Mentions spécifiques — Représentation non obligatoire (art. 753 CPC)](#représentation-non-obligatoire)
4. [Mentions spécifiques au référé](#spécificités-du-référé)
5. [Mentions spécifiques au fond](#spécificités-du-fond)
6. [Tableau de synthèse par situation](#tableau-de-synthèse)
7. [Délais de remise au greffe](#délais-de-remise)

---

## Socle commun — Articles 54 et 56 CPC

Ces mentions s'appliquent à TOUTE assignation devant le tribunal judiciaire, qu'il s'agisse du référé ou du fond, avec ou sans représentation obligatoire.

### Article 54 CPC — Mentions communes à tout acte introductif

À peine de nullité, la demande initiale mentionne :

1. L'indication de la juridiction devant laquelle la demande est portée
2. L'objet de la demande
3. Pour les personnes physiques : nom, prénoms, profession, domicile, nationalité, date et lieu de naissance
4. Pour les personnes morales : forme, dénomination, siège social et organe qui les représente légalement
5. Le cas échéant, les mentions relatives à la désignation des immeubles exigées pour la publication au fichier immobilier
6. Lorsqu'elle doit être précédée d'une tentative de résolution amiable : les diligences entreprises ou la justification de la dispense
7. L'indication des modalités de comparution devant la juridiction et la précision que, faute pour le défendeur de comparaître, il s'expose à ce qu'un jugement soit rendu contre lui sur les seuls éléments fournis par son adversaire

**Note sur la résolution amiable** : L'obligation de l'article 750-1 CPC est écartée en référé en raison de l'urgence inhérente à la procédure. Au fond, elle s'applique pour les demandes ≤ 5 000 € sauf exceptions (urgence, indisponibilité du conciliateur, etc.).

### Article 56 CPC — Mentions spécifiques à l'assignation

L'assignation contient en outre, à peine de nullité :

1. Les lieu, jour et heure de l'audience à laquelle l'affaire sera appelée
2. Un exposé des moyens en fait et en droit
3. La liste des pièces sur lesquelles la demande est fondée, dans un bordereau annexé à l'assignation

### Article 648 CPC — Mentions prescrites pour les actes de commissaire de justice

Tout acte de commissaire de justice doit mentionner à peine de nullité :

1. Sa date
2. Si le requérant est une personne physique : ses nom, prénoms, profession, domicile, nationalité, date et lieu de naissance
3. Si le requérant est une personne morale : sa forme, sa dénomination, son siège social et l'organe qui la représente légalement
4. Les nom, prénoms, demeure et signature du commissaire de justice
5. Les nom et domicile du destinataire, ou s'il s'agit d'une personne morale, sa dénomination et son siège social

---

## Représentation obligatoire — Article 752 CPC

### Quand s'applique l'article 752 ?

La représentation par avocat est **obligatoire** devant le tribunal judiciaire dans les cas suivants (art. 760-761 CPC) :

- Demande au fond dont le montant **excède 10 000 €**
- Matières relevant de la **compétence exclusive** du tribunal judiciaire (quelle que soit la valeur du litige)
- Référé portant sur une matière où la représentation est obligatoire

### Mentions supplémentaires (art. 752 CPC)

Outre les mentions des articles 54 et 56, l'assignation doit comporter, **à peine de nullité** :

1. **La constitution de l'avocat du demandeur** : identification complète de l'avocat (nom, prénom, barreau, adresse, toque), avec la formule « lequel se constitue et occupera sur la présente assignation et ses suites »
2. **Le délai dans lequel le défendeur est tenu de constituer avocat** : « Dans un délai de QUINZE JOURS à compter de la date du présent acte, vous êtes tenu de constituer avocat »

### Avertissement type — Représentation obligatoire

```
TRÈS IMPORTANT

Dans un délai de QUINZE JOURS, à compter de la date du présent acte, vous êtes
tenu(e)(s) de constituer avocat devant le Tribunal Judiciaire de [VILLE].

À défaut, vous vous exposez à ce qu'un jugement soit rendu contre vous sur les
seuls éléments fournis par votre (vos) adversaire(s).

Il vous est rappelé les dispositions suivantes, tirées de la loi n° 71-1130 du
31 décembre 1971 portant réforme de certaines professions judiciaires et juridiques :

Article 5 : « Les avocats exercent leur ministère et peuvent plaider sans
limitation territoriale devant toutes les juridictions et organismes
juridictionnels ou disciplinaires, sous les réserves prévues à l'article 4. »

Article 5-1 : « Les avocats peuvent assister et représenter autrui devant les
administrations publiques, sous réserve des dispositions législatives et
réglementaires. »

Il vous est par ailleurs rappelé les articles suivants du code de procédure civile :

Article 641 : « Lorsqu'un délai est exprimé en jours, celui de l'acte, de
l'événement, de la décision ou de la notification qui le fait courir ne compte pas. »

Article 642 : « Tout délai expire le dernier jour à vingt-quatre heures. Le délai
qui expirerait normalement un samedi, un dimanche ou un jour férié ou chômé, est
prorogé jusqu'au premier jour ouvrable suivant. »

Article 643 : « Lorsque la demande est portée devant une juridiction qui a son
siège en France métropolitaine, les délais de comparution, d'appel, d'opposition,
de tierce opposition, de recours en révision et de pourvoi en cassation sont
augmentés de : un mois pour les personnes qui demeurent en Guadeloupe, en Guyane,
à la Martinique, à La Réunion, à Mayotte, à Saint-Barthélemy, à Saint-Martin,
à Saint-Pierre-et-Miquelon, en Polynésie française, dans les îles Wallis et Futuna,
en Nouvelle-Calédonie et dans les Terres australes et antarctiques françaises ;
deux mois pour celles qui demeurent à l'étranger. »

Article 644 : « Les délais prévus à l'article précédent sont augmentés de la même
durée lorsque la juridiction a son siège dans un département ou une collectivité
d'outre-mer. »
```

### Mentions complémentaires (fond avec représentation obligatoire)

```
- Conformément aux dispositions de l'article 54 du code de procédure civile,
figurent ci-après les mentions relatives à la désignation des immeubles exigées
pour la publication au fichier immobilier : [... ou « sans objet »]

- Il est indiqué, en application de l'article 752 du code de procédure civile,
que le(s) demandeur(s) [est (sont) d'accord / n'est (ne sont) pas d'accord] pour
que la procédure se déroule sans audience en application de l'article L. 212-5-1
du code de l'organisation judiciaire.

- Les pièces sur lesquelles la demande est fondée sont indiquées en fin d'acte
selon bordereau annexé.
```

---

## Représentation non obligatoire — Article 753 CPC

### Quand s'applique l'article 753 ?

La représentation par avocat n'est **pas obligatoire** dans les cas suivants (art. 761 CPC) :

- Demande au fond dont le montant est **inférieur ou égal à 10 000 €**
- Demande indéterminée ayant pour origine l'exécution d'une obligation dont le montant n'excède pas 10 000 €
- **Sauf** matières relevant de la compétence exclusive du tribunal judiciaire

### Mentions supplémentaires (art. 753 CPC)

Outre les mentions des articles 54 et 56, l'assignation doit comporter, **à peine de nullité** :

1. Les nom, prénoms et adresse de la personne chez qui le demandeur élit domicile en France (si résidence à l'étranger)
2. Les dispositions de **l'article 832 du CPC** (possibilité de se faire assister ou représenter)
3. Les conditions dans lesquelles le défendeur peut se faire assister ou représenter
4. S'il y a lieu, le nom du représentant du demandeur

### Avertissement type — Représentation non obligatoire

```
TRÈS IMPORTANT

Vous êtes tenu(e)(s) de comparaître devant le Tribunal Judiciaire de [VILLE] à
l'audience du [date] à [heure].

Vous pouvez vous faire assister ou représenter par un avocat.

Vous pouvez également vous faire assister ou représenter par votre conjoint, votre
concubin ou la personne avec laquelle vous avez conclu un pacte civil de solidarité,
vos parents ou alliés en ligne directe, vos parents ou alliés en ligne collatérale
jusqu'au troisième degré inclus, les personnes exclusivement attachées à votre
service personnel ou à votre entreprise.

Le représentant, s'il n'est avocat, doit justifier d'un pouvoir spécial.

Il est rappelé les dispositions de l'article 832 du Code de procédure civile :
« Les parties se défendent elles-mêmes. Elles ont la faculté de se faire assister
ou représenter par toute personne de leur choix. Le représentant, s'il n'est avocat,
doit justifier d'un pouvoir spécial. »

Faute par vous de comparaître ou d'être régulièrement assisté(e)(s) ou
représenté(e)(s), vous vous exposez à ce qu'un jugement soit rendu contre vous
sur les seuls éléments fournis par votre (vos) adversaire(s).

Les pièces sur lesquelles la demande est fondée sont indiquées en fin d'acte selon
bordereau annexé.
```

---

## Spécificités du référé

### Fondements du référé devant le TJ

| Article | Objet | Conditions |
|---------|-------|-----------|
| **Art. 834 CPC** | Référé urgence — mesures conservatoires ou de remise en état | Urgence + absence de contestation sérieuse |
| **Art. 835 al. 1 CPC** | Référé trouble manifestement illicite / dommage imminent | Pas d'urgence requise (trouble manifeste suffit) |
| **Art. 835 al. 2 CPC** | Référé provision | Obligation non sérieusement contestable |
| **Art. 145 CPC** | Référé expertise / mesure d'instruction in futurum | Motif légitime de conserver ou d'établir avant tout procès la preuve de faits |

### Mentions spécifiques au référé

L'assignation en référé doit impérativement :

1. **Viser le fondement juridique** : « Vu l'article [834 / 835 / 145] du Code de procédure civile »
2. **Caractériser l'urgence** (si art. 834) : exposer les circonstances démontrant l'urgence
3. **Caractériser l'objet** :
   - Art. 834 : mesure conservatoire ou de remise en état ne se heurtant à aucune contestation sérieuse
   - Art. 835 al. 1 : trouble manifestement illicite ou dommage imminent
   - Art. 835 al. 2 : existence d'une obligation non sérieusement contestable justifiant l'allocation d'une provision
   - Art. 145 : motif légitime de conserver ou d'établir la preuve de faits dont pourrait dépendre la solution d'un litige

### Particularité de l'assignation en référé

- **Pas de tentative de résolution amiable préalable** (art. 750-1 CPC : dispense en cas d'urgence)
- **Assignation à heure et jour indiqués** : possibilité de réduction des délais, voire d'assigner à jour fixe en cas d'extrême urgence (art. 485 CPC)
- **Pas de procédure sans audience** : la mention de l'article 752 sur l'accord pour procédure sans audience ne s'applique pas

---

## Spécificités du fond

### Mentions complémentaires au fond

- **Tentative de résolution amiable** (art. 750-1 CPC) : obligatoire pour les demandes ≤ 5 000 € sauf exceptions. Mentionner les diligences accomplies ou la dispense.
- **Procédure sans audience** (art. L. 212-5-1 COJ) : indiquer l'accord ou le désaccord du demandeur
- **Exécution provisoire** : de droit depuis le décret du 11 décembre 2019 (art. 514 CPC). Motivation renforcée si demande d'écarter l'exécution provisoire (art. 514-1 CPC).

---

## Tableau de synthèse par situation

| Situation | Articles visas | Mentions assignation | Avertissement |
|-----------|---------------|---------------------|---------------|
| **Référé + représentation obligatoire** | Art. 54, 56, 648, 752, 834/835/145 CPC | Constitution avocat + délai 15 jours + fondement référé | Version « représentation obligatoire » |
| **Référé + représentation non obligatoire** | Art. 54, 56, 648, 753, 834/835/145 CPC | Art. 832 + modalités représentation + fondement référé | Version « représentation non obligatoire » |
| **Fond + représentation obligatoire** | Art. 54, 56, 648, 752 CPC | Constitution avocat + délai 15 jours + procédure sans audience + résolution amiable | Version « représentation obligatoire » |
| **Fond + représentation non obligatoire** | Art. 54, 56, 648, 753 CPC | Art. 832 + modalités représentation + résolution amiable | Version « représentation non obligatoire » |

---

## Délais de remise au greffe

| Procédure | Délai de remise au greffe | Sanction |
|-----------|--------------------------|---------|
| Procédure écrite (art. 754 CPC) | 2 mois avant la date de l'audience | Caducité de l'assignation |
| Procédure orale (art. 754 al. 2 CPC) | 15 jours avant la date de l'audience | Caducité de l'assignation |
| Référé | Selon les usages du tribunal (généralement 15 jours avant l'audience) | Caducité |

**Attention** : La caducité de l'assignation pour défaut de remise au greffe dans les délais est une sanction automatique qui n'exige pas la démonstration d'un grief (contrairement à la nullité pour vice de forme, art. 114 CPC).

---

## Sources Lexbase

- Lexbase Avocats, 1er mai 2025 : « Savoir quand se faire représenter devant le tribunal judiciaire » (Lexbase n° N2104B3C)
- Lexbase Droit privé, 23 janvier 2020 : « Réforme de la procédure civile 2020 — La demande devant le tribunal judiciaire » (Lexbase n° N1929BY4), Pr. Etienne Vergès
- Lexbase Droit privé, 23 janvier 2020 : « Extension de la représentation par avocat » (Lexbase n° N1954BYZ), Sâmi Hazoug
- Lexbase Avocats, 1er juillet 2021 : « La simplification de la procédure devant le tribunal judiciaire » (Lexbase n° N7989BYK), Marilyn Guez
- Lexbase Droit privé, 8 octobre 2015 : « Sanctions des mentions relatives à l'assignation et modalités de régularisation » (Lexbase n° N9309BUC)
- TJ Angoulême, Chambre Référés, 7 janvier 2026, n° 25/00260 (Lexbase n° B7968DBQ) — nullité pour défaut de mention
- TJ Lille, Référés expertises, 14 octobre 2025, n° 25/00748 (Lexbase n° B5535CG4) — représentation obligatoire en référé
