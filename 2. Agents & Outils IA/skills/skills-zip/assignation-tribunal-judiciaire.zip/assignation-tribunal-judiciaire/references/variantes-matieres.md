# Variantes par matière et cas particuliers

## Table des matières

1. [Dommage corporel](#a-dommage-corporel)
2. [Responsabilité médicale](#b-responsabilité-médicale)
3. [Droit de la consommation](#c-droit-de-la-consommation)
4. [Droit de la construction](#d-droit-de-la-construction)
5. [Droit civil général](#e-droit-civil-général)
6. [Variantes référé par matière](#variantes-référé)
7. [Cas particuliers transversaux](#cas-particuliers)

---

## A. Dommage corporel

### Fondements juridiques

**Accident de la circulation (Loi Badinter du 5 juillet 1985)** :
- Articles 1er à 6 : régime d'indemnisation des victimes d'accidents de la circulation
- Droit à réparation intégrale du conducteur non fautif et des non-conducteurs
- Exonération limitée : faute inexcusable cause exclusive (non-conducteurs), faute du conducteur victime
- Action directe contre l'assureur (art. L.124-3 C. assur.)

**Accident de la vie courante** :
- Articles 1240-1241 du Code civil (responsabilité du fait personnel)
- Article 1242 al. 1 du Code civil (responsabilité du fait des choses)
- Article 1243 du Code civil (responsabilité du fait des animaux)
- Article 1244 du Code civil (responsabilité du fait des bâtiments en ruine)

**Agression / infraction** :
- Articles 1240 et suivants du Code civil
- Possibilité de saisine de la CIVI (art. 706-3 CPP) — voir skill saisine-civi

### Spécificités rédactionnelles

- **Nomenclature Dintilhac** : chaque poste de préjudice fait l'objet d'un développement autonome avec : définition du poste → cotation par l'expert → évaluation motivée du quantum
- **Principe de réparation intégrale** : rappeler systématiquement (Cass. 2e civ., 28 oct. 2010, n° 09-68.848)
- **Tableau récapitulatif** : insérer un tableau synthétisant tous les postes de préjudice demandés
- **Recours des tiers payeurs** : demander la fixation de la créance de la CPAM (art. L.376-1 CSS), mentionner le protocole de la Cour de cassation du 3 juillet 2021
- **Tierce personne** : distinguer temporaire/permanente, calculer selon le SMC horaire majoré ou l'aide effective

### Demandes types au fond (dommage corporel)

```
DIRE et JUGER que [DÉFENDEUR] est entièrement responsable des préjudices subis par [DEMANDEUR]

HOMOLOGUER le rapport d'expertise [judiciaire/amiable] du Docteur [NOM] en date du [DATE]

Fixer la date de consolidation de [DEMANDEUR] au [DATE]

EN CONSÉQUENCE, CONDAMNER [DÉFENDEUR(S)] solidairement à payer à [DEMANDEUR] :
- Au titre des préjudices patrimoniaux : [montant] €
- Au titre des préjudices extra-patrimoniaux : [montant] €
Soit un total de [MONTANT TOTAL] €

FIXER la créance de la [CPAM de...] à la somme de [montant] €

JUGER que les condamnations porteront intérêts au taux légal à compter du jugement à intervenir

ORDONNER la capitalisation des intérêts (art. 1343-2 C. civ.)

CONDAMNER [DÉFENDEUR(S)] à payer à [DEMANDEUR] la somme de [montant] € au titre de l'article 700 CPC

CONDAMNER [DÉFENDEUR(S)] aux entiers dépens en ce compris les frais d'expertise
```

---

## B. Responsabilité médicale

### Fondements juridiques

**Responsabilité pour faute (art. L.1142-1 I CSP)** :
- Obligation de moyens du praticien (Cass. 1re civ., 20 mai 1936, Mercier)
- Faute médicale : manquement aux données acquises de la science
- Défaut d'information (art. L.1111-2 CSP, Cass. 1re civ., 25 févr. 1997, Hédreul)
- Perte de chance : préjudice distinct et autonome (Cass. 1re civ., 14 oct. 2010, n° 09-69.195)

**Infections nosocomiales (art. L.1142-1 I al. 2 CSP)** :
- Responsabilité de plein droit des établissements de santé
- Exonération : cause étrangère uniquement

**Aléa thérapeutique / ONIAM (art. L.1142-1 II CSP)** :
- Indemnisation par la solidarité nationale via l'ONIAM
- Conditions : conséquences anormales, gravité suffisante (art. D.1142-1 CSP : DFP ≥ 24 % ou 6 mois d'ITT ou inaptitude définitive)

**Prescription** : 10 ans à compter de la consolidation (art. L.1142-28 CSP)

### Spécificités rédactionnelles

- **Expertise médicale** : se fonder principalement sur le rapport d'expertise, citer l'expert comme source première
- **Obligation d'information** : rappeler la charge de la preuve qui incombe au praticien (art. L.1111-2 al. 7 CSP)
- **Perte de chance** : évaluer le coefficient de perte de chance distinct de la réparation intégrale
- **Recours ONIAM** : si aléa thérapeutique, envisager la mise en cause de l'ONIAM

### Demandes types — référé expertise médicale (art. 145 CPC)

```
ORDONNER une expertise médicale et DÉSIGNER tel expert qu'il plaira avec pour mission de :
1. Se faire communiquer le dossier médical complet de [DEMANDEUR]
2. Décrire les actes médicaux réalisés
3. Dire si les actes réalisés étaient conformes aux données acquises de la science
4. Décrire les lésions et séquelles en lien avec les actes médicaux litigieux
5. Fixer la date de consolidation
6. Évaluer les préjudices selon la nomenclature Dintilhac : DFT, SE, DFP, IP, PA, PE, préjudice sexuel, etc.
7. Dire si l'état de [DEMANDEUR] nécessite l'assistance d'une tierce personne
8. Donner tous éléments permettant au tribunal d'évaluer les préjudices

CONDAMNER [DÉFENDEUR] à verser une provision de [montant] € à valoir sur l'indemnisation définitive

FIXER la consignation de l'expert à la somme de [montant] € à la charge de [DEMANDEUR / DÉFENDEUR]
```

---

## C. Droit de la consommation

### Fondements juridiques

**Garantie légale de conformité (art. L.217-1 s. C. consom.)** :
- Réformée par l'ordonnance n° 2021-1247 du 29 septembre 2021 (entrée en vigueur 1er janvier 2022)
- Délai de 2 ans à compter de la délivrance (art. L.217-3 C. consom.)
- Présomption d'antériorité du défaut : 2 ans pour les biens neufs, 1 an pour les biens d'occasion (art. L.217-7 C. consom.)
- Choix entre réparation et remplacement (art. L.217-10 C. consom.)
- Résolution en cas d'impossibilité de réparation ou remplacement

**Garantie des vices cachés (art. 1641 s. C. civ.)** :
- Vice rendant la chose impropre à l'usage ou diminuant tellement cet usage que l'acheteur ne l'aurait pas acquise
- Action rédhibitoire ou estimatoire
- Prescription : 2 ans à compter de la découverte du vice (art. 1648 al. 1 C. civ.)
- Vendeur professionnel : présumé connaître le vice (Cass. 1re civ., 24 nov. 1954)

**Clauses abusives (art. L.212-1 s. C. consom.)** :
- Clause créant un déséquilibre significatif
- Réputées non écrites

**Pratiques commerciales trompeuses (art. L.121-1 s. C. consom.)** :
- Fondement d'une action en dommages-intérêts

### Spécificités rédactionnelles

- **Qualité de consommateur** : toujours caractériser la qualité de consommateur du demandeur et de professionnel du défendeur
- **Présomption d'antériorité** : invoquer systématiquement si applicable
- **Choix du fondement** : déterminer si garantie de conformité (plus favorable) ou vices cachés ou les deux à titre subsidiaire
- **Clauses abusives** : les relever et demander au tribunal de les réputer non écrites
- **Prescription** : vérifier le délai de 2 ans

### Demandes types (consommation)

```
DIRE et JUGER que [PRODUIT/SERVICE] n'est pas conforme au contrat au sens des articles L.217-1 et suivants du Code de la consommation

PRONONCER la résolution de la vente / CONDAMNER [PROFESSIONNEL] au remplacement/à la réparation

CONDAMNER [PROFESSIONNEL] à rembourser à [CONSOMMATEUR] le prix de [montant] €

CONDAMNER [PROFESSIONNEL] à payer à [CONSOMMATEUR] la somme de [montant] € à titre de dommages-intérêts en réparation du préjudice de jouissance / préjudice moral

Subsidiairement, sur le fondement des articles 1641 et suivants du Code civil :
PRONONCER la résolution de la vente pour vice caché
```

---

## D. Droit de la construction

### Fondements juridiques

**Garantie décennale (art. 1792 C. civ.)** :
- Présomption de responsabilité des constructeurs
- Désordres compromettant la solidité de l'ouvrage ou le rendant impropre à sa destination
- 10 ans à compter de la réception
- Assurance obligatoire (art. L.241-1 C. assur.)

**Garantie biennale de bon fonctionnement (art. 1792-3 C. civ.)** :
- Éléments d'équipement dissociables
- 2 ans à compter de la réception

**Garantie de parfait achèvement (art. 1792-6 C. civ.)** :
- 1 an à compter de la réception
- Réserves à la réception ou désordres signalés dans l'année

**Assurance dommages-ouvrage (art. L.242-1 C. assur.)** :
- Préfinancement des réparations
- Action directe contre l'assureur DO

**Responsabilité contractuelle de droit commun** :
- Art. 1231-1 C. civ. : avant réception, responsabilité contractuelle ordinaire
- Art. 1792-4-1 C. civ. : action directe contre le sous-traitant

### Spécificités rédactionnelles

- **Réception** : caractériser précisément la date de réception (expresse, tacite, judiciaire) — point de départ des garanties
- **Nature des désordres** : qualifier précisément (atteinte à la solidité / impropriété à destination / bon fonctionnement / parfait achèvement)
- **Pluralité de défendeurs** : identifier tous les intervenants à l'acte de construire et leurs assureurs
- **Expertise** : les désordres de construction font quasi systématiquement l'objet d'une expertise judiciaire préalable

### Demandes types (construction)

```
DIRE et JUGER que les désordres affectant [OUVRAGE] engagent la responsabilité décennale de [CONSTRUCTEUR] au sens de l'article 1792 du Code civil

CONDAMNER solidairement [CONSTRUCTEUR] et son assureur [ASSUREUR] à payer à [MAÎTRE D'OUVRAGE] la somme de [montant] € correspondant au coût des travaux de reprise

CONDAMNER solidairement les défendeurs à payer la somme de [montant] € au titre du préjudice de jouissance
```

---

## E. Droit civil général

### Fondements juridiques

**Responsabilité contractuelle** :
- Art. 1103 C. civ. : force obligatoire du contrat
- Art. 1104 C. civ. : bonne foi
- Art. 1217 s. C. civ. : inexécution du contrat (exception d'inexécution, réduction du prix, résolution, dommages-intérêts)
- Art. 1231-1 C. civ. : dommages-intérêts pour inexécution

**Responsabilité délictuelle** :
- Art. 1240 C. civ. : faute personnelle
- Art. 1241 C. civ. : imprudence ou négligence
- Art. 1242 al. 1 C. civ. : responsabilité du fait des choses
- Art. 1242 al. 4-5 C. civ. : responsabilité des parents du fait de leurs enfants mineurs
- Art. 1242 al. 6 C. civ. : responsabilité des commettants du fait de leurs préposés

**Prescription** :
- 5 ans de droit commun (art. 2224 C. civ.)
- 10 ans en matière de dommage corporel (art. 2226 C. civ.)
- 2 ans en consommation (art. L.218-2 C. consom.)

---

## Variantes référé par matière

### Référé expertise (art. 145 CPC) — Toutes matières

L'assignation en référé expertise doit :
- Démontrer le **motif légitime** de conserver ou établir la preuve
- Justifier que la mesure est demandée **avant tout procès** (ou qu'aucune instance au fond n'est en cours sur le même objet)
- Proposer une **mission d'expertise** précise et adaptée à la matière
- Indiquer le montant de la **consignation** proposée

### Référé provision (art. 835 al. 2 CPC) — Toutes matières

L'assignation en référé provision doit :
- Démontrer l'existence d'une **obligation non sérieusement contestable**
- Chiffrer précisément la **provision** sollicitée
- Produire les pièces établissant le caractère non contestable

### Référé trouble manifestement illicite (art. 835 al. 1 CPC) — Construction, consommation

L'assignation doit :
- Caractériser le **trouble manifestement illicite** ou le **dommage imminent**
- Décrire la mesure de cessation ou de prévention sollicitée

---

## Cas particuliers transversaux

### Pluralité de responsables

Lorsque plusieurs personnes sont responsables du même dommage :
- Demander la condamnation **solidaire** ou **in solidum** (si pas de solidarité contractuelle)
- Identifier chaque défendeur et son assureur
- Articuler les fondements de responsabilité propres à chacun

### Demande provisionnelle au fond

Il est possible de solliciter une provision au fond (art. 789 al. 3 CPC) :
- Devant le juge de la mise en état, avant le jugement au fond
- Si l'existence de l'obligation n'est pas sérieusement contestable

### Intervention forcée de tiers

- CPAM / organisme social : art. L.376-1 CSS — appel en la cause obligatoire
- Assureur : action directe (art. L.124-3 C. assur.)
- ONIAM : si aléa thérapeutique
- Fonds de garantie (FGAO, FGTI) : selon les cas

### Prescription interruptive

En référé :
- L'assignation en référé expertise interrompt la prescription (Cass. 2e civ., 31 janv. 2019, n° 18-10.011)
- Effet interruptif : nouveau délai de même durée à compter de l'ordonnance de référé
