# Checklist de vérification — Assignation TJ

## 1. Vérifications formelles

### Identification des parties
- [ ] État civil complet du demandeur (nom, prénom, date/lieu naissance, nationalité, profession, domicile)
- [ ] Identification complète du/des défendeur(s)
- [ ] Adresses complètes et à jour
- [ ] Pour les personnes morales : forme, dénomination, RCS, siège, représentant légal
- [ ] Formule « prise en la personne de son représentant légal y domicilié » pour les personnes morales

### Avocat et représentation
- [ ] Constitution de l'avocat avec coordonnées complètes (toque comprise)
- [ ] Formule « lequel se constitue et occupera sur la présente assignation et ses suites »
- [ ] Si postulation : avocat postulant correctement identifié
- [ ] Cohérence entre le régime de représentation et les mentions choisies (art. 752 ou 753)

### Juridiction et audience
- [ ] Tribunal judiciaire correctement désigné (ville)
- [ ] Date, heure et lieu d'audience précisés
- [ ] Formation correctement identifiée (référés / pôle civil section X / JCP)
- [ ] En référé : « Madame ou Monsieur le Président, statuant en référé »
- [ ] Au fond : « Tribunal Judiciaire de [Ville] »

### Formules d'ouverture et de transition
- [ ] « L'AN deux mille [année] et le » (date laissée au commissaire de justice)
- [ ] « J'AI, COMMISSAIRE DE JUSTICE DÉSIGNÉ, L'HONNEUR D'INFORMER »
- [ ] « OU ÉTANT ET PARLANT À » (laissé au commissaire de justice)
- [ ] Formule de transition vers l'objet du procès

---

## 2. Vérifications des mentions obligatoires

### Socle commun (art. 54 + 56 CPC)
- [ ] Indication de la juridiction saisie
- [ ] Objet de la demande
- [ ] Exposé des moyens en fait et en droit
- [ ] Liste des pièces (bordereau annexé)
- [ ] Modalités de comparution + avertissement défaut de comparution
- [ ] Mentions art. 648 CPC (acte de commissaire de justice)

### Si représentation obligatoire (art. 752 CPC)
- [ ] Constitution de l'avocat du demandeur
- [ ] Délai de 15 jours pour constituer avocat
- [ ] Rappel des articles 5 et 5-1 de la loi du 31 décembre 1971
- [ ] Rappel des articles 641-644 CPC (délais)
- [ ] Mention de la procédure sans audience (accord/désaccord) — au fond uniquement
- [ ] Mention des immeubles (art. 54 CPC) le cas échéant
- [ ] Mention du bordereau de pièces annexé

### Si représentation non obligatoire (art. 753 CPC)
- [ ] Élection de domicile (si demandeur à l'étranger)
- [ ] Rappel de l'article 832 CPC (modalités d'assistance et de représentation)
- [ ] Conditions de représentation du défendeur (pouvoir spécial si non-avocat)
- [ ] Nom du représentant du demandeur (si applicable)

### Mentions spécifiques référé
- [ ] Fondement du référé explicitement visé (art. 834, 835, ou 145 CPC)
- [ ] Caractérisation de l'urgence (si art. 834)
- [ ] Pas de mention de procédure sans audience
- [ ] Pas d'obligation de tentative de résolution amiable

### Mentions spécifiques fond
- [ ] Tentative de résolution amiable (si demande ≤ 5 000 € et pas de dispense)
- [ ] Procédure sans audience : accord ou désaccord du demandeur

---

## 3. Vérifications de fond

### Argumentation juridique
- [ ] Chaque moyen suit le syllogisme : majeure (droit) → mineure (faits) → conclusion
- [ ] Les textes de loi sont correctement cités (article, alinéa, code)
- [ ] Les jurisprudences sont vérifiables (juridiction, date, numéro)
- [ ] L'application au cas d'espèce est factuelle et documentée
- [ ] Les moyens sont hiérarchisés (principal / subsidiaire)
- [ ] Les objections adverses prévisibles sont anticipées

### En référé
- [ ] Le fondement choisi (art. 834, 835, 145) est pertinent au regard des faits
- [ ] Les conditions du référé sont caractérisées (urgence, absence de contestation sérieuse, motif légitime, etc.)
- [ ] La mesure sollicitée est précise et proportionnée
- [ ] Si provision : montant justifié et obligation non sérieusement contestable

### Au fond — Préjudices
- [ ] Chaque poste de préjudice est défini et individualisé
- [ ] La nomenclature Dintilhac est correctement appliquée (si dommage corporel)
- [ ] Le quantum est justifié pour chaque poste
- [ ] Le tableau récapitulatif est cohérent avec les développements
- [ ] Les recours des tiers payeurs sont mentionnés (CPAM, mutuelle)

---

## 4. Vérifications des pièces

- [ ] Le bordereau est numéroté de manière continue
- [ ] Chaque pièce est désignée précisément avec sa date
- [ ] Les renvois dans le corps de l'assignation correspondent au bordereau
- [ ] Les pièces essentielles sont présentes :

**Pièces systématiques :**
- [ ] Pièce d'identité du demandeur
- [ ] Mise(s) en demeure ou relances
- [ ] Rapport d'expertise (si disponible)

**Pièces spécifiques par matière :** (voir workflow-collecte.md)

---

## 5. Vérifications de cohérence globale

- [ ] Les montants sont cohérents dans tout le document (développements = tableau = dispositif)
- [ ] Les dates sont cohérentes et chronologiques
- [ ] Les références aux pièces sont exactes
- [ ] Les désignations des parties sont utilisées de façon cohérente
- [ ] Le dispositif correspond exactement aux développements (pas de demande non argumentée)
- [ ] Pas de contradiction entre les sections
- [ ] Les demandes sont claires, chiffrées et hiérarchisées
- [ ] Formules de clôture présentes (« SOUS TOUTES RÉSERVES », « DONT ACTE » au fond)

---

## 6. Vérifications de qualité rédactionnelle

- [ ] Vocabulaire juridique rigoureux et précis
- [ ] Style conforme au registre judiciaire (formules consacrées)
- [ ] Transitions fluides entre les parties
- [ ] Pas de répétitions excessives
- [ ] Pas de langage familier ou approximatif
- [ ] Formatage professionnel (gras, italique, soulignement appropriés)
- [ ] Le fichier .docx est créé avec les bonnes marges, police et interligne

---

## 7. Vérifications anti-hallucination

- [ ] Aucune jurisprudence inventée — chaque décision citée est vérifiable
- [ ] Les articles de loi cités existent et sont en vigueur
- [ ] Les montants des barèmes sont réalistes et actualisés
- [ ] Les noms des parties et les dates correspondent aux informations fournies
- [ ] Si incertitude sur une référence : la signaler à l'utilisateur plutôt que l'inventer
