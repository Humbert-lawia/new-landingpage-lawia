# Formules types et expressions du style judiciaire

## Formules d'introduction et de présentation

### Ouverture de l'instance
- "L'AN deux mille [année] et le [jour] [mois]"
- "A LA DEMANDE DE"
- "Ayant pour avocat plaidant"
- "Ayant pour avocat postulant"
- "J'AI, COMMISSAIRE DE JUSTICE DESIGNE, L'HONNEUR D'INFORMER"
- "Qu'un procès lui (leur) est intenté pour les raisons ci-après exposées"

### Convocation
- "A l'audience du Pôle Civil Section [X] qui se tiendra le [date] à [heure]"
- "Dans un délai de QUINZE JOURS, à compter de la date du présent acte, vous êtes tenu(es) de constituer avocat"
- "A défaut vous vous exposez à ce qu'un jugement ne soit rendu contre vous sur les seuls éléments fournis par votre (vos) adversaire(s)"

### Appel au tribunal
- "PLAISE AU TRIBUNAL"
- "PLAIT-IL AU TRIBUNAL"
- "QU'IL PLAISE AU TRIBUNAL"

## Formules de structure

### Titres de parties
- "RAPPEL DES FAITS ET DE LA PROCEDURE"
- "EN DROIT"
- "DISCUSSION"
- "SUR [thème juridique]"
- "EN CONSEQUENCE"
- "PAR CES MOTIFS"

### Transitions
- "Il résulte de ce qui précède que..."
- "Force est de constater que..."
- "Il s'ensuit que..."
- "Tel est précisément le cas en l'espèce"
- "Or, en l'occurrence..."
- "Ainsi qu'il sera démontré ci-après"
- "Au demeurant"
- "Il convient d'ajouter que..."
- "Il y a lieu de relever que..."
- "A cet égard"
- "En outre"
- "De surcroît"
- "Par ailleurs"
- "Au surplus"

## Formules d'analyse juridique

### Rappel du droit
- "L'article [numéro] du [Code] dispose que..."
- "Aux termes de l'article [numéro] du [Code]..."
- "Il ressort des dispositions de l'article [numéro] que..."
- "Le texte susvisé énonce que..."
- "La règle posée par l'article [numéro] est claire..."

### Citation jurisprudentielle
- "La Cour de cassation, dans un arrêt de principe en date du [date], a jugé que..."
- "Il est de jurisprudence constante que..."
- "La Haute juridiction considère que..."
- "Selon une jurisprudence bien établie..."
- "La Cour d'appel de [ville], dans un arrêt du [date], a considéré que..."
- "Les juges du fond ont constamment décidé que..."
- "Il est admis de longue date que..."

### Application au cas d'espèce
- "En l'espèce..."
- "Or, en l'occurrence..."
- "Or, dans le cas présent..."
- "Tel est précisément le cas qui nous occupe"
- "La situation de fait qui nous est soumise se caractérise par..."
- "Il ne saurait être contesté que..."
- "Il est acquis aux débats que..."
- "Il résulte des pièces versées que..."
- "Les éléments du dossier démontrent sans équivoque que..."

## Formules d'argumentation

### Affirmation
- "Il est constant que..."
- "Il ne fait aucun doute que..."
- "Il est manifeste que..."
- "Il apparaît clairement que..."
- "Nul ne saurait contester que..."
- "Il est incontestable que..."
- "Force est de reconnaître que..."

### Réfutation
- "Contrairement à ce qui pourrait être soutenu..."
- "L'argumentation adverse ne saurait prospérer"
- "Cette thèse doit être écartée"
- "Un tel raisonnement ne résiste pas à l'analyse"
- "Cette prétention est dénuée de tout fondement juridique"
- "Cette position méconnaît les principes..."

### Démonstration
- "Il convient de démontrer que..."
- "La démonstration s'impose que..."
- "L'analyse des faits révèle que..."
- "L'examen attentif du dossier établit que..."
- "Il résulte de l'ensemble de ces éléments que..."

## Formules de conclusion

### Demandes principales
- "DIRE et juger que..."
- "DECLARER [action] opposable à..."
- "CONDAMNER [partie] à payer à [partie] la somme de..."
- "ORDONNER à [partie] de..."
- "FIXER le montant de [élément] à la somme de..."
- "REJETER les demandes, fins et conclusions de..."
- "DEBOUTER [partie] de l'ensemble de ses demandes"
- "Homologuer le rapport d'expertise"

### Demandes accessoires
- "Ordonner l'exécution provisoire de la décision à intervenir nonobstant appel et sans caution"
- "Condamner [partie] aux dépens"
- "Condamner [partie] à verser à [partie] la somme de [montant] euros au titre de l'article 700 du code de procédure civile"
- "Déclarer le jugement commun à [tiers]"
- "Dire que les condamnations porteront intérêts au taux légal à compter de..."

### Formules de réserve
- "SOUS TOUTES RESERVES"
- "En tout état de cause"
- "A tout le moins"
- "Subsidiairement"
- "A titre infiniment subsidiaire"
- "DONT ACTE"

## Formules relatives aux préjudices corporels

### Qualification du préjudice
- "Ce préjudice se définit comme..."
- "Il s'agit d'un poste de préjudice autonome qui recouvre..."
- "La jurisprudence a consacré ce chef de préjudice en..."
- "Ce préjudice distinct et autonome correspond à..."

### Evaluation
- "L'évaluation équitable de ce préjudice conduit à..."
- "Eu égard à l'importance du préjudice subi..."
- "Au regard de la gravité des séquelles..."
- "Compte tenu de l'âge de la victime et de ses perspectives..."
- "En considération des éléments médicaux versés aux débats..."
- "L'expertise a mis en évidence..."
- "Il résulte du rapport d'expertise que..."

### Consolidation et séquelles
- "La date de consolidation doit être fixée au..."
- "Le déficit fonctionnel temporaire s'établit à..."
- "Le taux d'incapacité permanente partielle retenu par l'expert s'élève à..."
- "Les souffrances endurées sont évaluées à..."
- "Le préjudice esthétique est coté à..."

## Formules relatives à la responsabilité médicale

### Fondement de la responsabilité
- "La responsabilité du praticien est engagée au titre de..."
- "Il s'agit d'une obligation de moyens qui suppose..."
- "Le manquement aux règles de l'art est caractérisé par..."
- "La perte de chance de survie ou de guérison s'analyse comme..."

### Manquements
- "Le praticien a méconnu son obligation d'information"
- "Le défaut de recueil du consentement éclairé constitue..."
- "L'acte a été pratiqué en violation des règles de l'art"
- "Le diagnostic a été posé tardivement alors que..."
- "Le suivi post-opératoire s'est avéré défaillant"

### Causalité
- "Il existe un lien de causalité direct et certain entre..."
- "Le dommage trouve sa cause exclusive dans..."
- "Sans cette faute, le préjudice ne se serait pas réalisé"
- "L'expertise a établi de manière incontestable le lien causal"

## Formules de motivation et de justification

### Légitimité de la demande
- "Il serait inéquitable de laisser à la charge de..."
- "La réparation intégrale du préjudice commande que..."
- "Le principe de la réparation intégrale implique que..."
- "Il ne saurait être fait grief à la victime de..."

### Equité
- "L'équité commande que..."
- "Il convient, en équité, de..."
- "Une juste appréciation du préjudice conduit à..."
- "La réparation doit être à la mesure du préjudice subi"

### Urgence et nécessité
- "L'urgence de la situation impose que..."
- "La nécessité de préserver les droits de [partie] commande que..."
- "Il importe au plus haut point que..."
- "Il y a lieu, sans délai, de..."

## Formules procédurales

### Constitution
- "Qui se constitue et occupera pour elle/lui sur la présente assignation et ses suites"

### Références textuelles
- "Vu les dispositions de..."
- "Vu les jurisprudences citées"
- "Vu le rapport d'expertise"
- "Vu les pièces produites"
- "Faisant corps avec le présent dispositif, et tous autres à suppléer si besoin est"

### Exécution
- "Juger que les sommes d'ores et déjà exigibles s'entendent en deniers ou quittances"
- "Juger que les provisions allouées devront être déduites"
- "Juger que les condamnations porteront intérêts au taux légal à compter du jugement à intervenir"

## Expressions du registre judiciaire élevé

### Adverbes et locutions adverbiales
- "Assurément"
- "Manifestement"
- "Incontestablement"
- "Indubitablement"
- "Nécessairement"
- "Légitimement"
- "A juste titre"
- "A bon droit"
- "Sans conteste"

### Locutions conjonctives
- "Dès lors que"
- "Etant donné que"
- "Attendu que"
- "Considérant que"
- "Dans la mesure où"
- "En tant que"
- "Pour autant que"

### Verbes du style judiciaire
- "Convenir de"
- "S'imposer"
- "Résulter de"
- "S'ensuivre"
- "S'avérer"
- "Méconnaître (un principe)"
- "Caractériser (une faute)"
- "Etablir (un fait)"
- "Démontrer"
- "Contrevenir à"
