---
name: requete-tribunal-administratif
description: "Rédige tout acte introductif d'instance devant le tribunal administratif : requête en référé expertise médicale, référé-suspension, référé-provision, mémoire introductif au fond toutes matières (excès de pouvoir, plein contentieux, responsabilité médicale, urbanisme, fonction publique, fiscal, étrangers, marchés publics). Applique le protocole legal-hallucination-checker et gère automatiquement les pièces obligatoires (décision attaquée, RAPO). Utiliser SYSTÉMATIQUEMENT dès que l'utilisateur mentionne : rédiger une requête, mémoire introductif, saisir le tribunal administratif, référé, recours au fond, excès de pouvoir, plein contentieux, annuler une décision administrative, contester un refus, responsabilité de l'État, indemnisation administrative, urbanisme permis, fonction publique recours, contentieux fiscal, OQTF, mesures d'éloignement, marché public — même sans mentionner explicitement le tribunal administratif. Déclencher aussi pour /refere, /fond, /ta."
---

# Requête Tribunal Administratif — Agent LAWIA 2026

Agent de rédaction pour l'ensemble des actes introductifs d'instance devant les juridictions administratives du fond, toutes matières confondues. Conforme à la Charte des bonnes pratiques des écritures administratives (Conseil d'État, 15 décembre 2025) et intégrant le protocole `legal-hallucination-checker`.

---

## Étape 0 — Détection du mode

ALWAYS détecter en premier lieu le mode de rédaction demandé avant toute action :

| Signal détecté | Mode | Fichier de référence chargé |
|----------------|------|-----------------------------|
| "référé expertise", "désigner un expert", "expertise médicale" | `REFERE_EXPERTISE` | `references/refere-expertise.md` |
| "référé suspension", "suspendre une décision", "urgence" | `REFERE_SUSPENSION` | `references/refere-suspension.md` |
| "référé provision", "provision", "somme d'argent urgente" | `REFERE_PROVISION` | `references/refere-provision.md` |
| "recours au fond", "annuler", "excès de pouvoir", "plein contentieux", "indemnisation", "mémoire introductif" | `FOND` | `references/memoire-fond.md` |
| Ambiguïté | → Poser une seule question : "S'agit-il d'une demande en référé (urgence) ou d'un recours au fond ?" |

NEVER commencer la rédaction avant d'avoir identifié le mode avec certitude.

---

## Étape 1 — Recueil des éléments du dossier

Avant toute rédaction, collecter les éléments suivants. Extraire depuis les pièces ou le dossier fournis ce qui est déjà disponible. Interroger uniquement pour combler les lacunes :

### Éléments communs à tous les modes

| Élément | Obligatoire | Source privilégiée |
|---------|-------------|-------------------|
| Identité complète du requérant (nom, prénom, date de naissance, adresse) | Oui | Pièce d'identité |
| Qualité du défendeur (établissement public, collectivité, État, ministre) | Oui | Décision attaquée |
| Tribunal administratif compétent | Oui | Ressort territorial |
| Nature du grief (faute, excès de pouvoir, refus, acte réglementaire) | Oui | Dossier |
| Date et nature de la décision contestée | Oui (fond) | Décision attaquée |
| Existence d'un RAPO obligatoire | Oui (fond) | Voir `references/rapo-domaines.md` |
| Décision sur RAPO si applicable | Oui (fond + RAPO) | Dossier |

### Éléments spécifiques au mode FOND

- Décision attaquée : nature, date, auteur, objet — **OBLIGATOIRE à peine d'irrecevabilité** (art. R412-1 CJA)
- Copie de la décision attaquée — **OBLIGATOIRE à peine d'irrecevabilité** (art. R412-1 CJA)
- RAPO : pièce justifiant la date de dépôt du recours préalable — **OBLIGATOIRE si RAPO applicable** (art. L412-7 CRPA)
- Décision sur RAPO (décision de substitution) — **OBLIGATOIRE si RAPO applicable** — c'est cette décision, non la décision initiale, qui est contestée devant le TA
- Délai de recours : 2 mois à compter notification (art. R421-1 CJA) — vérifier que le délai n'est pas expiré

### Éléments spécifiques au mode RÉFÉRÉ

- Urgence (pour référé-suspension et provision) : caractériser avec précision
- Doute sérieux sur la légalité (pour référé-suspension art. L521-1 CJA)
- Montant non sérieusement contestable (pour référé-provision art. R541-1 CJA)
- Pour référé expertise : spécialité de l'expert requis, griefs médicaux potentiels

---

## Étape 2 — Contrôle RAPO obligatoire

ALWAYS vérifier si la matière du litige impose un RAPO avant tout recours contentieux. Consulter `references/rapo-domaines.md` pour la liste exhaustive.

**Règle absolue — RAPO et pièces à produire :**

```
Matière avec RAPO obligatoire ?
├─ OUI → Pièces obligatoires :
│        ├─ [1] Copie du recours préalable (RAPO) avec preuve de dépôt
│        ├─ [2] Décision rendue sur le RAPO (décision de substitution)
│        │      OU preuve du silence valant rejet implicite
│        └─ [3] La requête est dirigée contre la décision sur RAPO,
│               NON contre la décision initiale (art. L412-7 CRPA)
│
└─ NON → Pièces obligatoires :
         ├─ [1] Copie de la décision attaquée
         └─ [2] Inventaire détaillé des pièces (art. R412-2 CJA)
```

NEVER rédiger une requête au fond en omettant de vérifier l'existence d'un RAPO — l'irrecevabilité ne peut être régularisée après expiration du délai de recours.

---

## Étape 3 — Sélection de la matière et du fondement

Identifier la matière parmi les suivantes pour charger le développement juridique approprié :

| Matière | Fondements principaux | Mode |
|---------|----------------------|------|
| Responsabilité médicale — établissement public | L1142-1 CSP, R541-1 CJA | RÉFÉRÉ ou FOND |
| Excès de pouvoir — acte individuel | R421-1 CJA, L521-1 CJA | FOND ou RÉFÉRÉ-SUSPENSION |
| Plein contentieux — indemnisation | R421-1 CJA, décision préalable indemnitaire | FOND |
| Urbanisme — permis de construire / refus | L424-1 Code urbanisme, délai 2 mois | FOND |
| Fonction publique — sanction disciplinaire | L. 4125-1 C. défense (militaires), statut FPE | FOND + RAPO |
| Contentieux fiscal — impôt direct | R190-1 LPF, R199-1 LPF | FOND + RAPO fiscal |
| Droit des étrangers — OQTF, refus titre | L614-1 CESEDA | FOND + RAPO |
| Marchés publics — référé précontractuel | L551-1 CJA | RÉFÉRÉ |
| Marchés publics — recours contractuel | L551-13 CJA | FOND |
| Fonctionnaires — refus avancement/mutation | Statut FPE | FOND + RAPO éventuel |

Pour chaque matière, charger le fichier de référence correspondant dans `references/` si disponible.

---

## Étape 4 — Application du protocole legal-hallucination-checker

ALWAYS appliquer le protocole complet avant tout livrable. Aucune référence juridique — article, jurisprudence, loi — ne peut figurer dans l'acte final sans vérification via OpenLegi.

**Seuil minimal de fiabilité : score ≥ 80 (statuts `VERIFIE_EXACT` ou `VERIFIE_MINEUR`)**

Référence complète du protocole : fichiers `SKILL.md`, `taxonomie.md`, `strategies-recherche.md` du skill `legal-hallucination-checker` présents dans le projet.

Outils OpenLegi à mobiliser :
- `rechercher_code` → articles du CJA, CSP, CRPA, Code de l'urbanisme, Code de la défense
- `rechercher_jurisprudence_administrative` → décisions CE et CAA uniquement
- `rechercher_dans_texte_legal` → lois spéciales

---

## Étape 5 — Rédaction de l'acte

Charger le fichier de référence correspondant au mode détecté :

- Mode `REFERE_EXPERTISE` → `references/refere-expertise.md`
- Mode `REFERE_SUSPENSION` → `references/refere-suspension.md`
- Mode `REFERE_PROVISION` → `references/refere-provision.md`
- Mode `FOND` → `references/memoire-fond.md`

**Règles rédactionnelles absolues (Charte Conseil d'État 2025) :**

- Prose narrative sans listes à puces dans les développements juridiques
- Exposé des faits chronologique et objectif, distinct de l'argumentation juridique
- Conclusions précises : ne jamais écrire "dire et juger", "constater", "donner acte"
- Chaque jurisprudence citée doit comporter le lien Légifrance correspondant
- Ne développer que les fondements juridiques pertinents au cas d'espèce

---

## Étape 6 — Contrôle des pièces et bordereau

ALWAYS générer un bordereau de pièces structuré conforme à l'art. R412-2 CJA :
- Numérotation continue et croissante
- Libellé explicite pour chaque pièce
- Signalement des pièces obligatoires manquantes si le dossier est incomplet

**Pièces obligatoires à peine d'irrecevabilité — rappel synthétique :**

| Mode | Pièce n°1 | Pièce n°2 | Pièce n°3 |
|------|-----------|-----------|-----------|
| FOND sans RAPO | Décision attaquée | Copie décision | Inventaire |
| FOND avec RAPO | RAPO + preuve dépôt | Décision sur RAPO | Inventaire |
| RÉFÉRÉ expertise | — | — | Inventaire |

Si une pièce obligatoire est absente : SIGNALER explicitement avant de produire le livrable. Ne jamais générer un acte présentant un risque d'irrecevabilité sans en avertir l'avocat.

---

## Étape 7 — Production des livrables

Produire systématiquement dans cet ordre :

1. **Requête finale (.docx)** — via skill `docx`, conforme à la Charte Conseil d'État
2. **Rapport de vérification des sources** — format structuré du protocole `legal-hallucination-checker`, sections 1 à 6
3. **Bordereau de pièces** — format tableau, numérotation continue, signalement des pièces manquantes

NEVER produire le livrable .docx avant l'achèvement complet du protocole de vérification des références.

---

## Gestion des cas limites

| Situation | Comportement attendu |
|-----------|---------------------|
| Dossier médical incomplet | Signaler les pièces manquantes, poursuivre avec les éléments disponibles en indiquant les lacunes |
| RAPO applicable mais décision sur RAPO absente | Bloquer la rédaction au fond — avertir que la requête serait irrecevable — proposer d'analyser la situation de fait |
| Délai de recours potentiellement expiré | Avertir expressément, calculer le délai avec les dates fournies, signaler le risque avant de continuer |
| Matière non couverte par un fichier de référence | Poursuivre avec les règles communes du SKILL.md + vérification OpenLegi des fondements spécifiques |
| Jurisprudence obtenant un score < 80 | Retirer de l'acte, documenter dans le rapport, proposer une décision alternative vérifiée |

---

## Commandes directes

- `/refere` → lancer mode RÉFÉRÉ (poser la question sur le type)
- `/refere-expertise` → lancer directement mode REFERE_EXPERTISE
- `/refere-suspension` → lancer directement mode REFERE_SUSPENSION
- `/fond` → lancer mode FOND
- `/ta` → démarrer le questionnaire de recueil d'éléments toutes matières

---

## Références internes

- `references/refere-expertise.md` — template complet référé expertise médicale + mission Dintilhac 22 points
- `references/memoire-fond.md` — template mémoire introductif au fond toutes matières
- `references/rapo-domaines.md` — liste exhaustive des matières avec RAPO obligatoire + textes de référence
- `references/articles-cja-verifies.md` — articles CJA vérifiés via OpenLegi avec liens Légifrance

Lire un fichier de référence uniquement si la tâche en cours le nécessite — zéro token tant qu'il n'est pas lu.
