# Mémoire introductif au fond — Tribunal administratif

## Table des matières
1. Structure de l'acte
2. En-tête et identification des parties
3. Exposé des faits
4. Discussion juridique — recours pour excès de pouvoir
5. Discussion juridique — plein contentieux indemnitaire
6. Conclusions et demandes
7. Bordereau de pièces
8. Contrôle RAPO et délais

---

## 1. Structure de l'acte

L'acte se compose dans l'ordre suivant, sans exception :
1. En-tête LEXVOX AVOCATS
2. Identification du tribunal administratif compétent
3. Identification du requérant et de son avocat
4. Identification du défendeur
5. "PLAISE AU TRIBUNAL"
6. I. Faits et procédure (prose chronologique)
7. II. Recevabilité (si nécessaire)
8. III. Discussion juridique (fondements sélectionnés)
9. "PAR CES MOTIFS"
10. Dispositif (conclusions chiffrées si indemnitaire)
11. "SOUS TOUTES RÉSERVES"
12. Bordereau de pièces

---

## 2. En-tête et identification

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                              LEXVOX AVOCATS                                  ║
║                                                                              ║
║  Maître Patrice HUMBERT                    Maître Cédrine RAYBAUD           ║
║  Avocat spécialisé en Dommage corporel     Avocat spécialisé en droit de    ║
║  et Responsabilité médicale                la famille, des personnes et     ║
║                                            du patrimoine                     ║
║                                                                              ║
║  282 Boulevard Foch - 13300 SALON DE PROVENCE                               ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

**À MONSIEUR LE PRÉSIDENT ET MESSIEURS LES CONSEILLERS COMPOSANT LE TRIBUNAL ADMINISTRATIF DE [VILLE]**

**[Madame/Monsieur] [PRÉNOM] [NOM]**, né(e) le [date] à [lieu], demeurant [adresse],

Ayant pour avocat la SELARL LEXVOX, prise en la personne de Maître Patrice HUMBERT, Avocat au Barreau d'Aix-en-Provence, 282 boulevard Foch, 13300 SALON DE PROVENCE,

Qui se constitue sur la présente et ses suites,

**CONTRE :**

**[Dénomination du défendeur]**, dont le siège est [adresse], pris en la personne de [qualité du représentant légal],

*[Si RAPO applicable] :*
**[Autorité ayant statué sur le RAPO]**, prise en la personne de [qualité],

---

## 3. Exposé des faits (section I)

*[Rédiger en prose chronologique, sans listes à puces, avec les dates précises.]*

Structure recommandée :
- Situation initiale et contexte
- Décision administrative initiale (date, nature, auteur, objet)
- *[Si RAPO]* : recours préalable formé le [date], décision sur RAPO notifiée le [date]
- Préjudice ou atteinte aux droits résultant de la décision
- Démarches amiables si effectuées
- Situation actuelle du requérant

IMPORTANT — En présence d'un RAPO : préciser que la requête est dirigée contre la **décision sur RAPO** qui s'est substituée à la décision initiale en application de l'article L412-7 du Code des relations entre le public et l'administration.

---

## 4. Discussion — Recours pour excès de pouvoir

### A. Sur la recevabilité du recours

La requête est recevable. Elle est formée dans le délai de deux mois imparti par l'article R421-1 du code de justice administrative, courant à compter de la notification de la décision [attaquée / prise sur RAPO] intervenue le [date].

*[Si RAPO]* : En application de l'article L412-7 du code des relations entre le public et l'administration, la décision rendue le [date] par [autorité] sur le recours préalable obligatoire formé le [date] s'est substituée à la décision initiale du [date]. La présente requête est donc dirigée contre cette seule décision de substitution.

### B. Sur l'illégalité de la décision attaquée

#### 1. Sur l'illégalité externe

*[Sélectionner selon le cas]*

**a) Incompétence de l'auteur de l'acte**

[Démonstration : habilitation requise, absence de délégation régulière]

**b) Vice de procédure**

[Démonstration : consultation obligatoire omise, contradictoire non respecté, motivation absente]

**c) Vice de forme**

[Démonstration : forme légale non respectée, mentions obligatoires absentes]

#### 2. Sur l'illégalité interne

**a) Violation de la loi**

[Article ou texte méconnu — vérifier via OpenLegi avant citation — démonstration de la méconnaissance]

**b) Erreur de droit**

[Mauvaise qualification juridique des faits, méconnaissance du champ d'application d'un texte]

**c) Erreur manifeste d'appréciation**

[Appréciation manifestement erronée des circonstances de l'espèce — jurisprudence à vérifier via OpenLegi]

**d) Détournement de pouvoir**

*[Si applicable et démontrable]*

---

## 5. Discussion — Plein contentieux indemnitaire

### A. Sur la recevabilité

La recevabilité est subordonnée à l'existence d'une décision administrative préalable. Par courrier du [date], [le/la] requérant(e) a adressé une demande indemnitaire préalable à [l'administration], restée sans réponse dans le délai de deux mois / ayant fait l'objet d'un rejet explicite le [date]. La présente requête est donc recevable.

### B. Sur la responsabilité de la personne publique

*[Sélectionner le fondement selon la matière]*

**1. Responsabilité pour faute de service**

[Démonstration : faute caractérisée, lien de causalité, préjudice — jurisprudences CE et CAA vérifiées]

**2. Responsabilité pour faute médicale**

Aux termes de l'article L1142-1 du code de la santé publique : [citation exacte vérifiée via OpenLegi].

[Développement conforme au modèle `refere-expertise.md` pour la partie responsabilité médicale]

**3. Responsabilité sans faute**

*[Si applicable : risque, rupture d'égalité devant les charges publiques, travaux publics]*

[Fondement et démonstration]

### C. Sur l'évaluation des préjudices

*[Développer selon la nomenclature Dintilhac adaptée à la matière]*

Préjudices patrimoniaux :
- Préjudices économiques (perte de revenus, frais)
- Assistance tierce personne

Préjudices extrapatrimoniaux :
- Déficit fonctionnel (temporaire et permanent)
- Souffrances endurées
- Préjudice esthétique
- Préjudice d'agrément

---

## 6. Dispositif

**PAR CES MOTIFS**

Vu le code de justice administrative,

Vu [textes applicables à la matière — vérifiés via OpenLegi],

Vu les jurisprudences citées,

**Il est demandé au Tribunal administratif de [Ville] :**

*[Mode excès de pouvoir] :*

**1°)** D'annuler la décision [de substitution rendue sur RAPO du / attaquée du] [date] par [auteur] ;

**2°)** De mettre à la charge de [défendeur] la somme de [montant] euros au titre de l'article L761-1 du code de justice administrative ;

**3°)** De mettre les dépens à la charge de [défendeur].

*[Mode plein contentieux indemnitaire] :*

**1°)** De condamner [défendeur] à verser à [requérant(e)] la somme de [montant] euros en réparation des préjudices subis, assortie des intérêts au taux légal à compter du [date de la demande préalable] ;

**2°)** De mettre à la charge de [défendeur] la somme de [montant] euros au titre de l'article L761-1 du code de justice administrative ;

**3°)** De mettre les dépens à la charge de [défendeur].

---

**SOUS TOUTES RÉSERVES**

---

## 7. Bordereau de pièces — Mode FOND

| N° | Intitulé de la pièce | Obligatoire |
|----|---------------------|-------------|
| 1 | Copie de la pièce d'identité | Non |
| 2 | **Décision attaquée du [date]** (ou décision sur RAPO) | **OUI — irrecevabilité** |
| 3 | **RAPO : copie du recours préalable avec preuve de dépôt** | **OUI si RAPO applicable** |
| 4 | Décision initiale (si distincte de la décision sur RAPO) | Recommandé |
| 5 | Pièces justifiant les faits allégués | Selon dossier |
| 6 | Certificats, rapports, éléments probatoires | Selon dossier |
| 7 | [Autres pièces pertinentes] | — |

---

## 8. Contrôle délais — Checklist rapide

```
Décision initiale notifiée le : [date]
    ↓
RAPO applicable ? → OUI / NON
    ↓ (si OUI)
RAPO déposé le : [date]
Décision sur RAPO notifiée le : [date]
    ↓
Délai de recours contentieux : 2 mois à compter du [date notification décision sur RAPO]
Date limite de dépôt : [date limite]
Date de dépôt envisagée : [date]
    ↓
Délai respecté ? → OUI / NON
    ↓ (si NON) → AVERTIR L'AVOCAT — recours potentiellement tardif
```

ALWAYS afficher ce contrôle de délai avant de produire le livrable final.
