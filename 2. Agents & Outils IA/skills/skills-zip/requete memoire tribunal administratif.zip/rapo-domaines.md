# RAPO — Recours administratifs préalables obligatoires
## Liste exhaustive par matière · Sources Lexbase + OpenLegi vérifiées

> **Règle fondamentale** (art. L412-7 CRPA) : la décision prise à la suite d'un RAPO se substitue à la décision initiale. Le recours contentieux est dirigé exclusivement contre la décision de substitution.

---

## Table des matières
1. Militaires — Commission des recours des militaires (CRM)
2. Fonction publique civile — Commission de recours
3. Contentieux fiscal — Réclamation préalable
4. Droit des étrangers — OQTF et titre de séjour
5. Permis de conduire — Commission médicale
6. Administration pénitentiaire
7. Pensions civiles et militaires d'invalidité
8. Marchés publics
9. Tableau synthétique

---

## 1. Militaires — Commission des recours des militaires (CRM)

**Texte** : art. L4125-1 du Code de la défense
**Lexbase** : https://www.lexbase.fr/numlxb/L3816LLW

**Décisions concernées** : sanctions disciplinaires, notation, avancement, affectation, radiation des cadres, résiliation du contrat d'engagement.

**Procédure** :
- Recours devant la CRM dans les 2 mois de la notification de la décision initiale
- Délai de réponse de l'administration : 4 mois (silence = rejet implicite)
- Délai de recours contentieux : 2 mois à compter de la notification de la décision CRM

**Pièces à produire devant le TA** :
- Pièce n°1 : Décision initiale de l'administration
- Pièce n°2 : Copie du recours formé devant la CRM avec preuve de dépôt/envoi
- Pièce n°3 : **Décision rendue par la CRM** (décision de substitution attaquée devant le TA)
- OU preuve que la CRM n'a pas statué dans le délai de 4 mois (rejet implicite)

---

## 2. Fonction publique civile

**Texte** : Selon corps et statut — pas de RAPO généralisé mais certains statuts spéciaux l'imposent (magistrats, personnels de l'éducation nationale, certaines administrations de contrôle)

**RAPO facultatif devenu obligatoire** dans certains corps : vérifier le statut particulier applicable avant de saisir le TA.

**Recours gracieux ou hiérarchique** : suspendent le délai de recours contentieux mais ne constituent pas un RAPO sauf si le texte le prévoit expressément.

**Pièces à produire devant le TA** :
- Décision attaquée (mutation, sanction, refus de promotion, etc.)
- Copie du recours préalable et accusé de réception
- Décision de rejet ou attestation de silence (délai de 2 mois)

---

## 3. Contentieux fiscal — Réclamation préalable obligatoire

**Textes** :
- Art. R190-1 du Livre des procédures fiscales (LPF) — https://www.lexbase.fr/numlxb/L5264MMW
- Art. R199-1 du LPF — https://www.lexbase.fr/numlxb/L1706INI
- Art. R*199-2 du LPF — https://www.lexbase.fr/numlxb/L1626INK

**Principe** : toute contestation d'une imposition (IR, IS, TVA, CFE, TFPB) doit être précédée d'une réclamation auprès du service des impôts compétent.

**Délai de réclamation** : jusqu'au 31 décembre de la 2e année suivant la mise en recouvrement du rôle ou la notification de l'avis de mise en recouvrement.

**Silence de l'administration** : 6 mois vaut rejet implicite ouvrant droit à la saisine du TA.

**Pièces à produire devant le TA** :
- Pièce n°1 : Copie de la réclamation fiscale préalable avec preuve de dépôt
- Pièce n°2 : Décision de rejet explicit ou attestation de silence (6 mois)
- Pièce n°3 : Avis d'imposition ou avis de mise en recouvrement contesté

---

## 4. Droit des étrangers

**OQTF avec délai de départ volontaire (DDV 30 jours)** :
- Art. L614-1 et s. du CESEDA
- Délai de recours : 30 jours à compter de la notification
- Pas de RAPO — recours direct devant le TA

**OQTF sans délai de départ volontaire** :
- Délai de recours : 48 heures
- Compétence : juge des libertés et de la détention (JLD) + TA en référé

**Refus de titre de séjour — RAPO** :
- Dans certains cas, une commission de recours peut être saisie
- Vérifier les instructions préfectorales et le régime applicable à la nationalité concernée

**Pièces communes** :
- OQTF ou décision de refus de titre notifiée
- Passeport ou titre d'identité
- Pièces justificatives du droit au séjour invoqué

---

## 5. Permis de conduire

**Texte** : R. 221-11 et s. du Code de la route
**Décisions concernées** : annulation administrative, suspension, refus de restitution après invalidation.

**RAPO** : recours devant la commission médicale primaire puis d'appel avant saisine du TA.

---

## 6. Pensions civiles et militaires d'invalidité

**Texte** : Loi du 31 mars 1919 et décret du 29 décembre 1983 pour les militaires
**RAPO** : recours devant la commission spéciale de réforme ou la commission consultative médicale selon le cas.

**Jurisprudence de référence** : CE avis, 21 mars 2019, n°397088 — [https://www.lexbase.fr/numlxb/A1957ZMG](https://www.lexbase.fr/numlxb/A1957ZMG)

Substitution intégrale de la décision sur RAPO à la décision initiale, avec possibilité d'invoquer les vices de procédure de la décision initiale (Lexbase Public du 22 juillet 2021 — [N8423BYM](https://www.lexbase.fr/numlxb/N8423BYM)).

---

## 7. Administration pénitentiaire

**RAPO** : recours devant le directeur interrégional des services pénitentiaires avant saisine du TA pour les décisions relatives aux conditions de détention, transferts, classement en détention particulière.

---

## 8. Tableau synthétique

| Matière | RAPO | Autorité RAPO | Délai RAPO | Délai contentieux |
|---------|------|--------------|------------|-------------------|
| Militaires — sanction/notation | OUI | CRM | 2 mois | 2 mois après CRM |
| Fiscal — imposition | OUI | Service des impôts | Variable | 2 mois après décision |
| Permis de conduire | OUI | Commission médicale | Variable | 2 mois |
| Pensions invalidité | OUI | Commission spéciale | Variable | 2 mois |
| Administration pénitentiaire | OUI (partiel) | Dir. interrégional | Variable | 2 mois |
| OQTF 30 jours | NON | — | — | 30 jours |
| Excès de pouvoir (droit commun) | NON | — | — | 2 mois |
| Plein contentieux indemnitaire | Décision préalable | Administration concernée | 2 mois silence | 2 mois |
| Marchés publics — référé précontractuel | NON | — | — | Avant signature |
| Urbanisme | NON | — | — | 2 mois |

---

## Références légales vérifiées via OpenLegi

- Art. L412-7 CRPA — substitution décision RAPO — https://www.lexbase.fr/numlxb/L1897KNL
- Art. L412-5 CRPA — administration statue sur situation à la date de sa décision — https://www.lexbase.fr/numlxb/L1895KNI
- Art. L4125-1 Code de la défense — CRM militaires — https://www.lexbase.fr/numlxb/L3816LLW
- Art. R412-1 CJA — pièces obligatoires à peine d'irrecevabilité — https://www.lexbase.fr/numlxb/L1656LKK
- Art. R412-2 CJA — inventaire détaillé des pièces — https://www.lexbase.fr/numlxb/L4406LYT
- Art. R421-1 CJA — délai de droit commun 2 mois — https://www.lexbase.fr/numlxb/L4139LUT
- Art. R190-1 LPF — réclamation fiscale préalable — https://www.lexbase.fr/numlxb/L5264MMW
