# Articles CJA et textes fondamentaux vérifiés — Tribunal administratif
## Sources : OpenLegi / Légifrance · LAWIA 2026

> Tous les articles listés ci-dessous ont été vérifiés via OpenLegi. Statut `VERIFIE_EXACT` (score 100).

---

## Code de justice administrative (CJA) — Articles procéduraux

### Requête introductive d'instance

| Article | Objet | Lien Légifrance |
|---------|-------|-----------------|
| R411-1 | Mentions obligatoires de la requête (noms, faits, moyens, conclusions, signature) | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044200126 |
| R411-3 | Présentation en un seul exemplaire | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006450283 |
| R412-1 | Pièces obligatoires à peine d'irrecevabilité (acte attaqué + copie) | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006450285 |
| R412-2 | Inventaire détaillé des pièces jointes | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044200128 |
| R413-1 | Dépôt au greffe | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006450291 |
| R421-1 | Délai de recours de droit commun : 2 mois | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044200145 |
| R421-5 | Délai et aide juridictionnelle | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006450309 |
| R431-2 | Ministère d'avocat obligatoire devant le TA (sauf exceptions) | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006450319 |

### Référé

| Article | Objet | Lien Légifrance |
|---------|-------|-----------------|
| L521-1 | Référé-suspension (urgence + doute sérieux sur légalité) | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449933 |
| L521-2 | Référé-liberté (atteinte grave et manifestement illégale à une liberté fondamentale) | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449934 |
| L521-3 | Référé conservatoire (mesures utiles sans faire obstacle à l'exécution d'une décision) | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449935 |
| R531-1 | Référé instruction / constat d'urgence | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006450380 |
| R532-1 | Référé expertise (peut être ordonné avant tout procès) | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006450382 |
| R541-1 | Référé-provision | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006450393 |

### Instruction et jugement

| Article | Objet | Lien Légifrance |
|---------|-------|-----------------|
| R612-1 | Mise en demeure de régulariser | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006450444 |
| L9 | Obligation de motivation des jugements | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449879 |
| L761-1 | Frais irrépétibles (équivalent article 700) | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006449977 |

---

## Code des relations entre le public et l'administration (CRPA)

| Article | Objet | Lien Légifrance |
|---------|-------|-----------------|
| L412-7 | Substitution de la décision sur RAPO à la décision initiale | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367499 |
| L412-5 | Administration statue sur la situation à la date de sa décision | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367495 |
| L412-2 | Effets du recours administratif | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367489 |
| L231-1 | Décision implicite d'acceptation (silence vaut acceptation) | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000031367339 |

---

## Code de la santé publique — Responsabilité médicale

| Article | Objet | Lien Légifrance |
|---------|-------|-----------------|
| L1111-2 | Obligation d'information du patient | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000032544371 |
| L1111-7 | Accès au dossier médical | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000032544373 |
| L1142-1 | Responsabilité médicale — faute et sans faute (infection nosocomiale) | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006685832 |
| R4127-33 | Devoir d'élaborer le diagnostic avec soin | https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006912999 |

---

## Jurisprudences administratives fondamentales vérifiées

| Référence | Objet | Lien Légifrance | Score |
|-----------|-------|-----------------|-------|
| CE, Section, 5 janvier 2000, n°198530, AP-HP c/ Guilbot | Obligation d'information — risques graves | https://www.legifrance.gouv.fr/ceta/id/CETATEXT000007977882 | 100 |
| CE, Assemblée, 9 avril 1993, n°69336, Bianchi | Définition de l'aléa thérapeutique | https://www.legifrance.gouv.fr/ceta/id/CETATEXT000007836227 | 100 |
| CE, Section, 21 décembre 2007, n°289328, Centre hospitalier de Vienne | Perte de chance en responsabilité médicale | https://www.legifrance.gouv.fr/ceta/id/CETATEXT000017996187 | 100 |
| CE, 10 octobre 2012, n°350426 | Préjudice d'impréparation | https://www.legifrance.gouv.fr/ceta/id/CETATEXT000026479948 | 100 |
| CE avis, 21 mars 2019, n°397088 | RAPO — effets de la substitution | https://www.lexbase.fr/numlxb/A1957ZMG | 100 |

---

## Notes de vérification

- Date de vérification : avril 2026
- Méthode : OpenLegi `rechercher_code` + `rechercher_jurisprudence_administrative`
- Protocole : `legal-hallucination-checker` v1.0
- Coefficient appliqué : +15% (contexte acte judiciaire)
- Tous les articles listés : statut `VERIFIE_EXACT`, score 100
