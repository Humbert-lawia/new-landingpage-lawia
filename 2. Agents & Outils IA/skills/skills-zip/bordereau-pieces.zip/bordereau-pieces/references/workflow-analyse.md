# Workflow d'analyse — Types de pièces et règles de classement

## 1. Définition d'une pièce juridique

Document relatif à un événement ayant une portée juridique :

| Catégorie | Exemples |
|-----------|---------|
| **Actes contractuels** | Contrat de vente, bail, avenant, devis signé, bon de commande, CGV |
| **Correspondances** | Courriers, emails, SMS, notifications, lettres recommandées, mises en demeure |
| **Documents financiers** | Factures, reçus, RIB, relevés bancaires, quittances, bulletins de salaire |
| **État civil / identité** | Acte de naissance, mariage, décès, carte d'identité, passeport, extrait Kbis |
| **Procès-verbaux** | PV d'accident, constat d'huissier, PV de police, rapport de gendarmerie |
| **Documents médicaux** | Certificat médical, compte-rendu hospitalier, rapport d'expertise médicale, ordonnance, bilan |
| **Décisions judiciaires** | Jugement, arrêt, ordonnance, décision arbitrale, injonction de payer |
| **Actes administratifs** | Arrêté, décision préfectorale, refus administratif, permis de construire |
| **Documents de procédure** | Assignation, conclusions, requête, acte de signification, avis de passage |
| **Rapports d'expertise** | Rapport amiable, rapport judiciaire, contre-expertise, avis technique |
| **Photos et captures** | Photos de l'accident, captures d'écran de messages, photos de préjudice |
| **Divers** | Attestations sur l'honneur, déclarations, procurations, testaments |

---

## 2. Règles de classement par domaine

### Ordre des domaines (priorité décroissante)

1. **Médical** → Chronologique (certificats médicaux, rapports, ordonnances, hospitalisations)
2. **Accident / Sinistre** → Chronologique (PV, constats, déclarations)
3. **Expertise** → Chronologique (convocations, rapport, dires)
4. **Procédure judiciaire** → Chronologique (assignation, conclusions, jugements)
5. **Contrats et actes** → Chronologique
6. **Correspondances** → Chronologique
7. **Documents financiers** → Chronologique
8. **État civil / Identité** → Pas de classement chronologique — regrouper par personne
9. **Divers** → Chronologique

### Règle en cas de pièce appartenant à plusieurs catégories

Classer dans la catégorie principale selon l'objet principal du document.
Ex. : Un courrier d'avocat relatif à une expertise → « Procédure judiciaire » et non « Correspondances ».

### Pièces sans date

Classer en **fin de leur domaine thématique**, précéder d'une note « [date absente] ».

---

## 3. Terminologie juridique des types de pièces

Utiliser la terminologie précise ci-dessous — NEVER « document », « fichier », « papier » :

| Expression courante | Terme juridique correct |
|--------------------|-----------------------|
| « Lettre du médecin » | Certificat médical du Dr [Nom] |
| « Mail de l'assureur » | Courrier électronique de [Assureur] |
| « Rapport d'expertise » | Rapport d'expertise judiciaire de M./Mme [Prénom Nom], expert |
| « Ordonnance » | Ordonnance médicale prescrite par le Dr [Nom] |
| « Jugement » | Jugement du Tribunal [Judiciaire / de commerce] de [ville] |
| « Arrêt » | Arrêt de la Cour d'appel de [ville] |
| « Décision de la CPAM » | Décision de la Caisse Primaire d'Assurance Maladie de [département] |
| « Constat d'huissier » | Procès-verbal de constat dressé par Maître [Nom], huissier de justice |
| « Photos » | Reportage photographique [daté si possible] |

---

## 4. Identification de l'auteur (champ « Rédigé par »)

Pour chaque pièce, identifier :

| Type de document | Auteur à mentionner |
|-----------------|---------------------|
| Certificat médical | Dr [Prénom NOM], médecin [spécialité] |
| Rapport d'expertise | M./Mme [Prénom NOM], expert judiciaire / amiable |
| Jugement / Arrêt | Le Tribunal [nom] / La Cour d'appel de [ville] |
| Courrier d'avocat | Maître [Prénom NOM], avocat |
| Facture | [Nom de la société émettrice] |
| Contrat | [Parties contractantes] |
| PV de police | Officier de police judiciaire / Brigade de [lieu] |
| Attestation | [Nom du signataire], [qualité] |
| Ordonnance médicale | Dr [Prénom NOM] |
| Courrier d'assureur | [Nom de la compagnie d'assurance] |

Si l'auteur est inconnu ou illisible : mentionner « Auteur non identifié ».

---

## 5. Exemples de descriptions de pièces (bordereau)

### Format attendu dans le bordereau LEXVOX :

**Bon :**
```
3. **Rapport d'expertise médicale judiciaire**. Rapport établi le 14 mars 2024 par le 
   Docteur Jean MARTIN, expert près la Cour d'appel d'Aix-en-Provence, retenant un taux 
   d'AIPP de 15 % et une date de consolidation au 1er janvier 2024. Rédigé par : 
   Dr Jean MARTIN, expert judiciaire.
```

**Mauvais (trop vague) :**
```
3. Document médical. Rapport du médecin. Rédigé par : le docteur.
```

**Bon :**
```
7. **Courrier de mise en demeure**. Lettre recommandée avec accusé de réception adressée 
   le 5 octobre 2023 par la SARL DUPONT à M. Jacques MARTIN, lui intimant de régler 
   la somme de 12 400 € TTC sous 8 jours. Rédigé par : SELARL LEROUX & ASSOCIÉS, avocats.
```

**Bon (pièce sans date) :**
```
12. **Attestation de témoin** [date absente]. Attestation rédigée par M. Pierre DURAND, 
    témoin de l'accident, relatant les circonstances de la collision. Rédigé par : 
    M. Pierre DURAND.
```

---

## 6. Points de vigilance lors de l'analyse

### Alertes à détecter systématiquement

| Anomalie | Signal détectable | Commentaire à insérer |
|----------|------------------|-----------------------|
| Antidatation probable | Date du document incohérente avec dates mentionnées dans d'autres pièces | « Date suspecte — incohérence avec pièce n°X » |
| Document généré par IA | Style parfait, absence de fautes, métadonnées absentes, police uniforme | « Document paraissant généré par IA » |
| Signature absente | Acte qui devrait être signé (contrat, attestation) mais ne l'est pas | « Signature absente alors que requise » |
| Pièce contradictoire | Montant, date ou fait différent d'une autre pièce | « Incohérence avec pièce n°Y sur [point] » |
| Document illisible | Scan de mauvaise qualité, texte coupé, résolution insuffisante | « Document partiellement illisible — [description de ce qui est visible] » |
| Cachet manquant | Acte officiel sans cachet (ordonnance, certificat) | « Cachet ou tampon absent » |

### Pièces essentielles souvent manquantes

Signaler dans la synthèse factuelle si absent :
- Jugement sans PV de signification → délai d'appel inconnu
- Expertise sans convocation → présence des parties non vérifiable
- Contrat sans conditions générales → portée des obligations incomplète
- Arrêt sans signification → délai de pourvoi non connu
- Certificat médical sans prescription → état de santé non documenté à la date clé

---

*Workflow analyse — Skill analyseur-dossier-juridique — Architecture LAWIA 2026*
*Créé par Maître Patrice Humbert, SELARL LEXVOX AVOCATS & ASSOCIÉS*
