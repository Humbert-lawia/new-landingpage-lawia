# Modèle officiel — Bordereau de communication de pièces LEXVOX

## Modèle vierge à compléter

```
### SELARL LEXVOX AVOCATS & ASSOCIÉS
### Maître Patrice HUMBERT — Avocat au Barreau d'Aix-en-Provence
### 282 Boulevard Foch — 13300 SALON-DE-PROVENCE
### Tél. : 04 90 54 58 10 — humbert@avocat-lexvox.com

## BORDEREAU DE COMMUNICATION DE PIÈCES

SELARL LEXVOX AVOCATS & ASSOCIÉS, Maître Patrice HUMBERT,
Avocat inscrit au Barreau d'Aix-en-Provence

### AVOCAT DE :
## [PRÉNOM NOM DU CLIENT]

### LES PIÈCES SUIVANTES DONT IL ENTEND FAIRE ÉTAT :

1. **[Titre exact de la Pièce 1]**. [Description succincte — date — parties — objet].
   Rédigé par : [Auteur ou institution].

2. **[Titre exact de la Pièce 2]**. [Description succincte — date — parties — objet].
   Rédigé par : [Auteur ou institution].

[...]

N. **[Titre exact de la Pièce N]**. [Description succincte — date — parties — objet].
   Rédigé par : [Auteur ou institution].

SOUS TOUTES RÉSERVES
```

---

## Exemple 1 — Dossier dommage corporel

```
### SELARL LEXVOX AVOCATS & ASSOCIÉS
### Maître Patrice HUMBERT — Avocat au Barreau d'Aix-en-Provence
### 282 Boulevard Foch — 13300 SALON-DE-PROVENCE

## BORDEREAU DE COMMUNICATION DE PIÈCES

SELARL LEXVOX AVOCATS & ASSOCIÉS, Maître Patrice HUMBERT,
Avocat inscrit au Barreau d'Aix-en-Provence

### AVOCAT DE :
## M. Jean-Pierre MARTIN

### LES PIÈCES SUIVANTES DONT IL ENTEND FAIRE ÉTAT :

1. **Procès-verbal de gendarmerie**. PV dressé le 14 mars 2023 par la Brigade de
   Salon-de-Provence, constatant les circonstances de l'accident de la circulation
   survenu sur la RN 113 impliquant M. MARTIN et M. DUPONT. Rédigé par :
   Adjudant-chef Pierre LEMOINE, Gendarmerie nationale.

2. **Rapport de police scientifique**. Rapport technique du 20 mars 2023 analysant
   l'état des véhicules impliqués et les conditions météorologiques. Rédigé par :
   Capitaine Sophie DUVAL, Police scientifique.

3. **Certificat médical initial**. Certificat établi le 14 mars 2023 au service des
   urgences du CH de Salon-de-Provence, prescrivant 30 jours d'ITT à M. Jean-Pierre
   MARTIN (37 ans) pour fracture de l'humérus gauche. Rédigé par :
   Dr Marie RENAUD, urgentiste.

4. **Compte-rendu opératoire**. Compte-rendu de l'intervention chirurgicale du 16 mars
   2023 au bloc opératoire du CH de Salon-de-Provence — ostéosynthèse de l'humérus
   gauche. Rédigé par : Dr Philippe COSTA, chirurgien orthopédiste.

5. **Rapport d'expertise médicale judiciaire**. Rapport définitif établi le 15 octobre
   2023 par le Docteur François BLANC, expert près la Cour d'appel d'Aix-en-Provence,
   retenant : consolidation au 1er septembre 2023, AIPP 12%, souffrances endurées 3/7,
   préjudice esthétique permanent 1/7. Rédigé par : Dr François BLANC, expert judiciaire.

6. **Justificatifs de perte de revenus**. Ensemble des bulletins de salaire de M. MARTIN
   des mois de mars à septembre 2023 (7 bulletins) attestant d'une rémunération mensuelle
   brute de 2 850 € et d'une perte effective liée à l'arrêt de travail. Rédigé par :
   SAS LOGISTIQUE DU SUD (employeur).

7. **Attestation de tiers payeur — CPAM des Bouches-du-Rhône**. Notification du 10 novembre
   2023 détaillant le montant des débours engagés par la CPAM au titre des soins dispensés
   à M. MARTIN : total 18 640 €. Rédigé par : CPAM des Bouches-du-Rhône.

SOUS TOUTES RÉSERVES
```

---

## Exemple 2 — Dossier responsabilité médicale

```
### SELARL LEXVOX AVOCATS & ASSOCIÉS
### Maître Patrice HUMBERT — Avocat au Barreau d'Aix-en-Provence
### 282 Boulevard Foch — 13300 SALON-DE-PROVENCE

## BORDEREAU DE COMMUNICATION DE PIÈCES

SELARL LEXVOX AVOCATS & ASSOCIÉS, Maître Patrice HUMBERT,
Avocat inscrit au Barreau d'Aix-en-Provence

### AVOCAT DE :
## Mme Lucie BERNARD

### LES PIÈCES SUIVANTES DONT IL ENTEND FAIRE ÉTAT :

1. **Compte-rendu d'hospitalisation**. Compte-rendu de l'hospitalisation de Mme BERNARD
   du 3 au 8 janvier 2022 à la Clinique des Pins d'Aix-en-Provence, dans le service de
   chirurgie digestive du Dr BLANC, pour intervention de cholécystectomie coelioscopique.
   Rédigé par : Clinique des Pins, Aix-en-Provence.

2. **Compte-rendu opératoire du 3 janvier 2022**. Compte-rendu de la cholécystectomie
   décrivant les modalités de l'intervention et la survenue d'une plaie de la voie biliaire
   principale. Rédigé par : Dr Alain BLANC, chirurgien.

3. **Courrier de saisine de la CCI PACA**. Courrier adressé le 15 mars 2022 par Maître
   HUMBERT à la Commission de Conciliation et d'Indemnisation des accidents médicaux de
   la Région PACA, aux fins d'expertise. Rédigé par : Maître Patrice HUMBERT.

4. **Rapport d'expertise CCI du 12 septembre 2022**. Rapport d'expertise collégiale établi
   par les Drs DUMONT et PERRET, experts CCI PACA, retenant une faute chirurgicale
   caractérisée et un lien de causalité direct avec les préjudices subis par Mme BERNARD.
   Rédigé par : Dr Patrick DUMONT et Dr Claire PERRET, experts CCI.

5. **Offre d'indemnisation SHAM du 5 décembre 2022**. Proposition d'indemnisation adressée
   par SHAM (assureur de la Clinique des Pins) pour un montant total de 28 500 €, jugée
   insuffisante et refusée par Mme BERNARD. Rédigé par : SHAM, assureur en responsabilité
   médicale.

SOUS TOUTES RÉSERVES
```

---

## Règles absolues du bordereau LEXVOX

| Règle | Application |
|-------|-------------|
| Cohérence de numérotation | N° identique dans tableau, bordereau, PDF |
| Pas de commentaires | Réservés au tableau de synthèse — jamais dans le bordereau |
| Titre en gras | TOUJOURS encadrer le titre de la pièce en **gras** |
| Précision de la description | Date + parties + objet + montant si pertinent |
| Auteur systématique | Toujours renseigner « Rédigé par » — « Auteur non identifié » si inconnu |
| SOUS TOUTES RÉSERVES | Toujours en fin de bordereau, en caractères distincts |
| Pas de pagination | Le bordereau ne porte pas de numéro de page |

---

*Modèle bordereau LEXVOX — Skill analyseur-dossier-juridique — Architecture LAWIA 2026*
*Créé par Maître Patrice Humbert, SELARL LEXVOX AVOCATS & ASSOCIÉS*
